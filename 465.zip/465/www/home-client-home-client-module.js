(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-client-home-client-module"],{

/***/ "./node_modules/firebase/auth/dist/index.esm.js":
/*!******************************************************!*\
  !*** ./node_modules/firebase/auth/dist/index.esm.js ***!
  \******************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _firebase_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @firebase/auth */ "./node_modules/@firebase/auth/dist/auth.esm.js");


/**
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/***/ }),

/***/ "./src/app/controls/popmenu/popmenu.component.html":
/*!*********************************************************!*\
  !*** ./src/app/controls/popmenu/popmenu.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\" class=\"animated fadeInDown\">\n    <ion-fab-button (click)=\"togglePopupMenu()\">\n      <ion-ripple-effect></ion-ripple-effect>\n      <ion-icon name=\"apps\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  \n  <div class=\"popup-menu\">\n    <div class=\"popup-menu-overlay\" [ngClass]=\"{'in': openMenu}\"></div>\n    <div class=\"popup-menu-panel\" [ngClass]=\"{'in': openMenu}\">\n      <div class=\"popup-menu-item\">\n        <ion-icon name=\"shirt\" slot=\"middle\" size=\"large\" (click)=\"shirtInfo()\"></ion-icon>\n        <span>Tipos de prenda</span>\n      </div>\n      <div class=\"popup-menu-item\">\n        <ion-icon name=\"chatboxes\" slot=\"middle\" size=\"large\" (click)=\"suggestions()\"></ion-icon>\n        <span>Recomendaciones</span>\n      </div>\n      <div class=\"popup-menu-item\">\n        <ion-icon name=\"book\" slot=\"middle\" size=\"large\" (click)=\"comments()\"></ion-icon>\n        <span>Comentarios</span>\n      </div>\n    </div>\n  </div>\n  "

/***/ }),

/***/ "./src/app/controls/popmenu/popmenu.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/controls/popmenu/popmenu.component.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".popup-menu-overlay {\n  position: fixed;\n  top: 30;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  z-index: 100;\n  opacity: 0;\n  visibility: hidden;\n  transition: all 0.15s ease-in-out;\n  background-image: linear-gradient(rgba(49, 44, 59, 0.85) 0%, rgba(50, 45, 63, 0.65) 50%); }\n  .popup-menu-overlay.in {\n    opacity: 1;\n    visibility: visible; }\n  .popup-menu-toggle {\n  position: fixed;\n  width: 40px;\n  height: 40px;\n  bottom: 10px;\n  left: 50%;\n  margin-left: -20px;\n  background-color: var(--ion-color-primary);\n  border-radius: 50%;\n  z-index: 101;\n  transition: all .25s ease-in-out; }\n  .popup-menu-toggle.out {\n    opacity: 0;\n    visibility: hidden;\n    transform: scale(0);\n    transition: all .15s ease-in-out; }\n  .popup-menu-toggle.out:before {\n      transition: all .15s ease-in-out;\n      transform: scale(0); }\n  .popup-menu-panel {\n  position: fixed;\n  width: 300px;\n  border-radius: 5%;\n  bottom: 80px;\n  left: 50%;\n  margin-left: -150px;\n  padding: 20px;\n  background-color: var(--ion-color-primary);\n  z-index: 102;\n  transition: all .25s ease-in-out;\n  transition-delay: .15s;\n  transform-origin: 50% 100%;\n  transform: scale(0);\n  display: -moz-flex;\n  display: flex;\n  flex-wrap: wrap; }\n  .popup-menu-panel .popup-menu-item {\n    margin: auto;\n    -moz-flex: 1 0 30%;\n    flex: 1 0 30%;\n    display: -moz-flex;\n    display: flex;\n    -moz-flex-direction: column;\n    flex-direction: column;\n    transform: scale(0);\n    opacity: 0;\n    transition: all .25s ease-in-out; }\n  .popup-menu-panel .popup-menu-item ion-icon {\n      margin: 0 auto;\n      text-align: center;\n      color: #fff; }\n  .popup-menu-panel .popup-menu-item span {\n      padding: 0;\n      margin: 0 0 auto 0;\n      color: #fff;\n      text-align: center;\n      font-size: 12px;\n      text-transform: uppercase;\n      font-weight: 500;\n      line-height: 18px; }\n  .popup-menu-panel .popup-menu-item:active i {\n      color: #dd4135;\n      transition: all 0.15s; }\n  .popup-menu-panel .popup-menu-item:active span {\n      color: #dd4135;\n      transition: all .15s; }\n  .popup-menu-panel.in {\n    transform: scale(1);\n    transition-delay: 0s; }\n  .popup-menu-panel.in .popup-menu-item {\n      transform: scale(1);\n      opacity: 1;\n      transition-delay: .15s; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29udHJvbHMvcG9wbWVudS9DOlxcVXNlcnNcXGFsZXhhXFxEZXNrdG9wXFxGaW5hbC9zcmNcXGFwcFxcY29udHJvbHNcXHBvcG1lbnVcXHBvcG1lbnUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxlQUFlO0VBQ2YsT0FBTztFQUNQLE9BQU87RUFDUCxRQUFRO0VBQ1IsU0FBUztFQUNULFlBQVk7RUFDWixVQUFVO0VBQ1Ysa0JBQWtCO0VBRWxCLGlDQUFpQztFQUVqQyx3RkFBd0YsRUFBQTtFQVo1RjtJQWNRLFVBQVU7SUFDVixtQkFBbUIsRUFBQTtFQUkzQjtFQUNJLGVBQWU7RUFDZixXQUFXO0VBQ1gsWUFBWTtFQUNaLFlBQVk7RUFDWixTQUFTO0VBQ1Qsa0JBQWtCO0VBQ2xCLDBDQUEwQztFQUMxQyxrQkFBa0I7RUFDbEIsWUFBWTtFQUVaLGdDQUFnQyxFQUFBO0VBWHBDO0lBYVEsVUFBVTtJQUNWLGtCQUFrQjtJQUVsQixtQkFBbUI7SUFFbkIsZ0NBQWdDLEVBQUE7RUFsQnhDO01BcUJZLGdDQUFnQztNQUVoQyxtQkFBbUIsRUFBQTtFQUsvQjtFQUNJLGVBQWU7RUFDZixZQUFZO0VBRVosaUJBQWlCO0VBQ2pCLFlBQVk7RUFDWixTQUFTO0VBQ1QsbUJBQW1CO0VBQ25CLGFBQWE7RUFDYiwwQ0FBMEM7RUFDMUMsWUFBWTtFQUVaLGdDQUFnQztFQUVoQyxzQkFBc0I7RUFFdEIsMEJBQTBCO0VBRTFCLG1CQUFtQjtFQUluQixrQkFBa0I7RUFFbEIsYUFBYTtFQUliLGVBQWUsRUFBQTtFQTVCbkI7SUE4QlEsWUFBWTtJQUlaLGtCQUFrQjtJQUVsQixhQUFhO0lBSWIsa0JBQWtCO0lBRWxCLGFBQWE7SUFJYiwyQkFBMkI7SUFFM0Isc0JBQXNCO0lBRXRCLG1CQUFtQjtJQUNuQixVQUFVO0lBRVYsZ0NBQWdDLEVBQUE7RUFyRHhDO01BdURZLGNBQWM7TUFDZCxrQkFBa0I7TUFDbEIsV0FBVyxFQUFBO0VBekR2QjtNQTREWSxVQUFVO01BQ1Ysa0JBQWtCO01BQ2xCLFdBQVc7TUFDWCxrQkFBa0I7TUFDbEIsZUFBZTtNQUNmLHlCQUF5QjtNQUN6QixnQkFBZ0I7TUFDaEIsaUJBQWlCLEVBQUE7RUFuRTdCO01BdUVnQixjQUFxQjtNQUVyQixxQkFBcUIsRUFBQTtFQXpFckM7TUE0RWdCLGNBQXFCO01BRXJCLG9CQUFvQixFQUFBO0VBOUVwQztJQW9GUSxtQkFBbUI7SUFFbkIsb0JBQW9CLEVBQUE7RUF0RjVCO01BeUZZLG1CQUFtQjtNQUNuQixVQUFVO01BRVYsc0JBQXNCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9jb250cm9scy9wb3BtZW51L3BvcG1lbnUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBQb3B1cCBNZW51IC8vXHJcbi5wb3B1cC1tZW51LW92ZXJsYXkge1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgdG9wOiAzMDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICByaWdodDogMDtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIHotaW5kZXg6IDEwMDtcclxuICAgIG9wYWNpdHk6IDA7XHJcbiAgICB2aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAwLjE1cyBlYXNlLWluLW91dDtcclxuICAgIHRyYW5zaXRpb246IGFsbCAwLjE1cyBlYXNlLWluLW91dDtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KHJnYmEoNjksIDY1LCA3NywgMC44NSkgMCUsIHJnYmEoNTksIDU0LCA2OCwgMC42NSkgNTAlKTtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudChyZ2JhKDQ5LCA0NCwgNTksIDAuODUpIDAlLCByZ2JhKDUwLCA0NSwgNjMsIDAuNjUpIDUwJSk7XHJcbiAgICAmLmluIHtcclxuICAgICAgICBvcGFjaXR5OiAxO1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHZpc2libGU7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5wb3B1cC1tZW51LXRvZ2dsZSB7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICB3aWR0aDogNDBweDtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIGJvdHRvbTogMTBweDtcclxuICAgIGxlZnQ6IDUwJTtcclxuICAgIG1hcmdpbi1sZWZ0OiAtMjBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIHotaW5kZXg6IDEwMTtcclxuICAgIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIC4yNXMgZWFzZS1pbi1vdXQ7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgLjI1cyBlYXNlLWluLW91dDtcclxuICAgICYub3V0IHtcclxuICAgICAgICBvcGFjaXR5OiAwO1xyXG4gICAgICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcclxuICAgICAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoMCk7XHJcbiAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgwKTtcclxuICAgICAgICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAuMTVzIGVhc2UtaW4tb3V0O1xyXG4gICAgICAgIHRyYW5zaXRpb246IGFsbCAuMTVzIGVhc2UtaW4tb3V0O1xyXG4gICAgICAgICY6YmVmb3JlIHtcclxuICAgICAgICAgICAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjE1cyBlYXNlLWluLW91dDtcclxuICAgICAgICAgICAgdHJhbnNpdGlvbjogYWxsIC4xNXMgZWFzZS1pbi1vdXQ7XHJcbiAgICAgICAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgwKTtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgwKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi5wb3B1cC1tZW51LXBhbmVsIHtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIHdpZHRoOiAzMDBweDtcclxuXHJcbiAgICBib3JkZXItcmFkaXVzOiA1JTtcclxuICAgIGJvdHRvbTogODBweDtcclxuICAgIGxlZnQ6IDUwJTtcclxuICAgIG1hcmdpbi1sZWZ0OiAtMTUwcHg7XHJcbiAgICBwYWRkaW5nOiAyMHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgei1pbmRleDogMTAyO1xyXG4gICAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjI1cyBlYXNlLWluLW91dDtcclxuICAgIHRyYW5zaXRpb246IGFsbCAuMjVzIGVhc2UtaW4tb3V0O1xyXG4gICAgLXdlYmtpdC10cmFuc2l0aW9uLWRlbGF5OiAuMTVzO1xyXG4gICAgdHJhbnNpdGlvbi1kZWxheTogLjE1cztcclxuICAgIC13ZWJraXQtdHJhbnNmb3JtLW9yaWdpbjogNTAlIDEwMCU7XHJcbiAgICB0cmFuc2Zvcm0tb3JpZ2luOiA1MCUgMTAwJTtcclxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgwKTtcclxuICAgIHRyYW5zZm9ybTogc2NhbGUoMCk7XHJcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcclxuICAgIGRpc3BsYXk6IC1tb3otYm94O1xyXG4gICAgZGlzcGxheTogLXdlYmtpdC1mbGV4O1xyXG4gICAgZGlzcGxheTogLW1vei1mbGV4O1xyXG4gICAgZGlzcGxheTogLW1zLWZsZXhib3g7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgLXdlYmtpdC1mbGV4LXdyYXA6IHdyYXA7XHJcbiAgICAtbW96LWZsZXgtd3JhcDogd3JhcDtcclxuICAgIC1tcy1mbGV4LXdyYXA6IHdyYXA7XHJcbiAgICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgICAucG9wdXAtbWVudS1pdGVtIHtcclxuICAgICAgICBtYXJnaW46IGF1dG87XHJcbiAgICAgICAgLXdlYmtpdC1ib3gtZmxleDogMSAwIDMwJTtcclxuICAgICAgICAtd2Via2l0LWZsZXg6IDEgMCAzMCU7XHJcbiAgICAgICAgLW1vei1ib3gtZmxleDogMSAwIDMwJTtcclxuICAgICAgICAtbW96LWZsZXg6IDEgMCAzMCU7XHJcbiAgICAgICAgLW1zLWZsZXg6IDEgMCAzMCU7XHJcbiAgICAgICAgZmxleDogMSAwIDMwJTtcclxuICAgICAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcclxuICAgICAgICBkaXNwbGF5OiAtbW96LWJveDtcclxuICAgICAgICBkaXNwbGF5OiAtd2Via2l0LWZsZXg7XHJcbiAgICAgICAgZGlzcGxheTogLW1vei1mbGV4O1xyXG4gICAgICAgIGRpc3BsYXk6IC1tcy1mbGV4Ym94O1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgLXdlYmtpdC1ib3gtZGlyZWN0aW9uOiBub3JtYWw7XHJcbiAgICAgICAgLXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbDtcclxuICAgICAgICAtd2Via2l0LWZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgICAgLW1vei1mbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgIC1tcy1mbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlKDApO1xyXG4gICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMCk7XHJcbiAgICAgICAgb3BhY2l0eTogMDtcclxuICAgICAgICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAuMjVzIGVhc2UtaW4tb3V0O1xyXG4gICAgICAgIHRyYW5zaXRpb246IGFsbCAuMjVzIGVhc2UtaW4tb3V0O1xyXG4gICAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICAgICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNwYW4ge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgICBtYXJnaW46IDAgMCBhdXRvIDA7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDE4cHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICY6YWN0aXZlIHtcclxuICAgICAgICAgICAgaSB7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogcmdiKDIyMSw2NSw1Myk7XHJcbiAgICAgICAgICAgICAgICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAuMTVzO1xyXG4gICAgICAgICAgICAgICAgdHJhbnNpdGlvbjogYWxsIDAuMTVzO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHNwYW4ge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IHJnYigyMjEsNjUsNTMpO1xyXG4gICAgICAgICAgICAgICAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjE1cztcclxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb246IGFsbCAuMTVzO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgJi5pbiB7XHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlKDEpO1xyXG4gICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMSk7XHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2l0aW9uLWRlbGF5OiAwcztcclxuICAgICAgICB0cmFuc2l0aW9uLWRlbGF5OiAwcztcclxuICAgICAgICAucG9wdXAtbWVudS1pdGVtIHtcclxuICAgICAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlKDEpO1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpO1xyXG4gICAgICAgICAgICBvcGFjaXR5OiAxO1xyXG4gICAgICAgICAgICAtd2Via2l0LXRyYW5zaXRpb24tZGVsYXk6IC4xNXM7XHJcbiAgICAgICAgICAgIHRyYW5zaXRpb24tZGVsYXk6IC4xNXM7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/controls/popmenu/popmenu.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/controls/popmenu/popmenu.component.ts ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var PopmenuComponent = /** @class */ (function () {
    function PopmenuComponent(router) {
        this.router = router;
        this.openMenu = false;
    }
    PopmenuComponent.prototype.ngOnInit = function () {
    };
    PopmenuComponent.prototype.togglePopupMenu = function () {
        return this.openMenu = !this.openMenu;
    };
    PopmenuComponent.prototype.shirtInfo = function () {
        this.router.navigateRoot('/shirt-info');
    };
    PopmenuComponent.prototype.suggestions = function () {
        this.router.navigateRoot('/suggestions');
    };
    PopmenuComponent.prototype.comments = function () {
        this.router.navigateRoot('/comments');
    };
    PopmenuComponent = __decorate([
        core_1.Component({
            selector: 'popmenu',
            template: __webpack_require__(/*! ./popmenu.component.html */ "./src/app/controls/popmenu/popmenu.component.html"),
            styles: [__webpack_require__(/*! ./popmenu.component.scss */ "./src/app/controls/popmenu/popmenu.component.scss")]
        }),
        __metadata("design:paramtypes", [angular_1.NavController])
    ], PopmenuComponent);
    return PopmenuComponent;
}());
exports.PopmenuComponent = PopmenuComponent;


/***/ }),

/***/ "./src/app/directives/has-role.directive.ts":
/*!**************************************************!*\
  !*** ./src/app/directives/has-role.directive.ts ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var auth_service_1 = __webpack_require__(/*! ../providers/auth.service */ "./src/app/providers/auth.service.ts");
var HasRoleDirective = /** @class */ (function () {
    function HasRoleDirective(authService, templateRef, viewContainer) {
        this.authService = authService;
        this.templateRef = templateRef;
        this.viewContainer = viewContainer;
    }
    HasRoleDirective.prototype.ngOnInit = function () {
        var _this = this;
        this.authService.getUserSubject().subscribe(function (_) {
            if (_this.authService.hasRoles(_this.roles)) {
                _this.viewContainer.createEmbeddedView(_this.templateRef);
            }
            else {
                _this.viewContainer.clear();
            }
        });
    };
    __decorate([
        core_1.Input('appHasRole'),
        __metadata("design:type", Array)
    ], HasRoleDirective.prototype, "roles", void 0);
    HasRoleDirective = __decorate([
        core_1.Directive({
            selector: '[appHasRole]'
        }),
        __metadata("design:paramtypes", [auth_service_1.AuthService, core_1.TemplateRef, core_1.ViewContainerRef])
    ], HasRoleDirective);
    return HasRoleDirective;
}());
exports.HasRoleDirective = HasRoleDirective;


/***/ }),

/***/ "./src/app/directives/shared-directives.module.ts":
/*!********************************************************!*\
  !*** ./src/app/directives/shared-directives.module.ts ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var has_role_directive_1 = __webpack_require__(/*! ./has-role.directive */ "./src/app/directives/has-role.directive.ts");
var SharedDirectivesModule = /** @class */ (function () {
    function SharedDirectivesModule() {
    }
    SharedDirectivesModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule
            ],
            declarations: [has_role_directive_1.HasRoleDirective],
            exports: [has_role_directive_1.HasRoleDirective]
        })
    ], SharedDirectivesModule);
    return SharedDirectivesModule;
}());
exports.SharedDirectivesModule = SharedDirectivesModule;


/***/ }),

/***/ "./src/app/home-client/home-client.module.ts":
/*!***************************************************!*\
  !*** ./src/app/home-client/home-client.module.ts ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var home_client_page_1 = __webpack_require__(/*! ./home-client.page */ "./src/app/home-client/home-client.page.ts");
var popmenu_component_1 = __webpack_require__(/*! ../controls/popmenu/popmenu.component */ "./src/app/controls/popmenu/popmenu.component.ts");
var shared_directives_module_1 = __webpack_require__(/*! ../directives/shared-directives.module */ "./src/app/directives/shared-directives.module.ts");
var routes = [
    {
        path: '',
        component: home_client_page_1.HomeClientPage
    }
];
var HomeClientPageModule = /** @class */ (function () {
    function HomeClientPageModule() {
    }
    HomeClientPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                shared_directives_module_1.SharedDirectivesModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [home_client_page_1.HomeClientPage, popmenu_component_1.PopmenuComponent]
        })
    ], HomeClientPageModule);
    return HomeClientPageModule;
}());
exports.HomeClientPageModule = HomeClientPageModule;


/***/ }),

/***/ "./src/app/home-client/home-client.page.html":
/*!***************************************************!*\
  !*** ./src/app/home-client/home-client.page.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"secondary\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>\n        <ion-text color=\"light\">\n          <ion-text color=\"light\" class=\"fw700\">Apparel Designer</ion-text>\n        </ion-text>\n    </ion-title>\n    <ion-buttons slot=\"end\">\n    \t<ion-buttons slot=\"end\">\n\t\t\t\n        <ion-button fill=\"clear\" class=\"shadow-0 txt-light\" [routerLink]=\"'/mycart'\" routerDirection=\"forward\">\n          <ion-icon name=\"cart\"></ion-icon>\n        </ion-button>\n      </ion-buttons>\n    </ion-buttons>\n  </ion-toolbar>\n\n</ion-header>\n\n\n<div class=\"logoContainer\">\n   <img src=\"https://www.seekclipart.com/clipng/middle/28-280784_hand-sewing-needles-thread-hypodermic-needle-black-needle.png\" class=\"logo\">\n</div>\n<ion-content>\n  \n  <ion-button  margin shape=\"round\" expand=\"full\" color=\"secondary\" (click)=\"designer()\">\n    Generar orden de confeccion\n  </ion-button>\n  \n  <ion-button margin shape=\"round\" expand=\"full\" color=\"secondary\" (click)=\"vendorCatalog()\">\n    Catalogo de  productos \n  </ion-button>\n\n  <ion-button margin shape=\"round\" expand=\"full\" color=\"secondary\" (click)=\"myOrder()\">\n    Mis pedidos\n  </ion-button>\n\n  <ion-button margin shape=\"round\" expand=\"full\" color=\"secondary\" (click)=\"designOrders()\">\n   Mis Ordenes de confeccion\n  </ion-button>\n  \n  <ion-button margin shape=\"round\" expand=\"full\" color=\"secondary\" (click)=\"logout()\">\n    Salir\n  </ion-button>\n\n\n  <popmenu></popmenu>\n\n</ion-content>\n  "

/***/ }),

/***/ "./src/app/home-client/home-client.page.scss":
/*!***************************************************!*\
  !*** ./src/app/home-client/home-client.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host ion-content {\n  --background: var(--ion-color-light); }\n\n:host ion-item {\n  border-radius: 0;\n  border-bottom: 1px dotted var(--ion-color-medium); }\n\n:host ion-card.no-radius {\n  border-radius: 0; }\n\n:host .logoContainer {\n  background-color: var(--ion-color-light); }\n\n:host .logoContainer .logo {\n    width: 100px;\n    height: 100px;\n    margin: 10px auto 8px;\n    background-size: 50%;\n    margin-left: 35%; }\n\n:host .toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS1jbGllbnQvQzpcXFVzZXJzXFxhbGV4YVxcRGVza3RvcFxcRmluYWwvc3JjXFxhcHBcXGhvbWUtY2xpZW50XFxob21lLWNsaWVudC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFUSxvQ0FBYSxFQUFBOztBQUZyQjtFQU1RLGdCQUFnQjtFQUNoQixpREFBaUQsRUFBQTs7QUFQekQ7RUFZWSxnQkFBZ0IsRUFBQTs7QUFaNUI7RUF3Qk8sd0NBQXdDLEVBQUE7O0FBeEIvQztJQWlCUSxZQUFZO0lBQ1osYUFBYTtJQUNiLHFCQUFxQjtJQUNyQixvQkFBb0I7SUFDckIsZ0JBQWdCLEVBQUE7O0FBckJ2QjtFQThCSSxzRkFBYSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvaG9tZS1jbGllbnQvaG9tZS1jbGllbnQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gICAgaW9uLWNvbnRlbnQge1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcclxuICAgIH1cclxuXHJcbiAgICBpb24taXRlbSB7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMDtcclxuICAgICAgICBib3JkZXItYm90dG9tOiAxcHggZG90dGVkIHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICAgfVxyXG5cclxuICAgIGlvbi1jYXJkIHtcclxuICAgICAgICAmLm5vLXJhZGl1cyB7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDA7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4ubG9nb0NvbnRhaW5lcntcclxuICAgIC5sb2dvIHtcclxuICAgICAgICB3aWR0aDogMTAwcHg7XHJcbiAgICAgICAgaGVpZ2h0OiAxMDBweDtcclxuICAgICAgICBtYXJnaW46IDEwcHggYXV0byA4cHg7XHJcbiAgICAgICAgYmFja2dyb3VuZC1zaXplOiA1MCU7XHJcbiAgICAgICBtYXJnaW4tbGVmdDogMzUlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gICAgXHJcbn1cclxuXHJcbi50b29sYmFyIHtcclxuICAgXHJcbiAgICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsIHZhcigtLWlvbi1jb2xvci1kYXJrKSwgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpKTtcclxuICAgICAgICBcclxuICB9XHJcbiAgIFxyXG59Il19 */"

/***/ }),

/***/ "./src/app/home-client/home-client.page.ts":
/*!*************************************************!*\
  !*** ./src/app/home-client/home-client.page.ts ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var currencies_1 = __webpack_require__(/*! src/providers/currencies */ "./src/providers/currencies.ts");
var users_1 = __webpack_require__(/*! src/providers/users */ "./src/providers/users.ts");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var firebase = __webpack_require__(/*! firebase/app */ "./node_modules/firebase/app/dist/index.cjs.js");
__webpack_require__(/*! firebase/auth */ "./node_modules/firebase/auth/dist/index.esm.js");
__webpack_require__(/*! firebase/firestore */ "./node_modules/firebase/firestore/dist/index.esm.js");
var auth_service_1 = __webpack_require__(/*! ../providers/auth.service */ "./src/app/providers/auth.service.ts");
var HomeClientPage = /** @class */ (function () {
    function HomeClientPage(navCtrl, currenciesProv, toastCtrl, menuCtrl, events, usersProv, router, authService) {
        this.navCtrl = navCtrl;
        this.currenciesProv = currenciesProv;
        this.toastCtrl = toastCtrl;
        this.menuCtrl = menuCtrl;
        this.events = events;
        this.usersProv = usersProv;
        this.router = router;
        this.authService = authService;
        this.autheticated = false;
        this.menu = [];
        this.isAdmin = false;
        this.userId = "9gZV69NOKSYFYHtkYVQ2YCJOa1Q2";
    }
    HomeClientPage.prototype.ngOnInit = function () {
        var userId = firebase.auth().currentUser;
        this.user == userId;
    };
    HomeClientPage.prototype.ionViewWillLoad = function () {
    };
    HomeClientPage.prototype.addProduct = function () {
        this.navCtrl.navigateRoot('/add-product');
    };
    HomeClientPage.prototype.designer = function () {
        this.navCtrl.navigateRoot('/designer');
    };
    HomeClientPage.prototype.administration = function () {
        this.navCtrl.navigateRoot('/administration');
    };
    HomeClientPage.prototype.vendorCatalog = function () {
        this.navCtrl.navigateRoot('/home');
    };
    HomeClientPage.prototype.myOrder = function () {
        this.navCtrl.navigateRoot('/myorder');
    };
    HomeClientPage.prototype.designOrders = function () {
        this.navCtrl.navigateRoot('/design-orders');
    };
    HomeClientPage.prototype.logout = function () {
        var _this = this;
        this.usersProv.logoutUser().then(function () {
            _this.user = null;
            _this.router.navigateByUrl('/login');
            _this.menuCtrl.enable(false);
        });
    };
    HomeClientPage = __decorate([
        core_1.Component({
            selector: "app-home-client",
            template: __webpack_require__(/*! ./home-client.page.html */ "./src/app/home-client/home-client.page.html"),
            styles: [__webpack_require__(/*! ./home-client.page.scss */ "./src/app/home-client/home-client.page.scss")]
        }),
        __metadata("design:paramtypes", [angular_1.NavController,
            currencies_1.CurrenciesProvider,
            angular_1.ToastController,
            angular_1.MenuController,
            angular_1.Events,
            users_1.UsersProvider,
            router_1.Router,
            auth_service_1.AuthService])
    ], HomeClientPage);
    return HomeClientPage;
}());
exports.HomeClientPage = HomeClientPage;


/***/ }),

/***/ "./src/app/providers/auth.service.ts":
/*!*******************************************!*\
  !*** ./src/app/providers/auth.service.ts ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var rxjs_1 = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
var AuthService = /** @class */ (function () {
    function AuthService() {
        this.currentUser = new rxjs_1.BehaviorSubject(null);
    }
    AuthService.prototype.login = function (name) {
        if (name === 'user') {
            this.currentUser.next({
                name: 'Dummy User',
                roles: ['[read-content]', 'purchase-items', 'user']
            });
        }
        else if (name === 'admin') {
            this.currentUser.next({
                name: 'The Admin',
                roles: ['read-content', 'write-content', 'admin']
            });
        }
    };
    AuthService.prototype.getUserSubject = function () {
        return this.currentUser.asObservable();
    };
    AuthService.prototype.logout = function () {
        this.currentUser.next(null);
    };
    AuthService.prototype.hasRoles = function (roles) {
        for (var _i = 0, roles_1 = roles; _i < roles_1.length; _i++) {
            var oneRole = roles_1[_i];
            if (!this.currentUser || !this.currentUser.value.roles.includes(oneRole)) {
                return false;
            }
        }
        return true;
    };
    AuthService = __decorate([
        core_1.Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], AuthService);
    return AuthService;
}());
exports.AuthService = AuthService;


/***/ })

}]);
//# sourceMappingURL=home-client-home-client-module.js.map