(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["mycart-mycart-module"],{

/***/ "./src/app/mycart/mycart.module.ts":
/*!*****************************************!*\
  !*** ./src/app/mycart/mycart.module.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var mycart_page_1 = __webpack_require__(/*! ./mycart.page */ "./src/app/mycart/mycart.page.ts");
var routes = [
    {
        path: '',
        component: mycart_page_1.MycartPage
    }
];
var MycartPageModule = /** @class */ (function () {
    function MycartPageModule() {
    }
    MycartPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [mycart_page_1.MycartPage]
        })
    ], MycartPageModule);
    return MycartPageModule;
}());
exports.MycartPageModule = MycartPageModule;


/***/ }),

/***/ "./src/app/mycart/mycart.page.html":
/*!*****************************************!*\
  !*** ./src/app/mycart/mycart.page.html ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-header>\n\t<ion-toolbar class=\"toolbar\">\n\t\t\t<ion-buttons slot=\"start\">\n\t\t\t\t\t<ion-menu-button color=\"light \t\"></ion-menu-button>\n\t\t    </ion-buttons>\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-back-button class=\"mgb-5  txt-light\" defaultHref=\"/home\"></ion-back-button>\n\t\t  </ion-buttons>\n\t  \n\n\t\t<ion-buttons slot=\"end\">\n\t\t\t<ion-button fill=\"clear\" class=\"mgb-5  txt-light\" [routerLink]=\"'/search'\" routerDirection=\"forward\">\n\t\t\t\t<ion-icon name=\"search\"></ion-icon>\n\t\t\t</ion-button>\n\t\t</ion-buttons>\n\n\t\t<ion-title class=\"mgb-5  txt-light\">Carrito de compras</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content class=\"pdl-15 pdr-15\">\n\t<br>\n\t<div padding class=\"\" *ngIf=\"!list_cart || list_cart.length == 0 || list_cart == null\">\n\t\t<h3 class=\"txt1\">Todavia no has añadido ningun producto al carrito</h3>\n\t</div>\n\t<div class=\"\" *ngIf=\"list_cart && list_cart.length > 0 && list_cart != null\">\n\t\t<div class=\"\">\n\t\t\t<div class=\"item-cart pdb-15 pdt-15\" *ngFor=\"let item of list_cart, let i = index\">\n\t\t\t\t<div class=\"\">\n\t\t\t\t\t<ion-button class=\"shadow-0 txt3\" fill=\"clear\" (click)=\"removeItem(i)\">\n\t\t\t\t\t\t<ion-icon name=\"ios-close-circle\"></ion-icon>\n\t\t\t\t\t</ion-button>\n\t\t\t\t</div>\n\t\t\t\t<div class=\"thumb ovfl-hidden flex-row flex-ali-center flex-jus-center\" [routerLink]=\"['/detail', {id_item: item.id}]\">\n\t\t\t\t\t<img [src]=\"item.thumb\">\n\t\t\t\t</div>\n\t\t\t\t<div class=\"description pdl-10 pdr-15 ovfl-hidden\" [routerLink]=\"['/detail', {id_item: item.id}]\">\n\t\t\t\t\t<h4 class=\"fs-16 mg-0 ellipsis\">{{item.name}}</h4>\n\t\t\t\t\t<p class=\"mg-0 txt3 fw-600 ellipsis\" *ngIf=\"currenciesProv\">\n\t\t\t\t\t\t<span class=\"ellipsis fs-14 txt3 mg-0 line-through mgr-10 fw-600\" *ngIf=\"item.discount > 0\">\n\t\t\t\t\t\t\t<i>{{(item.price)}} Lps</i>\n\t\t\t\t\t\t</span>\n\t\t\t\t\t\t<span class=\"ellipsis fs-14 txt1 mg-0 fw-600\" *ngIf=\"item.discount > 0\">\n\t\t\t\t\t\t\t{{(item.price - item.price*item.discount/100)}} Lps\n\t\t\t\t\t\t</span>\n\t\t\t\t\t\t<span class=\"ellipsis fs-14 txt1 mg-0 fw-600\" *ngIf=\"item.discount == 0\">\n\t\t\t\t\t\t\t{{(item.price)}} Lps\n\t\t\t\t\t\t</span>\n\t\t\t\t\t</p>\n\t\t\t\t\t<ion-button>Personalizar</ion-button>\n\t\t\t\t</div>\n\t\t\t\t<div class=\"quantity\">\n\t\t\t\t\t<ion-button fill=\"clear\" size=\"small\" class=\"txt3 shadow-0 fs-18 mg-0\" (click)=\"quantity(i, 1)\">\n\t\t\t\t\t\t<ion-icon name=\"ios-add\"></ion-icon>\n\t\t\t\t\t</ion-button>\n\t\t\t\t\t<ion-input type=\"number\" text-center value=\"{{item.quantity}}\" (ionChange)=\"enterQuantity(i, $event.target.value)\" min=\"1\" max=\"99\" minlength=\"1\" maxlength=\"2\"></ion-input>\n\t\t\t\t\t<ion-button fill=\"clear\" size=\"small\" class=\"txt3 shadow-0 fs-18 mg-0\" (click)=\"quantity(i, -1)\">\n\t\t\t\t\t\t<ion-icon name=\"ios-remove\"></ion-icon>\n\t\t\t\t\t</ion-button>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\n\t\t<div class=\"white mgt-15\">\n\t\t\t<div class=\"transaction-fee flex-row flex-ali-center pdl-20 pdr-20 pdb-5\">\n\t\t\t\t<p class=\"txt3\">Precio total</p>\n\t\t\t\t<p class=\"fw-600 flex-1\" text-right *ngIf=\"total_price\">+ {{(total_price)}} Lps</p>\n\t\t\t</div>\n\t\t\t<hr class=\"bg-light\">\n\t\t\t<div class=\"transaction-fee flex-row flex-ali-center pdl-20 pdr-20 pdb-5\">\n\t\t\t\t<p class=\"txt3\">Impuesto 15 %</p>\n\t\t\t\t<p class=\"fw-600 flex-1\" text-right *ngIf=\"tax_pay\">+ {{(tax_pay)}} Lps</p>\n\t\t\t</div>\n\t\t\t<hr class=\"bg-light\">\n\t\t\t<div class=\"transaction-fee flex-row flex-ali-center pdl-20 pdr-20 pdb-5\">\n\t\t\t\t<p class=\"txt3\">Tarifa de transaccion({{(shipfee_pay)}})</p>\n\t\t\t\t<p class=\"fw-600 flex-1\" text-right *ngIf=\"shipfee_pay\">+ {{(shipfee_pay)}} Lps</p>\n\t\t\t</div>\n\t\t\t<hr class=\"bg-light\">\n\t\t\t<div class=\"total-pay mgt-30\" text-center>\n\t\t\t\t<p class=\"txt4 mgb-5\">Total a pagar</p>\n\t\t\t\t<h2 class=\"fw-900 spacing-3 fs-40 mgt-0\" *ngIf=\"total_pay\">{{(total_pay)}} Lps</h2>\n\t\t\t</div>\n\t\t\t<br class=\"bg-light\">\n\t\t\t<div class=\"\" text-center>\n\t\t\t\t<ion-button size=\"large\" shape=\"round\" color=\"primary\" class=\"bdra-30 uppercase fw-600 bg-base\" [routerLink]=\"['/checkout', {total_price: total_price, tax_pay: tax_pay, shipfee_pay: shipfee_pay, total_pay: total_pay}]\" routerDirection=\"forward\">\n\t\t\t\t\tRealizar pago\n\t\t\t\t\t<ion-icon slot=\"end\" name=\"md-play\"></ion-icon>\n\t\t\t\t</ion-button>\n\t\t\t</div>\n\t\t\t<br>\n\t\t\t<br>\n\t\t\t<br>\n\t\t\t<br>\n\t\t</div>\n\t</div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/mycart/mycart.page.scss":
/*!*****************************************!*\
  !*** ./src/app/mycart/mycart.page.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".item-cart {\n  display: flex;\n  align-items: center;\n  border-bottom: 1px solid #ebebeb; }\n  .item-cart .thumb {\n    width: 60px;\n    height: 70px; }\n  .item-cart .thumb img {\n      height: 100%;\n      min-width: 100%; }\n  .item-cart .description {\n    flex: 10; }\n  .item-cart .quantity {\n    flex: 1; }\n  .item-cart .quantity input {\n      width: 30px;\n      margin-top: 6px;\n      margin-bottom: 6px; }\n  .transaction-fee {\n  display: flex;\n  align-items: center; }\n  .toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbXljYXJ0L0M6XFxVc2Vyc1xcYWxleGFcXERlc2t0b3BcXEZpbmFsL3NyY1xcYXBwXFxteWNhcnRcXG15Y2FydC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLGdDQUFnQyxFQUFBO0VBSGpDO0lBS0UsV0FBVztJQUNYLFlBQVksRUFBQTtFQU5kO01BUUcsWUFBWTtNQUNaLGVBQWUsRUFBQTtFQVRsQjtJQWFFLFFBQVEsRUFBQTtFQWJWO0lBZ0JFLE9BQU8sRUFBQTtFQWhCVDtNQWtCRyxXQUFXO01BQ1gsZUFBZTtNQUNmLGtCQUFrQixFQUFBO0VBSXJCO0VBQ0MsYUFBYTtFQUNiLG1CQUFtQixFQUFBO0VBR3BCO0VBRUMsc0ZBQWEsRUFBQSIsImZpbGUiOiJzcmMvYXBwL215Y2FydC9teWNhcnQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLml0ZW0tY2FydHtcblx0ZGlzcGxheTogZmxleDtcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcblx0Ym9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlYmViZWI7XG5cdC50aHVtYntcblx0XHR3aWR0aDogNjBweDtcblx0XHRoZWlnaHQ6IDcwcHg7XG5cdFx0aW1ne1xuXHRcdFx0aGVpZ2h0OiAxMDAlO1xuXHRcdFx0bWluLXdpZHRoOiAxMDAlO1xuXHRcdH1cblx0fVxuXHQuZGVzY3JpcHRpb257XG5cdFx0ZmxleDogMTA7XG5cdH1cblx0LnF1YW50aXR5e1xuXHRcdGZsZXg6IDE7XG5cdFx0aW5wdXR7XG5cdFx0XHR3aWR0aDogMzBweDtcblx0XHRcdG1hcmdpbi10b3A6IDZweDtcblx0XHRcdG1hcmdpbi1ib3R0b206IDZweDtcblx0XHR9XG5cdH1cbn1cbi50cmFuc2FjdGlvbi1mZWV7XG5cdGRpc3BsYXk6IGZsZXg7XG5cdGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi50b29sYmFyIHtcbiAgIFxuXHQtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsIHZhcigtLWlvbi1jb2xvci1kYXJrKSwgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpKTtcblx0XHRcbiAgfSJdfQ== */"

/***/ }),

/***/ "./src/app/mycart/mycart.page.ts":
/*!***************************************!*\
  !*** ./src/app/mycart/mycart.page.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
var currencies_1 = __webpack_require__(/*! ../../providers/currencies */ "./src/providers/currencies.ts");
var MycartPage = /** @class */ (function () {
    function MycartPage(events, currenciesProv, storage) {
        var _this = this;
        this.events = events;
        this.currenciesProv = currenciesProv;
        this.storage = storage;
        this.total_price = 0;
        this.total_pay = 0;
        this.storage.get('cart_list').then(function (val) {
            if (!val || val == null) {
                _this.list_cart = new Array();
            }
            else {
                _this.list_cart = val;
            }
            console.log(_this.list_cart);
        });
        this.events.subscribe('cart_list: change', function (lst) {
            _this.list_cart = lst;
        });
        this.storage.get('setting').then(function (val) {
            _this.tax = val.tax_fee;
            _this.shipfee = val.ship_fee;
            _this.price_calc();
        });
    }
    MycartPage.prototype.ionViewWillEnter = function () {
    };
    MycartPage.prototype.price_calc = function () {
        var _this = this;
        this.total_price = 0;
        this.list_cart.forEach(function (val) {
            var item_tmp = 0;
            if (val.discount > 0) {
                item_tmp = (parseFloat(val.price) - parseFloat(val.price) / 100 * parseFloat(val.discount)) * parseInt(val.quantity);
            }
            else {
                item_tmp = parseFloat(val.price) * parseInt(val.quantity);
            }
            _this.total_price = _this.total_price + item_tmp;
        });
        this.shipfee_calc();
        this.tax_calc();
        this.total_pay_calc();
    };
    MycartPage.prototype.shipfee_calc = function () {
        this.shipfee_pay = parseFloat(this.total_price) / 100 * this.shipfee;
    };
    MycartPage.prototype.tax_calc = function () {
        this.tax_pay = parseFloat(this.total_price) / 100 * this.tax;
    };
    MycartPage.prototype.total_pay_calc = function () {
        this.total_pay = this.shipfee_pay + this.tax_pay + this.total_price;
    };
    MycartPage.prototype.quantity = function (i, qtt) {
        this.list_cart[i].quantity = parseFloat(this.list_cart[i].quantity) + parseFloat(qtt);
        if (this.list_cart[i].quantity > 99) {
            this.list_cart[i].quantity = 99;
        }
        if (this.list_cart[i].quantity < 1) {
            this.list_cart[i].quantity = 1;
        }
        this.events.publish('cart_list: change', this.list_cart);
        this.storage.set('cart_list', this.list_cart);
        this.price_calc();
    };
    MycartPage.prototype.enterQuantity = function (i, qtt) {
        this.list_cart[i].quantity = parseFloat(qtt);
        if (this.list_cart[i].quantity > 99) {
            this.list_cart[i].quantity = 99;
        }
        if (this.list_cart[i].quantity < 1) {
            this.list_cart[i].quantity = 1;
        }
        this.events.publish('cart_list: change', this.list_cart);
        this.storage.set('cart_list', this.list_cart);
        this.price_calc();
    };
    MycartPage.prototype.removeItem = function (i) {
        this.list_cart.splice(i, 1);
        this.events.publish('cart_list: change', this.list_cart);
        this.storage.set('cart_list', this.list_cart);
    };
    MycartPage.prototype.ngOnInit = function () {
    };
    MycartPage = __decorate([
        core_1.Component({
            selector: 'app-mycart',
            template: __webpack_require__(/*! ./mycart.page.html */ "./src/app/mycart/mycart.page.html"),
            styles: [__webpack_require__(/*! ./mycart.page.scss */ "./src/app/mycart/mycart.page.scss")]
        }),
        __metadata("design:paramtypes", [angular_1.Events,
            currencies_1.CurrenciesProvider,
            storage_1.Storage])
    ], MycartPage);
    return MycartPage;
}());
exports.MycartPage = MycartPage;


/***/ })

}]);
//# sourceMappingURL=mycart-mycart-module.js.map