(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["suggestions-suggestions-module"],{

/***/ "./src/app/suggestions/suggestions.module.ts":
/*!***************************************************!*\
  !*** ./src/app/suggestions/suggestions.module.ts ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var suggestions_page_1 = __webpack_require__(/*! ./suggestions.page */ "./src/app/suggestions/suggestions.page.ts");
var routes = [
    {
        path: '',
        component: suggestions_page_1.SuggestionsPage
    }
];
var SuggestionsPageModule = /** @class */ (function () {
    function SuggestionsPageModule() {
    }
    SuggestionsPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [suggestions_page_1.SuggestionsPage]
        })
    ], SuggestionsPageModule);
    return SuggestionsPageModule;
}());
exports.SuggestionsPageModule = SuggestionsPageModule;


/***/ }),

/***/ "./src/app/suggestions/suggestions.page.html":
/*!***************************************************!*\
  !*** ./src/app/suggestions/suggestions.page.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\t<ion-toolbar class=\"toolbar\">\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-back-button color=\"light\" text=\"\" icon=\"ios-arrow-round-back\"></ion-back-button>\n\t\t\t\n\t\t\t\t<ion-back-button class=\"mgb-5  txt-light\" defaultHref=\"/home-client\"></ion-back-button>\n\t\t\n\t\t</ion-buttons>\n\n\t\n\n\t\t<ion-title color=\"light\">Recomendaciones</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/suggestions/suggestions.page.scss":
/*!***************************************************!*\
  !*** ./src/app/suggestions/suggestions.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3VnZ2VzdGlvbnMvQzpcXFVzZXJzXFxhbGV4YVxcRGVza3RvcFxcRmluYWwvc3JjXFxhcHBcXHN1Z2dlc3Rpb25zXFxzdWdnZXN0aW9ucy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxzRkFBYSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvc3VnZ2VzdGlvbnMvc3VnZ2VzdGlvbnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXIge1xyXG4gICBcclxuICAgIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgdmFyKC0taW9uLWNvbG9yLWRhcmspLCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkpO1xyXG4gICAgICAgIFxyXG4gIH0iXX0= */"

/***/ }),

/***/ "./src/app/suggestions/suggestions.page.ts":
/*!*************************************************!*\
  !*** ./src/app/suggestions/suggestions.page.ts ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var SuggestionsPage = /** @class */ (function () {
    function SuggestionsPage() {
    }
    SuggestionsPage.prototype.ngOnInit = function () {
    };
    SuggestionsPage = __decorate([
        core_1.Component({
            selector: 'app-suggestions',
            template: __webpack_require__(/*! ./suggestions.page.html */ "./src/app/suggestions/suggestions.page.html"),
            styles: [__webpack_require__(/*! ./suggestions.page.scss */ "./src/app/suggestions/suggestions.page.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], SuggestionsPage);
    return SuggestionsPage;
}());
exports.SuggestionsPage = SuggestionsPage;


/***/ })

}]);
//# sourceMappingURL=suggestions-suggestions-module.js.map