(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["checkout-checkout-module"],{

/***/ "./src/app/checkout/checkout.module.ts":
/*!*********************************************!*\
  !*** ./src/app/checkout/checkout.module.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var forms_2 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var checkout_page_1 = __webpack_require__(/*! ./checkout.page */ "./src/app/checkout/checkout.page.ts");
var routes = [
    {
        path: '',
        component: checkout_page_1.CheckoutPage
    }
];
var CheckoutPageModule = /** @class */ (function () {
    function CheckoutPageModule() {
    }
    CheckoutPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                forms_2.ReactiveFormsModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [checkout_page_1.CheckoutPage]
        })
    ], CheckoutPageModule);
    return CheckoutPageModule;
}());
exports.CheckoutPageModule = CheckoutPageModule;


/***/ }),

/***/ "./src/app/checkout/checkout.page.html":
/*!*********************************************!*\
  !*** ./src/app/checkout/checkout.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-header>\n\t<ion-toolbar class=\"toolbar\">\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-back-button color=\"light\" text=\"\" icon=\"ios-arrow-round-back\"></ion-back-button>\n\t\t</ion-buttons>\n\t\t<ion-title color=\"light\">Pago</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\n\t<ion-row padding>\n\t\t<h4>Completar la orden</h4>\n\t\t<p>Necesitas completar la<br>informacion que se solicita</p>\n\t</ion-row>\n\t<ion-list *ngIf=\"pay_method != null\">\n\t\t<ion-radio-group [(ngModel)]=\"pay_method\">\n\t\t\t<ion-item>\n\t\t\t\t<ion-label>Pago a la entrega </ion-label>\n\t\t\t\t<ion-radio checked=\"true\" value=\"1\"></ion-radio>\n\t\t\t</ion-item>\n\n\t\t\t<ion-item>\n\t\t\t\t<ion-label>Pagar con tarjeta de credito</ion-label>\n\t\t\t\t<ion-radio value=\"2\"></ion-radio>\n\t\t\t</ion-item>\n\n\t\t\t<ion-item>\n\t\t\t\t<ion-label>Pagar usando Paypal</ion-label>\n\t\t\t\t<ion-radio value=\"3\"></ion-radio>\n\t\t\t</ion-item>\n\t\t</ion-radio-group>\n\t</ion-list>\n\n\t<ion-list>\n\t\t<div *ngIf=\"pay_method==2\">\n\t\t\t<ion-item>\n\t\t\t\t<ion-label stacked>Numero de tarjeta de credito</ion-label>\n\t\t\t\t<ion-input [(ngModel)]=\"card_info.number\" type=\"text\"></ion-input>\n\t\t\t</ion-item>\n\n\t\t\t<ion-item>\n\t\t\t\t<ion-label stacked>Exp Month</ion-label>\n\t\t\t\t<ion-input [(ngModel)]=\"card_info.expMonth\" type=\"text\"></ion-input>\n\t\t\t</ion-item>\n\n\t\t\t<ion-item>\n\t\t\t\t<ion-label stacked>Exp Year</ion-label>\n\t\t\t\t<ion-input [(ngModel)]=\"card_info.expYear\" type=\"text\"></ion-input>\n\t\t\t</ion-item>\n\n\t\t\t<ion-item>\n\t\t\t\t<ion-label stacked>CVC</ion-label>\n\t\t\t\t<ion-input [(ngModel)]=\"card_info.cvc\" type=\"text\"></ion-input>\n\t\t\t</ion-item>\n\t\t</div>\n\n\n\t\t<!-- <div *ngIf=\"user_id == null\">\n\t\t\t<ion-item>\n\t\t\t\t<ion-label stacked>Full name</ion-label>\n\t\t\t\t<ion-input [(ngModel)]=\"full_name\" type=\"text\"></ion-input>\n\t\t\t\t<p padding class=\"err\" *ngIf=\"full_name.length() < 5 || full_name.length() > 50\">* More than 5 and less than 50 characters, do not contain special characters.</p>\n\t\t\t</ion-item>\n\n\t\t\t<ion-item>\n\t\t\t\t<ion-label stacked>Phone</ion-label>\n\t\t\t\t<ion-input type=\"number\" [(ngModel)]=\"phone\" type=\"text\"></ion-input>\n\t\t\t\t<p padding class=\"err\" *ngIf=\"phone.length() < 10 || phone.length() > 50\">* More than 10 and less than 50 digits.</p>\n\t\t\t</ion-item>\n\n\t\t\t<ion-item>\n\t\t\t\t<ion-label stacked>Email</ion-label>\n\t\t\t\t<ion-input type=\"text\" [(ngModel)]=\"email\" type=\"text\"></ion-input>\n\t\t\t\t<p padding class=\"err\" *ngIf=\"email.length() < 10 || email.length() > 50\">* More than 10 and less than 50 digits.</p>\n\t\t\t</ion-item>\n\t\t</div> -->\n\t</ion-list>\n\n\t<form padding (ngSubmit)=\"order()\" [formGroup]=\"addressForm\" *ngIf=\"user_id || user_id != null\">\n\t\t<ion-list>\n\t\t\t<div padding>\n\t\t\t\t<ion-label class=\"txt3\">Direccion de recepcion</ion-label>\n\t\t\t\t<ion-item>\n\t\t\t\t\t<ion-input formControlName=\"address\" type=\"text\"></ion-input>\n\t\t\t\t</ion-item>\n\t\t\t\t<div text-right class=\"error-message\" *ngIf=\"!addressForm.controls.address.valid && addressForm.controls.address.dirty\">\n\t\t\t\t\t<p class=\"fs-14 mgt-5 txt-danger\">Por favor ingresa los datos correctamente</p>\n\t\t\t\t</div>\n\n\t\t\t\t<br>\n\n\t\t\t\t<ion-label class=\"txt3\">Mensaje</ion-label>\n\t\t\t\t<ion-item>\n\t\t\t\t\t<ion-textarea formControlName=\"message\"></ion-textarea>\n\t\t\t\t</ion-item>\n\t\t\t</div>\n\t\t</ion-list>\n\n\t\t<div class=\"payment\" padding>\n\t\t\t<p class=\"fee total-pay flex-row flex-ali-end\">\n\t\t\t\t<span class=\"uppercase fs-15 fw-600\">Precio:</span>\n\t\t\t\t<span class=\"mgl-20 fs-20 fw-600 spacing1 flex-1\" text-right *ngIf=\"currenciesProv\">{{(total_price)}} Lps</span>\n\t\t\t</p>\n\t\t\t<p class=\"fee total-pay flex-row flex-ali-end\">\n\t\t\t\t<span class=\"uppercase fs-15 fw-600\">Impuesto:</span>\n\t\t\t\t<span class=\"mgl-20 fs-20 fw-600 spacing1 flex-1\" text-right *ngIf=\"currenciesProv\">{{(tax_pay)}} lps</span>\n\t\t\t</p>\n\t\t\t<p class=\"fee total-pay flex-row flex-ali-end\">\n\t\t\t\t<span class=\"uppercase fs-15 fw-600\">Envio:</span>\n\t\t\t\t<span class=\"mgl-20 fs-20 fw-600 spacing1 flex-1\" text-right *ngIf=\"currenciesProv\">{{(shipfee_pay)}} Lps</span>\n\t\t\t</p>\n\n\t\t\t<p class=\"fee total-pay flex-row flex-ali-end\">\n\t\t\t\t<span class=\"uppercase fs-20 fw-600\">Pago:</span>\n\t\t\t\t<span class=\"mgl-20 fs-28 fw-600 spacing1 flex-1\" text-right *ngIf=\"currenciesProv\">{{(total_pay)}} Lps</span>\n\t\t\t</p>\n\n\t\t\t<div class=\"err_show\" *ngIf=\"!validate\">\n\t\t\t\t<p class=\"err txt-danger italic\">Error! debes llenar la informacion denuevo.</p>\n\t\t\t</div>\n\n\t\t\t<br><br>\n\n\t\t\t<ion-button type=\"submit\" shape=\"round\" expand=\"block\">\n\t\t\t\t<ion-icon slot=\"start\" name=\"card\"></ion-icon>Completar la orden\n\t\t\t</ion-button>\n\t\t\t\n\t\t\t<!-- <ion-button type=\"button\" class=\"mgt-15\" shape=\"round\" expand=\"block\" href=\"/mycart\" routerDirection=\"forward\">\n\t\t\t\t<ion-icon slot=\"start\" name=\"close\"></ion-icon>Cancel\n\t\t\t</ion-button> -->\n\t\t</div>\n\t</form>\n\n\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/checkout/checkout.page.scss":
/*!*********************************************!*\
  !*** ./src/app/checkout/checkout.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2hlY2tvdXQvQzpcXFVzZXJzXFxhbGV4YVxcRGVza3RvcFxcRmluYWwvc3JjXFxhcHBcXGNoZWNrb3V0XFxjaGVja291dC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxzRkFBYSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvY2hlY2tvdXQvY2hlY2tvdXQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXIge1xyXG4gICBcclxuICAgIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgdmFyKC0taW9uLWNvbG9yLWRhcmspLCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkpO1xyXG4gICAgICAgIFxyXG4gIH0iXX0= */"

/***/ }),

/***/ "./src/app/checkout/checkout.page.ts":
/*!*******************************************!*\
  !*** ./src/app/checkout/checkout.page.ts ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var environment_1 = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
var ngx_1 = __webpack_require__(/*! @ionic-native/stripe/ngx */ "./node_modules/@ionic-native/stripe/ngx/index.js");
var currencies_1 = __webpack_require__(/*! ../../providers/currencies */ "./src/providers/currencies.ts");
var orders_1 = __webpack_require__(/*! ../../providers/orders */ "./src/providers/orders.ts");
var ngx_2 = __webpack_require__(/*! @ionic-native/paypal/ngx */ "./node_modules/@ionic-native/paypal/ngx/index.js");
var CheckoutPage = /** @class */ (function () {
    function CheckoutPage(route, router, payPal, storage, toastCtrl, stripe, events, formBuilder, currenciesProv, ordersProv, loadingCtrl, alertCtrl) {
        var _this = this;
        this.route = route;
        this.router = router;
        this.payPal = payPal;
        this.storage = storage;
        this.toastCtrl = toastCtrl;
        this.stripe = stripe;
        this.events = events;
        this.formBuilder = formBuilder;
        this.currenciesProv = currenciesProv;
        this.ordersProv = ordersProv;
        this.loadingCtrl = loadingCtrl;
        this.alertCtrl = alertCtrl;
        this.fullname = '';
        this.phone = '';
        this.address = '';
        this.validate = true;
        this.pay_method = 1;
        this.email = '';
        this.user_id = '';
        /*this card info just for test, pls set it to empty string when your app go online */
        this.card_info = {
            number: '4242424242424242',
            expMonth: '12',
            expYear: '2030',
            cvc: '200'
        };
        this.carts = '';
        this.settings = '';
        this.route.params.subscribe(function (params) {
            _this.total_price = params.total_price;
            _this.tax_pay = params.tax_pay;
            _this.shipfee_pay = params.shipfee_pay;
            _this.total_pay = params.total_pay;
            console.log(_this.total_pay);
        });
        this.pay_method = 1;
        this.storage.get('user').then(function (obj) {
            console.log(obj);
            if (obj == null) {
                _this.user_id = null;
            }
            else {
                _this.user_id = obj.id_auth;
                _this.fullname = obj.fullname;
                _this.phone = obj.phone;
                _this.email = obj.email;
            }
        });
        this.storage.ready().then(function () {
            _this.storage.get('cart_list').then(function (data) {
                _this.carts = data;
            });
            _this.storage.get('setting').then(function (data) {
                _this.settings = data;
            });
        });
        this.addressForm = this.formBuilder.group({
            address: ['', forms_1.Validators.compose([forms_1.Validators.minLength(2), forms_1.Validators.required])],
            message: ['']
        });
        this.events.subscribe('user: change', function () {
            _this.ionViewWillEnter();
        });
    }
    CheckoutPage.prototype.ionViewWillEnter = function () {
        var _this = this;
        this.pay_method = 1;
        this.storage.get('user').then(function (obj) {
            console.log(obj);
            if (obj == null) {
                _this.user_id = null;
            }
            else {
                _this.user_id = obj.id_auth;
                _this.fullname = obj.fullname;
                _this.phone = obj.phone;
                _this.email = obj.email;
            }
        });
    };
    CheckoutPage.prototype.presentToast = function () {
        return __awaiter(this, void 0, void 0, function () {
            var toast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            message: 'Se agrego con exito',
                            duration: 2000,
                            position: 'bottom'
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    CheckoutPage.prototype.presentLoading = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = this;
                        return [4 /*yield*/, this.loadingCtrl.create({
                                message: 'Cargando',
                                duration: 2000
                            })];
                    case 1:
                        _a.loading = _b.sent();
                        return [4 /*yield*/, this.loading.present()];
                    case 2: return [2 /*return*/, _b.sent()];
                }
            });
        });
    };
    CheckoutPage.prototype.presentAlertErr = function (err) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            message: err,
                            buttons: [{
                                    text: "Ok",
                                    role: 'cancel'
                                }]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    CheckoutPage.prototype.order = function () {
        if (!this.addressForm.valid) {
            this.validate = false;
            console.log(this.addressForm.value);
        }
        else {
            this.validate = true;
            var data = {
                pay_method: parseInt(this.pay_method),
                email: this.email,
                total_price: this.total_price,
                tax_pay: parseFloat(this.tax_pay),
                shipfee_pay: parseFloat(this.shipfee_pay),
                total_pay: parseFloat(this.total_pay),
                fullname: this.fullname,
                id_user: this.user_id,
                phone: this.phone,
                address: this.addressForm.value.address,
                message: this.addressForm.value.message,
                items: JSON.stringify(this.carts)
            };
            if (this.pay_method == 1) {
                this.order_on_delivery(data);
            }
            if (this.pay_method == 2) {
                this.order_card(data);
            }
            if (this.pay_method == 3) {
                this.order_on_paypal(data);
            }
        }
    };
    CheckoutPage.prototype.order_on_delivery = function (data) {
        var _this = this;
        this.ordersProv.addOrders(data).then(function (val) {
            _this.storage.remove('cart_list').then(function () {
                _this.presentAlertErr('Se agrego la orden con exito!').then(function () {
                    _this.router.navigateByUrl('/home');
                });
            });
        });
    };
    CheckoutPage.prototype.order_card = function (data) {
        var _this = this;
        this.stripe.setPublishableKey(environment_1.environment.stripe_publish_key);
        this.stripe.createCardToken(this.card_info).then(function (token) {
            _this.ordersProv.addOrders(data).then(function (val) {
                _this.storage.remove('cart_list').then(function () {
                    _this.presentAlertErr('Se agrego la orden con exito!').then(function () {
                        _this.router.navigateByUrl('/home');
                    });
                });
            });
        }).catch(function (error) {
            _this.presentAlertErr(error);
        });
    };
    CheckoutPage.prototype.order_on_paypal = function (data) {
        var _this = this;
        this.payPal.init({
            PayPalEnvironmentProduction: environment_1.environment.paypal_live_client_id,
            PayPalEnvironmentSandbox: environment_1.environment.paypal_sandbox_client_id
        }).then(function () {
            _this.payPal.prepareToRender('PayPalEnvironmentSandbox', new ngx_2.PayPalConfiguration({})).then(function () {
                var payment = new ngx_2.PayPalPayment(_this.total_pay, _this.settings.currency_code, 'Description', 'sale');
                _this.payPal.renderSinglePaymentUI(payment).then(function () {
                    _this.ordersProv.addOrders(data).then(function (val) {
                        _this.storage.remove('cart_list').then(function () {
                            _this.presentAlertErr('Se agrego la orden con exito!').then(function () {
                                _this.router.navigateByUrl('/home');
                            });
                        });
                    });
                }, function () {
                });
            }, function () {
            });
        }, function () {
        });
    };
    CheckoutPage = __decorate([
        core_1.Component({
            selector: 'page-checkout',
            template: __webpack_require__(/*! ./checkout.page.html */ "./src/app/checkout/checkout.page.html"),
            styles: [__webpack_require__(/*! ./checkout.page.scss */ "./src/app/checkout/checkout.page.scss")]
        }),
        __metadata("design:paramtypes", [router_1.ActivatedRoute,
            router_1.Router,
            ngx_2.PayPal,
            storage_1.Storage,
            angular_1.ToastController,
            ngx_1.Stripe,
            angular_1.Events,
            forms_1.FormBuilder,
            currencies_1.CurrenciesProvider,
            orders_1.OrdersProvider,
            angular_1.LoadingController,
            angular_1.AlertController])
    ], CheckoutPage);
    return CheckoutPage;
}());
exports.CheckoutPage = CheckoutPage;


/***/ })

}]);
//# sourceMappingURL=checkout-checkout-module.js.map