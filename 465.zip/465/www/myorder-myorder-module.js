(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["myorder-myorder-module"],{

/***/ "./src/app/myorder/myorder.module.ts":
/*!*******************************************!*\
  !*** ./src/app/myorder/myorder.module.ts ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var myorder_page_1 = __webpack_require__(/*! ./myorder.page */ "./src/app/myorder/myorder.page.ts");
var routes = [
    {
        path: '',
        component: myorder_page_1.MyorderPage
    }
];
var MyorderPageModule = /** @class */ (function () {
    function MyorderPageModule() {
    }
    MyorderPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [myorder_page_1.MyorderPage]
        })
    ], MyorderPageModule);
    return MyorderPageModule;
}());
exports.MyorderPageModule = MyorderPageModule;


/***/ }),

/***/ "./src/app/myorder/myorder.page.html":
/*!*******************************************!*\
  !*** ./src/app/myorder/myorder.page.html ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-header>\n\t<ion-toolbar class=\"toolbar\">\n\t\t\t<ion-buttons slot=\"start\">\n\t\t\t\t\t<ion-back-button color=\"light\" defaultHref=\"/home-client\"></ion-back-button>\n\t\t\t\t  </ion-buttons>\n\n\t\t<ion-buttons slot=\"end\">\n\t\t\t\n\t\t\t<ion-button fill=\"clear\" class=\"shadow-0 txt-light\" [routerLink]=\"'/mycart'\" routerDirection=\"forward\">\n\t\t\t\t<ion-icon name=\"cart\"></ion-icon>\n\t\t\t</ion-button>\n\t\t</ion-buttons>\n\n\t\t<ion-title color=\"light\">Mis pedidos</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n\n<ion-content padding class=\"bg-l1\">\n\t<br>\n\t<h2 class=\"uppercase\" *ngIf=\"list_orders_pending.length > 0\">Hay ordenes esperando a ser completadas</h2>\n\t<br>\n\t<div class=\"\" *ngIf=\"list_orders_pending.length > 0\">\n\t\t<div *ngFor=\"let item of list_orders_pending\" class=\"item-order bg-white mgb-20 shadow-2\" padding>\n\t\t\t<div class=\"top\">\n\t\t\t\t<p class=\"txt-b1 fw-600\">Orden #{{item.payload.doc.id}}</p>\n\t\t\t\t<p text-right class=\"txt-b3\">{{item.payload.doc.data().created.substring(4, 15)}}</p>\n\t\t\t</div>\n\t\t\t<!-- <p class=\"txt-b1 fw-600 mgt-0 txt-warning pd-2 bg-black-3 pdl-10\">\n\t\t\t\t<ion-icon class=\"mgr-5 txt-warning\" name=\"card\"></ion-icon>\n\t\t\t\tEnvio pendiente\n\t\t\t</p> -->\n\t\t\t<hr/>\n\t\t\t<div class=\"-wrap-prd\">\n\t\t\t\t<div *ngFor=\"let elmt of item.lst_items\" class=\"elm-prd\" [routerLink]=\"['/detail', {id_item: elmt.id}]\">\n\t\t\t\t\t<h4 class=\"fs-14 mgb-0 name\">{{elmt.name}}</h4>\n\t\t\t\t\t<p class=\"txt-b3 quantity\">x {{elmt.quantity}}</p>\n\t\t\t\t\t<p class=\"txt-b3 price\" text-right>{{currenciesProv.formatMoney(elmt.price)}} {{(elmt.discount > 0)? '(-'+ elmt.discount +'%)' : null}}</p>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t\t<br>\n\t\t\t<div class=\"bottom\">\n\t\t\t\t<p class=\"txt-b3\">\n\t\t\t\t\t<ion-icon name=\"ios-pin\"></ion-icon>\n\t\t\t\t\t{{item.payload.doc.data().address}}\n\t\t\t\t</p>\n\t\t\t\t<hr/>\n\t\t\t\t<p class=\"txt-b3 mg-0\">\n\t\t\t\t\tDespues de impuesto aplicado: \n\t\t\t\t\t<strong class=\"txt-b1 pull-right\" text-right>{{currenciesProv.formatMoney(item.payload.doc.data().total_price)}}</strong>\n\t\t\t\t</p>\n\t\t\t\t<p class=\"txt-b3 mg-0\">\n\t\t\t\t\tImpuesto ({{settings.tax_fee}}%): \n\t\t\t\t\t<strong class=\"txt-b1 pull-right\" text-right>{{currenciesProv.formatMoney(item.payload.doc.data().tax_pay)}}</strong>\n\t\t\t\t</p>\n\t\t\t\t<p class=\"txt-b3 mg-0\">\n\t\t\t\t\tTarifa de envio ({{currenciesProv.formatMoney(settings.ship_fee)}}): \n\t\t\t\t\t<strong class=\"txt-b1 pull-right\" text-right>{{currenciesProv.formatMoney(item.payload.doc.data().shipfee_pay)}}</strong>\n\t\t\t\t</p>\n\t\t\t\t<p class=\"txt-b3 fs-18\">\n\t\t\t\t\tTotal: \n\t\t\t\t\t<strong class=\"txt-b1 pull-right\" text-right>{{currenciesProv.formatMoney(item.payload.doc.data().total_pay)}}</strong>\n\t\t\t\t</p>\n\t\t\t</div>\n\t\t\t<div class=\"\" text-right>\n\t\t\t\t<hr class=\"bg-light\">\n\t\t\t\t<p class=\"txt1 italic fw-600\" *ngIf=\"item.payload.doc.data().pay_method == 1\">Pago a la entrega</p>\n\t\t\t\t<p class=\"txt1 italic fw-600\" *ngIf=\"item.payload.doc.data().pay_method == 2\">Pago por tarjeta de credito</p>\n\t\t\t\t<p class=\"txt1 italic fw-600\" *ngIf=\"item.payload.doc.data().pay_method == 3\">Pagar utilizando Paypal</p>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n\n\t<br>\n\t<h2 class=\"uppercase\" *ngIf=\"list_orders_success.length > 0\">10 ordenes mas recientes</h2>\n\t<br>\n\n\t<div class=\"\" *ngIf=\"list_orders_success.length > 0\">\n\t\t<div *ngFor=\"let item of list_orders_success\" class=\"item-order bg-white mgb-20 shadow-2\" padding>\n\t\t\t<div class=\"top\">\n\t\t\t\t<p class=\"txt-b1 fw-600\">Orden #{{item.payload.doc.id}}</p>\n\t\t\t\t<p text-right class=\"txt-b3\">{{item.payload.doc.data().created.substring(4, 15)}}</p>\n\t\t\t</div>\n\t\t\t<p class=\"txt-b1 fw-600 mgt-0 txt-success pd-2 bg-black-3 pdl-10\">\n\t\t\t\t<ion-icon class=\"mgr-5 txt-success\" name=\"card\"></ion-icon>\n\t\t\t\tExitoso\n\t\t\t</p>\n\t\t\t<hr/>\n\t\t\t<div class=\"-wrap-prd\">\n\t\t\t\t<div *ngFor=\"let elmt of item.lst_items\" class=\"elm-prd\">\n\t\t\t\t\t<h4 class=\"fs-14 mgb-0 name\">{{elmt.name}}</h4>\n\t\t\t\t\t<p class=\"txt-b3 quantity\">x {{elmt.quantity}}</p>\n\t\t\t\t\t<p class=\"txt-b3 price\" text-right>{{currenciesProv.formatMoney(elmt.price)}}{{(elmt.discount > 0)? '(-'+ elmt.discount +'%)' : null}}</p>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t\t<br>\n\t\t\t<div class=\"bottom\">\n\t\t\t\t<p class=\"txt-b3\">\n\t\t\t\t\t<ion-icon name=\"ios-pin\"></ion-icon>\n\t\t\t\t\t{{item.payload.doc.data().address}}\n\t\t\t\t</p>\n\t\t\t\t<hr/>\n\t\t\t\t<p class=\"txt-b3 mg-0\">\n\t\t\t\t\tDespues del impuesto aplicado: \n\t\t\t\t\t<strong class=\"txt-b1 pull-right\" text-right>{{currenciesProv.formatMoney(item.payload.doc.data().total_price)}}</strong>\n\t\t\t\t</p>\n\t\t\t\t<p class=\"txt-b3 mg-0\">\n\t\t\t\t\tImpuesto ({{settings.tax_fee}}%): \n\t\t\t\t\t<strong class=\"txt-b1 pull-right\" text-right>{{currenciesProv.formatMoney(item.payload.doc.data().tax_fee)}}</strong>\n\t\t\t\t</p>\n\t\t\t\t<p class=\"txt-b3 mg-0\">\n\t\t\t\t\tTarifa de envio ({{currenciesProv.formatMoney(settings.ship_fee)}}): \n\t\t\t\t\t<strong class=\"txt-b1 pull-right\" text-right>{{currenciesProv.formatMoney(item.payload.doc.data().shipfee_pay)}}</strong>\n\t\t\t\t</p>\n\t\t\t\t<p class=\"txt-b3 fs-18\">\n\t\t\t\t\tTotal: \n\t\t\t\t\t<strong class=\"txt-b1 pull-right\" text-right>{{currenciesProv.formatMoney(item.payload.doc.data().total_pay)}}</strong>\n\t\t\t\t</p>\n\t\t\t</div>\n\t\t\t<div class=\"\" text-right>\n\t\t\t\t<hr class=\"bg-light\">\n\t\t\t\t<p class=\"txt1 italic fw-600\" *ngIf=\"item.payload.doc.data().pay_method == 1\">Payment on delivery</p>\n\t\t\t\t<p class=\"txt1 italic fw-600\" *ngIf=\"item.payload.doc.data().pay_method == 2\">Payment by credit card</p>\n\t\t\t\t<p class=\"txt1 italic fw-600\" *ngIf=\"item.payload.doc.data().pay_method == 3\">Payment use Paypal</p>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/myorder/myorder.page.scss":
/*!*******************************************!*\
  !*** ./src/app/myorder/myorder.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".item-order {\n  border-top: 12px dotted var(--ion-background-color);\n  border-bottom: 12px dotted var(--ion-background-color); }\n  .item-order .top {\n    display: flex;\n    align-items: center; }\n  .item-order .top p {\n      flex: 1; }\n  .item-order .elm-prd {\n    display: flex;\n    align-items: center; }\n  .item-order .elm-prd .name {\n      flex: 3; }\n  .item-order .elm-prd .quantity {\n      flex: 1; }\n  .item-order .elm-prd .price {\n      flex: 1; }\n  .toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbXlvcmRlci9DOlxcVXNlcnNcXGFsZXhhXFxEZXNrdG9wXFxGaW5hbC9zcmNcXGFwcFxcbXlvcmRlclxcbXlvcmRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyxtREFBbUQ7RUFDbkQsc0RBQXNELEVBQUE7RUFGdkQ7SUFJRSxhQUFhO0lBQ2IsbUJBQW1CLEVBQUE7RUFMckI7TUFPRyxPQUFPLEVBQUE7RUFQVjtJQVdFLGFBQWE7SUFDYixtQkFBbUIsRUFBQTtFQVpyQjtNQWNHLE9BQU8sRUFBQTtFQWRWO01BaUJHLE9BQU8sRUFBQTtFQWpCVjtNQW9CRyxPQUFPLEVBQUE7RUFRVjtFQUVJLHNGQUFhLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9teW9yZGVyL215b3JkZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLml0ZW0tb3JkZXJ7XG5cdGJvcmRlci10b3A6IDEycHggZG90dGVkIHZhcigtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yKTtcblx0Ym9yZGVyLWJvdHRvbTogMTJweCBkb3R0ZWQgdmFyKC0taW9uLWJhY2tncm91bmQtY29sb3IpO1xuXHQudG9we1xuXHRcdGRpc3BsYXk6IGZsZXg7XG5cdFx0YWxpZ24taXRlbXM6IGNlbnRlcjtcblx0XHRwe1xuXHRcdFx0ZmxleDogMTtcblx0XHR9XG5cdH1cblx0LmVsbS1wcmR7XG5cdFx0ZGlzcGxheTogZmxleDtcblx0XHRhbGlnbi1pdGVtczogY2VudGVyO1xuXHRcdC5uYW1le1xuXHRcdFx0ZmxleDogMztcblx0XHR9XG5cdFx0LnF1YW50aXR5e1xuXHRcdFx0ZmxleDogMTtcblx0XHR9XG5cdFx0LnByaWNle1xuXHRcdFx0ZmxleDogMTtcblx0XHR9XG5cdH1cblx0LmJvdHRvbXtcblxuXHR9XG59XG5cbi50b29sYmFyIHtcbiAgIFxuICAgIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgdmFyKC0taW9uLWNvbG9yLWRhcmspLCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkpO1xuICAgICAgICBcbiAgfVxuICAgIl19 */"

/***/ }),

/***/ "./src/app/myorder/myorder.page.ts":
/*!*****************************************!*\
  !*** ./src/app/myorder/myorder.page.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var orders_1 = __webpack_require__(/*! ../../providers/orders */ "./src/providers/orders.ts");
var currencies_1 = __webpack_require__(/*! ../../providers/currencies */ "./src/providers/currencies.ts");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
var MyorderPage = /** @class */ (function () {
    function MyorderPage(currenciesProv, ordersProv, storage, loadingCtrl) {
        var _this = this;
        this.currenciesProv = currenciesProv;
        this.ordersProv = ordersProv;
        this.storage = storage;
        this.loadingCtrl = loadingCtrl;
        this.list_orders_success = [];
        this.list_orders_pending = [];
        this.presentLoading();
        this.storage.get('setting').then(function (data) {
            _this.settings = data;
        });
        this.storage.get('user').then(function (obj) {
            console.log(obj);
            if (obj == null) {
                _this.user_id = null;
            }
            else {
                _this.user_id = obj.id_auth;
                _this.ordersProv.getOrdersPending(_this.user_id).then(function (data) {
                    _this.list_orders_pending = data;
                    for (var i = 0; i < data.length; ++i) {
                        _this.list_orders_pending[i]['lst_items'] = JSON.parse(data[i].payload.doc.data().items);
                    }
                    console.log(_this.list_orders_pending);
                });
                _this.ordersProv.getOrdersSuccess(_this.user_id, 10).then(function (data) {
                    _this.loading.dismiss().then(function () {
                        _this.list_orders_success = data;
                        for (var i = 0; i < data.length; ++i) {
                            _this.list_orders_success[i]['lst_items'] = JSON.parse(data[i].payload.doc.data().items);
                        }
                    });
                    console.log(_this.list_orders_success);
                });
            }
        });
    }
    MyorderPage.prototype.presentLoading = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = this;
                        return [4 /*yield*/, this.loadingCtrl.create({
                                message: 'Cargando',
                                duration: 2000
                            })];
                    case 1:
                        _a.loading = _b.sent();
                        return [4 /*yield*/, this.loading.present()];
                    case 2: return [2 /*return*/, _b.sent()];
                }
            });
        });
    };
    MyorderPage.prototype.ionViewWillEnter = function () {
    };
    MyorderPage.prototype.ngOnInit = function () {
    };
    MyorderPage = __decorate([
        core_1.Component({
            selector: 'app-myorder',
            template: __webpack_require__(/*! ./myorder.page.html */ "./src/app/myorder/myorder.page.html"),
            styles: [__webpack_require__(/*! ./myorder.page.scss */ "./src/app/myorder/myorder.page.scss")]
        }),
        __metadata("design:paramtypes", [currencies_1.CurrenciesProvider,
            orders_1.OrdersProvider,
            storage_1.Storage,
            angular_1.LoadingController])
    ], MyorderPage);
    return MyorderPage;
}());
exports.MyorderPage = MyorderPage;


/***/ })

}]);
//# sourceMappingURL=myorder-myorder-module.js.map