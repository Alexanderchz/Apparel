(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["favorites-favorites-module"],{

/***/ "./src/app/favorites/favorites.module.ts":
/*!***********************************************!*\
  !*** ./src/app/favorites/favorites.module.ts ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var favorites_page_1 = __webpack_require__(/*! ./favorites.page */ "./src/app/favorites/favorites.page.ts");
var routes = [
    {
        path: '',
        component: favorites_page_1.FavoritesPage
    }
];
var FavoritesPageModule = /** @class */ (function () {
    function FavoritesPageModule() {
    }
    FavoritesPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [favorites_page_1.FavoritesPage]
        })
    ], FavoritesPageModule);
    return FavoritesPageModule;
}());
exports.FavoritesPageModule = FavoritesPageModule;


/***/ }),

/***/ "./src/app/favorites/favorites.page.html":
/*!***********************************************!*\
  !*** ./src/app/favorites/favorites.page.html ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\t<ion-toolbar class=\"toolbar\">\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-menu-button>\n\t\t\t\t<ion-icon color=\"light\" name=\"ios-arrow-round-forward\"></ion-icon>\n\t\t\t</ion-menu-button>\n\t\t</ion-buttons>\n\n\t\t<ion-buttons slot=\"end\">\n\t\t\n\t\t\t<ion-button fill=\"clear\" class=\"shadow-0 txt-light\" [routerLink]=\"'/mycart'\" routerDirection=\"forward\">\n\t\t\t\t<ion-icon name=\"cart\"></ion-icon>\n\t\t\t</ion-button>\n\t\t</ion-buttons>\n\n\t\t<ion-title color=\"light\">Favoritos</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\n\t<div padding class=\"pdr-50\">\n\t\t<h2 class=\"uppercase pdr-50\">Aqui se encuentran los productos que te encantaron!</h2>\n\t</div>\n\n\t<div class=\"\" *ngIf=\"list_favo_product == null || list_favo_product.length == 0 || !list_favo_product\">\n\t\t<h5 class=\"pdl-15 pdr-50 uppercase spacing-1 fs-14\">Aun no tienes productos que te gusten :(</h5>\n\t</div>\n\t<div class=\"\" *ngIf=\"list_favo_product && list_favo_product.length > 0\">\n\t\t<div class=\"wrap-top-slide\">\n\t\t\t<ion-slides>\n\t\t\t\t<ion-slide *ngFor=\"let item of list_favo_product_slide\" [routerLink]=\"['/detail', {id_item: item.payload.doc.id}]\">\n\t\t\t\t\t<div text-left class=\"item-slide\">\n\t\t\t\t\t\t<div class=\"thumb flex-row flex-jus-center flex-ali-center\">\n\t\t\t\t\t\t\t<img src=\"{{item.payload.doc.data().thumb}}\">\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</div>\n\t\t\t\t</ion-slide>\n\t\t\t</ion-slides>\n\t\t</div>\n\n\t\t<br>\n\t\t<br>\n\n\t\t<h5 class=\"pdl-15 pdr-50 uppercase spacing-1 fs-14\"></h5>\n\t\t\n\t\t<br>\n\n\t\t<div class=\"list-prd-list\" *ngIf=\"list_favo_product.length > 0\">\n\t\t\t<div class=\"item-prd mgb-20 pdb-15\" *ngFor=\"let item of list_favo_product, let i = imdex\">\n\t\t\t\t<div class=\"thumb mgr-10\" [routerLink]=\"['/detail', {id_item: item.payload.doc.id}]\">\n\t\t\t\t\t<img src=\"{{item.payload.doc.data().thumb}}\">\n\t\t\t\t</div>\n\t\t\t\t<div class=\"\">\n\t\t\t\t\t<div class=\"ovfl-hidden\" [routerLink]=\"['/detail', {id_item: item.payload.doc.id}]\">\n\t\t\t\t\t\t<h4 class=\"fs-16 fw-600 ellipsis mg-0\">{{item.payload.doc.data().name}}</h4>\n\t\t\t\t\t\t<p class=\"mg-0\">\n\t\t\t\t\t\t\t<span class=\"ellipsis fs-14 txt3 mg-0 line-through mgr-10 fw-600\" *ngIf=\"currenciesProv && item.payload.doc.data().discount > 0\">\n\t\t\t\t\t\t\t\t<i *ngIf=\"currenciesProv\">\n\t\t\t\t\t\t\t\t\t{{currenciesProv.formatMoney(item.payload.doc.data().price)}}\n\t\t\t\t\t\t\t\t</i>\n\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t\t<span class=\"ellipsis fs-14 txt1 mg-0 fw-600\" *ngIf=\"currenciesProv && item.payload.doc.data().discount > 0\">\n\t\t\t\t\t\t\t\t{{currenciesProv.formatMoney(item.payload.doc.data().price - item.payload.doc.data().price*item.payload.doc.data().discount/100)}}\n\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t\t<span class=\"ellipsis fs-14 txt1 mg-0 fw-600\" *ngIf=\"currenciesProv && item.payload.doc.data().discount == 0\">\n\t\t\t\t\t\t\t\t{{currenciesProv.formatMoney(item.payload.doc.data().price)}}\n\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t</p>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class=\"mgt-5\">\n\t\t\t\t\t\t<ion-button size=\"small\" (click)=\"addCart(item)\" class=\"fs-11 bdra-0 fw-600\">\n\t\t\t\t\t\t\t<ion-icon name=\"ios-cart\"></ion-icon>\n\t\t\t\t\t\t\tAgregar al carrito\n\t\t\t\t\t\t</ion-button>\n\t\t\t\t\t\t<ion-button size=\"small\" color=\"primary\" class=\"fs-11 bdra-0\" *ngIf=\"favo_str.search(item.payload.doc.id) > -1\" (click)=\"favorites(item)\">\n\t\t\t\t\t\t\t<ion-icon name=\"ios-heart\"></ion-icon>\n\t\t\t\t\t\t</ion-button>\n\t\t\t\t\t\t<ion-button size=\"small\" color=\"dark\" class=\"fs-11 bdra-0\" *ngIf=\"favo_str.search(item.payload.doc.id) < 0\" (click)=\"favorites(item)\">\n\t\t\t\t\t\t\t<ion-icon name=\"ios-heart\"></ion-icon>\n\t\t\t\t\t\t</ion-button>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n\n\t<ion-infinite-scroll (ionInfinite)=\"loadMore($event)\">\n\t\t<ion-infinite-scroll-content></ion-infinite-scroll-content>\n\t</ion-infinite-scroll>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/favorites/favorites.page.scss":
/*!***********************************************!*\
  !*** ./src/app/favorites/favorites.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".wrap-top-slide {\n  width: 130%; }\n  .wrap-top-slide .thumb {\n    height: 100px; }\n  .list-prd-list .item-prd {\n  display: flex;\n  align-items: center;\n  border-bottom: 1px solid #ebebeb; }\n  .list-prd-list .item-prd .thumb {\n    height: 80px;\n    width: 90px; }\n  .toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZmF2b3JpdGVzL0M6XFxVc2Vyc1xcYWxleGFcXERlc2t0b3BcXEZpbmFsL3NyY1xcYXBwXFxmYXZvcml0ZXNcXGZhdm9yaXRlcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyxXQUFXLEVBQUE7RUFEWjtJQUdFLGFBQWEsRUFBQTtFQUdmO0VBRUUsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQixnQ0FBZ0MsRUFBQTtFQUpsQztJQU1HLFlBQVk7SUFDWixXQUFXLEVBQUE7RUFLZDtFQUVJLHNGQUFhLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9mYXZvcml0ZXMvZmF2b3JpdGVzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi53cmFwLXRvcC1zbGlkZXtcblx0d2lkdGg6IDEzMCU7XG5cdC50aHVtYntcblx0XHRoZWlnaHQ6IDEwMHB4O1xuXHR9XG59XG4ubGlzdC1wcmQtbGlzdHtcblx0Lml0ZW0tcHJke1xuXHRcdGRpc3BsYXk6IGZsZXg7XG5cdFx0YWxpZ24taXRlbXM6IGNlbnRlcjtcblx0XHRib3JkZXItYm90dG9tOiAxcHggc29saWQgI2ViZWJlYjtcblx0XHQudGh1bWJ7XG5cdFx0XHRoZWlnaHQ6IDgwcHg7XG5cdFx0XHR3aWR0aDogOTBweDtcblx0XHR9XG5cdH1cbn1cblxuLnRvb2xiYXIge1xuICAgXG4gICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCB2YXIoLS1pb24tY29sb3ItZGFyayksIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSk7XG4gICAgICAgIFxuICB9Il19 */"

/***/ }),

/***/ "./src/app/favorites/favorites.page.ts":
/*!*********************************************!*\
  !*** ./src/app/favorites/favorites.page.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
var products_1 = __webpack_require__(/*! ../../providers/products */ "./src/providers/products.ts");
var favorites_1 = __webpack_require__(/*! ../../providers/favorites */ "./src/providers/favorites.ts");
var currencies_1 = __webpack_require__(/*! ../../providers/currencies */ "./src/providers/currencies.ts");
var FavoritesPage = /** @class */ (function () {
    function FavoritesPage(events, toastCtrl, loadingCtrl, productsProv, storage, favoritesProv, currenciesProv) {
        var _this = this;
        this.events = events;
        this.toastCtrl = toastCtrl;
        this.loadingCtrl = loadingCtrl;
        this.productsProv = productsProv;
        this.storage = storage;
        this.favoritesProv = favoritesProv;
        this.currenciesProv = currenciesProv;
        this.list_favo_product = [];
        this.list_favo_product_slide = [];
        this.limit = 4;
        this.start = 0;
        this.favo_str = '';
        this.presentLoading();
        this.storage.get('user').then(function (val) {
            _this.id_user = val.id_auth;
            _this.favoritesProv.getByUserId(_this.id_user).then(function (data) {
                if (data.length > 0) {
                    _this.favo_str = data[0].payload.doc.data().id_product;
                    _this.id_favo_str = data[0].payload.doc.id;
                    _this.favo_id_arr = _this.favo_str.split(' ');
                    console.log(data);
                    for (var i = _this.start; i < _this.limit && i < _this.favo_id_arr.length; i++) {
                        _this.favoritesProv.getFavoByIdPd(_this.favo_id_arr[i]).then(function (dataProduct) {
                            _this.loading.dismiss().then(function () {
                                console.log(dataProduct);
                                if (dataProduct.length > 0) {
                                    _this.list_favo_product = _this.list_favo_product.concat(dataProduct);
                                    _this.start = _this.start + 1;
                                }
                            });
                        }, function (error) {
                        });
                    }
                    console.log(_this.favo_id_arr);
                }
            });
        });
        this.storage.get('cart_list').then(function (val) {
            if (!val || val == null) {
                _this.list_cart = new Array();
            }
            else {
                _this.list_cart = val;
            }
            console.log(_this.list_cart);
        });
        this.events.subscribe('cart_list: change', function (lst) {
            _this.list_cart = lst;
        });
    }
    FavoritesPage.prototype.presentLoading = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = this;
                        return [4 /*yield*/, this.loadingCtrl.create({
                                message: 'Cargando',
                                duration: 2000
                            })];
                    case 1:
                        _a.loading = _b.sent();
                        return [4 /*yield*/, this.loading.present()];
                    case 2: return [2 /*return*/, _b.sent()];
                }
            });
        });
    };
    FavoritesPage.prototype.ionViewWillEnter = function () {
    };
    FavoritesPage.prototype.loadMore = function (event) {
        var _this = this;
        var count = this.start;
        for (var i = this.start; i < this.favo_id_arr.length; i++) {
            if (this.start - count < this.limit) {
                this.favoritesProv.getFavoByIdPd(this.favo_id_arr[i]).then(function (data) {
                    if (data.length > 0) {
                        _this.list_favo_product = _this.list_favo_product.concat(data);
                        _this.start = _this.start + 1;
                    }
                    else {
                        setTimeout(function () {
                            event.target.disabled = true;
                        }, 1500);
                    }
                }, function (error) {
                    setTimeout(function () {
                        event.target.disabled = true;
                    }, 1500);
                });
            }
            else {
                setTimeout(function () {
                    event.target.disabled = true;
                }, 1500);
                break;
            }
        }
    };
    FavoritesPage.prototype.favorites = function (item, i) {
        var _this = this;
        console.log(item.payload.doc.id);
        this.favo_str = this.favo_str.replace(item.payload.doc.id + ' ', '');
        this.favoritesProv.favoritesAdd(this.favo_str, this.id_user, this.id_favo_str).then(function (data) {
            _this.list_favo_product.splice(i, 1);
            console.log(_this.list_favo_product);
        });
    };
    FavoritesPage.prototype.addCart = function (item) {
        console.log(item);
        var itemCv = {
            id: item.payload.doc.id,
            name: item.payload.doc.data().name,
            price: item.payload.doc.data().price,
            discount: item.payload.doc.data().discount,
            description: item.payload.doc.data().description,
            vote: item.payload.doc.data().vote,
            created: item.payload.doc.data().created,
            id_cat: item.payload.doc.data().id_cat,
            tag: item.payload.doc.data().tag,
            thumb: item.payload.doc.data().thumb,
            thumb1: item.payload.doc.data().thumb1,
            thumb2: item.payload.doc.data().thumb2,
            thumb3: item.payload.doc.data().thumb3,
            thumb4: item.payload.doc.data().thumb4,
            quantity: 1
        };
        var temp = this.list_cart.filter(function (element) {
            if (element.id == itemCv.id) {
                element.quantity = 1 + element.quantity;
                return true;
            }
        });
        console.log(temp);
        if (temp.length == 0) {
            this.list_cart = this.list_cart.concat(itemCv);
        }
        this.presentToast();
        // this.list_cart = new Array();
        this.events.publish('cart_list: change', this.list_cart);
        this.storage.set('cart_list', this.list_cart);
        console.log(this.list_cart);
    };
    FavoritesPage.prototype.presentToast = function () {
        return __awaiter(this, void 0, void 0, function () {
            var toast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            message: 'Se agrego con exito',
                            duration: 2000,
                            position: 'bottom'
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    FavoritesPage.prototype.ngOnInit = function () {
    };
    FavoritesPage = __decorate([
        core_1.Component({
            selector: 'app-favorites',
            template: __webpack_require__(/*! ./favorites.page.html */ "./src/app/favorites/favorites.page.html"),
            styles: [__webpack_require__(/*! ./favorites.page.scss */ "./src/app/favorites/favorites.page.scss")]
        }),
        __metadata("design:paramtypes", [angular_1.Events,
            angular_1.ToastController,
            angular_1.LoadingController,
            products_1.ProductsProvider,
            storage_1.Storage,
            favorites_1.FavoritesProvider,
            currencies_1.CurrenciesProvider])
    ], FavoritesPage);
    return FavoritesPage;
}());
exports.FavoritesPage = FavoritesPage;


/***/ })

}]);
//# sourceMappingURL=favorites-favorites-module.js.map