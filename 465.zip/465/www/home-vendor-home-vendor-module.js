(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-vendor-home-vendor-module"],{

/***/ "./src/app/home-vendor/home-vendor.module.ts":
/*!***************************************************!*\
  !*** ./src/app/home-vendor/home-vendor.module.ts ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var home_vendor_page_1 = __webpack_require__(/*! ./home-vendor.page */ "./src/app/home-vendor/home-vendor.page.ts");
var routes = [
    {
        path: '',
        component: home_vendor_page_1.HomeVendorPage
    }
];
var HomeVendorPageModule = /** @class */ (function () {
    function HomeVendorPageModule() {
    }
    HomeVendorPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [home_vendor_page_1.HomeVendorPage]
        })
    ], HomeVendorPageModule);
    return HomeVendorPageModule;
}());
exports.HomeVendorPageModule = HomeVendorPageModule;


/***/ }),

/***/ "./src/app/home-vendor/home-vendor.page.html":
/*!***************************************************!*\
  !*** ./src/app/home-vendor/home-vendor.page.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"secondary\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>\n      <ion-text color=\"light\">\n        <ion-text color=\"light\" class=\"fw700\">Apparel Designer</ion-text>\n      </ion-text>\n\n      <ion-label>{{user.username}}</ion-label>\n\n    </ion-title>\n    <ion-buttons slot=\"end\">  \n      <ion-buttons slot=\"end\">\n\n      </ion-buttons>\n    </ion-buttons>\n  </ion-toolbar>\n\n</ion-header>\n\n<div class=\"logoContainer\">\n  <img\n    src=\"https://library.kissclipart.com/20180904/kcw/kissclipart-sewing-machine-vector-clipart-sewing-machines-clip-ad232945c9e04e8d.jpg\"\n    class=\"logo\">\n</div>\n\n\n\n<ion-content>\n\n  <ion-button margin shape=\"round\" expand=\"full\" color=\"secondary\" (click)=\"addProduct()\">\n    Agregar producto\n  </ion-button>\n\n  <ion-button margin shape=\"round\" expand=\"full\" color=\"secondary\" (click)=\"myProducts()\">\n    Mis productos\n  </ion-button>\n\n  <ion-button margin shape=\"round\" expand=\"full\" color=\"secondary\" (click)=\"ordersToAttend()\">\n    Mis ordenes a atender\n  </ion-button>\n\n  <ion-button margin shape=\"round\" expand=\"full\" color=\"secondary\" (click)=\"logout()\">\n    Salir\n  </ion-button>\n\n\n\n\n</ion-content>"

/***/ }),

/***/ "./src/app/home-vendor/home-vendor.page.scss":
/*!***************************************************!*\
  !*** ./src/app/home-vendor/home-vendor.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n.logoContainer {\n  background-color: var(--ion-color-light); }\n\n.logoContainer .logo {\n    width: 100px;\n    height: 100px;\n    margin: 10px auto 8px;\n    background-size: 50%;\n    margin-left: 35%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS12ZW5kb3IvQzpcXFVzZXJzXFxhbGV4YVxcRGVza3RvcFxcRmluYWwvc3JjXFxhcHBcXGhvbWUtdmVuZG9yXFxob21lLXZlbmRvci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxzRkFBYSxFQUFBOztBQUlmO0VBU0ssd0NBQXdDLEVBQUE7O0FBVDdDO0lBRU0sWUFBWTtJQUNaLGFBQWE7SUFDYixxQkFBcUI7SUFDckIsb0JBQW9CO0lBQ3JCLGdCQUFnQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvaG9tZS12ZW5kb3IvaG9tZS12ZW5kb3IucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXIgeyAgXHJcbiAgICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsIHZhcigtLWlvbi1jb2xvci1kYXJrKSwgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpKTsgICAgICBcclxuICB9XHJcblxyXG5cclxuICAubG9nb0NvbnRhaW5lcntcclxuICAgIC5sb2dvIHtcclxuICAgICAgICB3aWR0aDogMTAwcHg7XHJcbiAgICAgICAgaGVpZ2h0OiAxMDBweDtcclxuICAgICAgICBtYXJnaW46IDEwcHggYXV0byA4cHg7XHJcbiAgICAgICAgYmFja2dyb3VuZC1zaXplOiA1MCU7XHJcbiAgICAgICBtYXJnaW4tbGVmdDogMzUlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gICAgXHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/home-vendor/home-vendor.page.ts":
/*!*************************************************!*\
  !*** ./src/app/home-vendor/home-vendor.page.ts ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var users_1 = __webpack_require__(/*! src/providers/users */ "./src/providers/users.ts");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
var HomeVendorPage = /** @class */ (function () {
    function HomeVendorPage(router, usersProv, menuCtrl, events, storage) {
        this.router = router;
        this.usersProv = usersProv;
        this.menuCtrl = menuCtrl;
        this.events = events;
        this.storage = storage;
    }
    HomeVendorPage.prototype.ngOnInit = function () {
        var _this = this;
        this.storage.ready().then(function () {
            _this.storage.get('user').then(function (val) {
                if (val != null) {
                    _this.user = val;
                }
            });
        });
    };
    HomeVendorPage.prototype.addProduct = function () {
        return this.router.navigateRoot('/add-product');
    };
    HomeVendorPage.prototype.ordersToAttend = function () {
        return this.router.navigateRoot('/orderstoattend');
    };
    HomeVendorPage.prototype.myProducts = function () {
        return this.router.navigateRoot('/myproducts');
    };
    HomeVendorPage.prototype.logout = function () {
        var _this = this;
        this.usersProv.logoutUser().then(function () {
            _this.user = null;
            _this.router.navigateForward('/login');
            _this.menuCtrl.enable(false);
        });
    };
    HomeVendorPage = __decorate([
        core_1.Component({
            selector: 'app-home-vendor',
            template: __webpack_require__(/*! ./home-vendor.page.html */ "./src/app/home-vendor/home-vendor.page.html"),
            styles: [__webpack_require__(/*! ./home-vendor.page.scss */ "./src/app/home-vendor/home-vendor.page.scss")]
        }),
        __metadata("design:paramtypes", [angular_1.NavController, users_1.UsersProvider, angular_1.MenuController, angular_1.Events, storage_1.Storage])
    ], HomeVendorPage);
    return HomeVendorPage;
}());
exports.HomeVendorPage = HomeVendorPage;


/***/ })

}]);
//# sourceMappingURL=home-vendor-home-vendor-module.js.map