(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["list-list-module"],{

/***/ "./src/app/list/list.module.ts":
/*!*************************************!*\
  !*** ./src/app/list/list.module.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var list_page_1 = __webpack_require__(/*! ./list.page */ "./src/app/list/list.page.ts");
var ListPageModule = /** @class */ (function () {
    function ListPageModule() {
    }
    ListPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild([
                    {
                        path: '',
                        component: list_page_1.ListPage
                    }
                ])
            ],
            declarations: [list_page_1.ListPage]
        })
    ], ListPageModule);
    return ListPageModule;
}());
exports.ListPageModule = ListPageModule;


/***/ }),

/***/ "./src/app/list/list.page.html":
/*!*************************************!*\
  !*** ./src/app/list/list.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n   <ion-buttons slot=\"start\">\n    <ion-back-button class=\"fs-24 txt1\" text=\"\" icon=\"ios-arrow-round-back\"></ion-back-button>\n  </ion-buttons>\n\n  <ion-buttons slot=\"end\">\n    <ion-button fill=\"clear\" class=\"shadow-0 txt1\" [routerLink]=\"'/search'\" routerDirection=\"forward\">\n      <ion-icon name=\"search\"></ion-icon>\n    </ion-button>\n    <ion-button fill=\"clear\" class=\"shadow-0 txt1\" [routerLink]=\"'/mycart'\" routerDirection=\"forward\">\n      <ion-icon name=\"cart\"></ion-icon>\n    </ion-button>\n  </ion-buttons>\n\n  <ion-title>List</ion-title>\n</ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n  <div class=\"wrap-top-slide\" *ngIf=\"list_slide_product.length > 0\">\n    <ion-slides spaceBetween=\"10\" loop=\"true\">\n      <ion-slide *ngFor=\"let item of list_slide_product\">\n        <div text-left class=\"item-slide\" [routerLink]=\"['/detail', {id_item: item.payload.doc.id}]\">\n          <div class=\"thumb ovfl-hidden flex-row flex-ali-center flex-jus-center\">\n            <img src=\"{{item.payload.doc.data().thumb}}\">\n          </div>\n        </div>\n      </ion-slide>\n    </ion-slides>\n  </div>\n\n  <br/>\n\n  <div class=\"ovfl-hidden\">\n    <div class=\"wrap-slides-cat\" *ngIf=\"list_cat.length > 0\">\n      <ion-slides [options]=\"slidePerViewOpts\">\n        <ion-slide *ngFor=\"let item of list_cat\" [routerLink]=\"['/list', {id: item.payload.doc.id, name: item.payload.doc.data().name}]\">\n          <div class=\"mini-cat shadow-2\">\n            <img src=\"{{item.payload.doc.data().thumb}}\">\n            <h6 text-center class=\"mg-0 flex-row flex-jus-start flex-ali-end txt-light pd-10 capitalize\">{{item.payload.doc.data().name}}</h6>\n          </div>\n        </ion-slide>\n      </ion-slides>\n    </div>\n  </div>\n\n  <br>\n\n  <div class=\"top-action\">\n    <h6 no-margin class=\"uppercase spacing-1\">{{obj.name}}</h6>\n    <div text-right class=\"\">\n      <ion-button fill=\"clear\" shape=\"round\" (click)=\"u_list(true)\" [ngClass]=\"(u_grid == true)? 'txt-base' : 'txt4'\">\n        <ion-icon name=\"md-apps\"></ion-icon>\n      </ion-button>\n      <ion-button fill=\"clear\" shape=\"round\" (click)=\"u_list(false)\" [ngClass]=\"(u_grid == false)? 'txt-base' : 'txt4'\">\n        <ion-icon name=\"md-list\"></ion-icon>\n      </ion-button>\n    </div>\n  </div>\n\n  <div class=\"list-prd-card\">\n    <ion-row no-padding *ngIf=\"u_grid == true && list_product.length > 0\">\n      <ion-col col-6 *ngFor=\"let item of list_product\">\n        <div class=\"item-prd mgb-30\">\n          <div class=\"thumb ovfl-hidden flex-row flex-jus-center flex-ali-center\">\n            <div class=\"discount fw-600 pdt-5 fs-12 shadow-3 white\" *ngIf=\"item.payload.doc.data().discount > 0\">\n              - {{item.payload.doc.data().discount}}%\n            </div>\n            <img src=\"{{item.payload.doc.data().thumb}}\" [routerLink]=\"['/detail', {id_item: item.payload.doc.id}]\">\n            <ion-button size=\"small\" color=\"primary\" class=\"fs-11 bdra-0 favo-btn\" *ngIf=\"favo_str.search(item.payload.doc.id) > -1\" (click)=\"favorites(item)\">\n              <ion-icon name=\"ios-heart\"></ion-icon>\n            </ion-button>\n            <ion-button size=\"small\" color=\"dark\" class=\"fs-11 bdra-0 favo-btn\" *ngIf=\"favo_str.search(item.payload.doc.id) < 0\" (click)=\"favorites(item)\">\n              <ion-icon name=\"ios-heart\"></ion-icon>\n            </ion-button>\n          </div>\n\n          <div class=\"ovfl-hidden\" [routerLink]=\"['/detail', {id_item: item.payload.doc.id}]\">\n            <h4 class=\"fs-16 fw-600 ellipsis mgb-0 mgt-10\">{{item.payload.doc.data().name}}</h4>\n            <p class=\"mgt-5 mgb-0\">\n              <span class=\"ellipsis fs-14 txt3 mg-0 line-through mgr-10 fw-600\" *ngIf=\"currenciesProv && item.payload.doc.data().discount > 0\">\n                <i *ngIf=\"currenciesProv\">{{currenciesProv.formatMoney(item.payload.doc.data().price)}}</i>\n              </span>\n              <span class=\"ellipsis fs-14 txt1 mg-0 fw-600\" *ngIf=\"currenciesProv && item.payload.doc.data().discount > 0\">\n                {{currenciesProv.formatMoney(item.payload.doc.data().price - item.payload.doc.data().price*item.payload.doc.data().discount/100)}}\n              </span>\n              <span class=\"ellipsis fs-14 txt1 mg-0 fw-600\" *ngIf=\"currenciesProv && item.payload.doc.data().discount == 0\">\n                {{currenciesProv.formatMoney(item.payload.doc.data().price)}}\n              </span>\n            </p>\n          </div>\n          <div class=\"mgt-10\">\n            <ion-button size=\"small\" color=\"dark\" (click)=\"addCart(item)\" class=\"uppercase fs-11 bdra-0 fw-600\">\n              <ion-icon slot=\"start\" name=\"ios-cart\"></ion-icon>\n              Add to cart\n            </ion-button>\n          </div>\n        </div>\n      </ion-col>\n    </ion-row>\n  </div>\n\n\n\n\n\n <div class=\"list-prd-list\" *ngIf=\"u_grid == false && list_product.length > 0\">\n    <div class=\"item-prd mgb-20 pdb-15\" *ngFor=\"let item of list_product\">\n      <div class=\"thumb mgr-10 flex-row flex-ali-center flex-jus-center\">\n        <img src=\"{{item.payload.doc.data().thumb}}\">\n      </div>\n      <div class=\"\">\n        <div class=\"ovfl-hidden\">\n          <h4 class=\"fs-14 txt1 fw-600 ellipsis mg-0\">{{item.payload.doc.data().name}}</h4>\n          <p class=\"mg-0\">\n            <span class=\"ellipsis fs-14 txt3 mg-0 line-through mgr-10 fw-600\" *ngIf=\"currenciesProv && item.payload.doc.data().discount > 0\">\n              <i *ngIf=\"currenciesProv\">\n                {{currenciesProv.formatMoney(item.payload.doc.data().price)}}\n              </i>\n            </span>\n            <span class=\"ellipsis fs-14 txt1 mg-0 fw-600\" *ngIf=\"currenciesProv && item.payload.doc.data().discount > 0\">\n              {{currenciesProv.formatMoney(item.payload.doc.data().price - item.payload.doc.data().price*item.payload.doc.data().discount/100)}}\n            </span>\n            <span class=\"ellipsis fs-14 txt1 mg-0 fw-600\" *ngIf=\"currenciesProv && item.payload.doc.data().discount == 0\">\n              {{currenciesProv.formatMoney(item.payload.doc.data().price - item.payload.doc.data().price*item.payload.doc.data().discount/100)}}\n            </span>\n          </p>\n        </div>\n        <div class=\"mgt-5\">\n          <ion-button size=\"small\" (click)=\"addCart(item)\" class=\"fs-11 bdra-0 fw-600\">\n            <ion-icon name=\"ios-cart\"></ion-icon>\n            Add cart\n          </ion-button>\n          <ion-button size=\"small\" color=\"primary\" class=\"fs-11 bdra-0\" *ngIf=\"favo_str.search(item.payload.doc.id) > -1\" (click)=\"favorites(item)\">\n            <ion-icon name=\"ios-heart\"></ion-icon>\n          </ion-button>\n          <ion-button size=\"small\" color=\"dark\" class=\"fs-11 bdra-0\" *ngIf=\"favo_str.search(item.payload.doc.id) < 0\" (click)=\"favorites(item)\">\n            <ion-icon name=\"ios-heart\"></ion-icon>\n          </ion-button>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <br>\n\n  <ion-infinite-scroll (ionInfinite)=\"loadMore($event)\">\n    <ion-infinite-scroll-content></ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/list/list.page.scss":
/*!*************************************!*\
  !*** ./src/app/list/list.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".wrap-top-slide .thumb {\n  height: 200px; }\n\n.wrap-slides-cat {\n  width: 135%; }\n\n.mini-cat {\n  height: 70px;\n  overflow: hidden;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  position: relative; }\n\n.mini-cat h6 {\n    position: absolute;\n    left: 0;\n    right: 0;\n    top: 0;\n    bottom: 0;\n    background: rgba(0, 0, 0, 0.4); }\n\n.top-action {\n  display: flex;\n  align-items: center; }\n\n.top-action h6 {\n    flex: 1; }\n\n.list-prd-card .item-prd .thumb {\n  position: relative;\n  height: 150px; }\n\n.list-prd-card .item-prd .thumb img {\n    height: 100%;\n    min-width: 100%; }\n\n.list-prd-card .item-prd .thumb .discount {\n    z-index: 100;\n    position: absolute;\n    top: 10px;\n    left: 0px;\n    height: 25px;\n    width: 80px;\n    overflow: hidden; }\n\n.list-prd-card .item-prd .thumb .discount:before {\n      content: \"\";\n      background: var(--ion-background-color);\n      display: block;\n      height: 200%;\n      width: 180%;\n      margin-left: -100px;\n      transform: rotate(-15deg);\n      position: absolute;\n      z-index: -1; }\n\n.list-prd-card .item-prd .thumb .favo-btn {\n    z-index: 10;\n    position: absolute;\n    right: 10px;\n    bottom: 5px; }\n\n.list-prd-list .item-prd {\n  display: flex;\n  align-items: center;\n  border-bottom: 1px solid #ebebeb; }\n\n.list-prd-list .item-prd .thumb {\n    height: 80px;\n    width: 90px; }\n\n.list-prd-list .item-prd .thumb img {\n      height: 100%;\n      min-width: 100%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbGlzdC9DOlxcVXNlcnNcXGFsZXhhXFxEZXNrdG9wXFxGaW5hbC9zcmNcXGFwcFxcbGlzdFxcbGlzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFFRSxhQUFhLEVBQUE7O0FBR2Y7RUFDQyxXQUFXLEVBQUE7O0FBRVo7RUFDQyxZQUFZO0VBQ1osZ0JBQWdCO0VBQ2hCLGFBQWE7RUFDYixtQkFBbUI7RUFDbkIsdUJBQXVCO0VBQ3ZCLGtCQUFrQixFQUFBOztBQU5uQjtJQVdFLGtCQUFrQjtJQUNsQixPQUFPO0lBQ1AsUUFBUTtJQUNSLE1BQU07SUFDTixTQUFTO0lBQ1QsOEJBQTJCLEVBQUE7O0FBRzdCO0VBQ0MsYUFBYTtFQUNiLG1CQUFtQixFQUFBOztBQUZwQjtJQUlFLE9BQU8sRUFBQTs7QUFHVDtFQUdHLGtCQUFrQjtFQUNsQixhQUFhLEVBQUE7O0FBSmhCO0lBTUksWUFBWTtJQUNaLGVBQWUsRUFBQTs7QUFQbkI7SUFVSSxZQUFZO0lBQ1osa0JBQWtCO0lBQ2xCLFNBQVM7SUFDVCxTQUFTO0lBQ1QsWUFBWTtJQUNaLFdBQVc7SUFDWCxnQkFBZ0IsRUFBQTs7QUFoQnBCO01Ba0JLLFdBQVc7TUFDWCx1Q0FBdUM7TUFDdkMsY0FBYztNQUNkLFlBQVk7TUFDWixXQUFXO01BQ1gsbUJBQW1CO01BQ25CLHlCQUF5QjtNQUN6QixrQkFBa0I7TUFDbEIsV0FBVyxFQUFBOztBQTFCaEI7SUE4QkksV0FBVztJQUNYLGtCQUFrQjtJQUNsQixXQUFXO0lBQ1gsV0FBVyxFQUFBOztBQU9mO0VBRUUsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQixnQ0FBZ0MsRUFBQTs7QUFKbEM7SUFNRyxZQUFZO0lBQ1osV0FBVyxFQUFBOztBQVBkO01BU0ksWUFBWTtNQUNaLGVBQWUsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2xpc3QvbGlzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbi53cmFwLXRvcC1zbGlkZXtcblx0LnRodW1ie1xuXHRcdGhlaWdodDogMjAwcHg7XG5cdH1cbn1cbi53cmFwLXNsaWRlcy1jYXR7XG5cdHdpZHRoOiAxMzUlO1xufVxuLm1pbmktY2F0e1xuXHRoZWlnaHQ6IDcwcHg7XG5cdG92ZXJmbG93OiBoaWRkZW47XG5cdGRpc3BsYXk6IGZsZXg7XG5cdGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cdGp1c3RpZnktY29udGVudDogY2VudGVyO1xuXHRwb3NpdGlvbjogcmVsYXRpdmU7XG5cdGltZ3tcblxuXHR9XG5cdGg2e1xuXHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcblx0XHRsZWZ0OiAwO1xuXHRcdHJpZ2h0OiAwO1xuXHRcdHRvcDogMDtcblx0XHRib3R0b206IDA7XG5cdFx0YmFja2dyb3VuZDogcmdiYSgwLDAsMCwwLjQpO1xuXHR9XG59XG4udG9wLWFjdGlvbntcblx0ZGlzcGxheTogZmxleDtcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcblx0aDZ7XG5cdFx0ZmxleDogMTtcblx0fVxufVxuLmxpc3QtcHJkLWNhcmR7XG5cdC5pdGVtLXByZHtcblx0XHQudGh1bWJ7XG5cdFx0XHRwb3NpdGlvbjogcmVsYXRpdmU7XG5cdFx0XHRoZWlnaHQ6IDE1MHB4O1xuXHRcdFx0aW1ne1xuXHRcdFx0XHRoZWlnaHQ6IDEwMCU7XG5cdFx0XHRcdG1pbi13aWR0aDogMTAwJTtcblx0XHRcdH1cblx0XHRcdC5kaXNjb3VudHtcblx0XHRcdFx0ei1pbmRleDogMTAwO1xuXHRcdFx0XHRwb3NpdGlvbjogYWJzb2x1dGU7XG5cdFx0XHRcdHRvcDogMTBweDtcblx0XHRcdFx0bGVmdDogMHB4O1xuXHRcdFx0XHRoZWlnaHQ6IDI1cHg7XG5cdFx0XHRcdHdpZHRoOiA4MHB4O1xuXHRcdFx0XHRvdmVyZmxvdzogaGlkZGVuO1xuXHRcdFx0XHQmOmJlZm9yZXtcblx0XHRcdFx0XHRjb250ZW50OiBcIlwiO1xuXHRcdFx0XHRcdGJhY2tncm91bmQ6IHZhcigtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yKTtcblx0XHRcdFx0XHRkaXNwbGF5OiBibG9jaztcblx0XHRcdFx0XHRoZWlnaHQ6IDIwMCU7XG5cdFx0XHRcdFx0d2lkdGg6IDE4MCU7XG5cdFx0XHRcdFx0bWFyZ2luLWxlZnQ6IC0xMDBweDtcblx0XHRcdFx0XHR0cmFuc2Zvcm06IHJvdGF0ZSgtMTVkZWcpO1xuXHRcdFx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcblx0XHRcdFx0XHR6LWluZGV4OiAtMTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0LmZhdm8tYnRue1xuXHRcdFx0XHR6LWluZGV4OiAxMDtcblx0XHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xuXHRcdFx0XHRyaWdodDogMTBweDtcblx0XHRcdFx0Ym90dG9tOiA1cHg7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG59XG5cblxuLmxpc3QtcHJkLWxpc3R7XG5cdC5pdGVtLXByZHtcblx0XHRkaXNwbGF5OiBmbGV4O1xuXHRcdGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cdFx0Ym9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlYmViZWI7XG5cdFx0LnRodW1ie1xuXHRcdFx0aGVpZ2h0OiA4MHB4O1xuXHRcdFx0d2lkdGg6IDkwcHg7XG5cdFx0XHRpbWd7XG5cdFx0XHRcdGhlaWdodDogMTAwJTtcblx0XHRcdFx0bWluLXdpZHRoOiAxMDAlO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxufSJdfQ== */"

/***/ }),

/***/ "./src/app/list/list.page.ts":
/*!***********************************!*\
  !*** ./src/app/list/list.page.ts ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var categories_1 = __webpack_require__(/*! ../../providers/categories */ "./src/providers/categories.ts");
var products_1 = __webpack_require__(/*! ../../providers/products */ "./src/providers/products.ts");
var currencies_1 = __webpack_require__(/*! ../../providers/currencies */ "./src/providers/currencies.ts");
var favorites_1 = __webpack_require__(/*! ../../providers/favorites */ "./src/providers/favorites.ts");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
var ListPage = /** @class */ (function () {
    function ListPage(route, events, catProv, toastCtrl, favoritesProv, storage, currenciesProv, loadingCtrl, productsProv) {
        var _this = this;
        this.route = route;
        this.events = events;
        this.catProv = catProv;
        this.toastCtrl = toastCtrl;
        this.favoritesProv = favoritesProv;
        this.storage = storage;
        this.currenciesProv = currenciesProv;
        this.loadingCtrl = loadingCtrl;
        this.productsProv = productsProv;
        this.list_cat = [];
        this.list_cart = [];
        this.list_product = [];
        this.list_slide_product = [];
        this.favo_str = '';
        this.jump = 4;
        this.u_grid = true;
        this.slidePerViewOpts = {
            speed: 1000,
            spaceBetween: 16,
            centeredSlides: true,
            initialSlide: 1,
            slidesPerView: 3
        };
        this.presentLoading();
        this.route.params.subscribe(function (params) {
            _this.obj = params;
        });
        console.log(this.obj);
        this.arr_start = new Array();
        this.list_product = new Array();
        this.catProv.getCatChild(this.obj.id).then(function (data) {
            _this.list_cat = data;
            console.log(_this.list_cat);
            if (data.length > 0) {
                for (var i = 0; i < data.length; ++i) {
                    console.log(_this.list_cat[i].payload.doc.id);
                    var jump = 2;
                    _this.productsProv.getProductByCat(null, jump, data[i].payload.doc.id).then(function (val) {
                        if (val && val.length > 0) {
                            console.log(val);
                            _this.list_product = _this.list_product.concat(val);
                            _this.arr_start = _this.arr_start.concat(val[val.length - 1].payload.doc.data().id_cat);
                            console.log(_this.list_product);
                        }
                        else {
                            // jump = jump + 4;
                            // this.productsProv.getProductByCat(null, jump, this.list_cat[i].payload.doc.id);
                        }
                    }, function (error) {
                    });
                }
            }
            else {
                _this.productsProv.getProductByCat(null, 2, _this.obj.id).then(function (data) {
                    if (data && data.length > 0) {
                        _this.list_product = data;
                        _this.start = data[data.length - 1].payload.doc.data().id_cat;
                        console.log(_this.list_product);
                    }
                    else {
                    }
                }, function (error) {
                });
            }
        }, function (error) {
        });
        this.productsProv.getProductBySlide(5, this.obj.id).then(function (data) {
            _this.list_slide_product = data;
            console.log(_this.list_slide_product);
        });
        this.storage.get('user').then(function (val) {
            _this.id_user = val.id_auth;
            _this.favoritesProv.getByUserId(_this.id_user).then(function (data) {
                _this.loading.dismiss().then(function () {
                    if (data.length > 0) {
                        _this.favo_str = data[0].payload.doc.data().id_product;
                        _this.id_favo_str = data[0].payload.doc.id;
                        console.log(data);
                    }
                });
            });
        });
        this.storage.get('cart_list').then(function (val) {
            if (!val || val == null) {
                _this.list_cart = new Array();
            }
            else {
                _this.list_cart = val;
            }
            console.log(_this.list_cart);
        });
        this.events.subscribe('cart_list: change', function (lst) {
            _this.list_cart = lst;
        });
    }
    ListPage.prototype.ionViewWillEnter = function () {
    };
    ListPage.prototype.loadMore = function (event) {
        var _this = this;
        if (this.list_cat.length > 0) {
            for (var i = 0; i < this.list_cat.length; ++i) {
                console.log(this.list_cat[i].payload.doc.id);
                console.log(this.arr_start[i]);
                var jump = 2;
                this.productsProv.getProductByCat(this.arr_start[i], jump, this.list_cat[i].payload.doc.id).then(function (val) {
                    if (val && val.length > 0) {
                        console.log(val);
                        _this.list_product = _this.list_product.concat(val);
                        _this.arr_start[i] = val[val.length - 1].payload.doc.data().id_cat;
                        console.log(_this.list_product);
                        setTimeout(function () {
                            event.target.disabled = true;
                        }, 1500);
                    }
                    else {
                        // jump = jump + 4;
                        // this.productsProv.getProductByCat(this.arr_start[i], jump, this.list_cat[i].payload.doc.id);
                        setTimeout(function () {
                            event.target.disabled = true;
                        }, 1500);
                    }
                }, function (error) {
                    setTimeout(function () {
                        event.target.disabled = true;
                    }, 1500);
                });
            }
        }
        else {
            console.log(this.start);
            this.productsProv.getProductByCat(this.start, 2, this.obj.id).then(function (data) {
                if (data && data.length > 0) {
                    console.log(data);
                    _this.list_product = _this.list_product.concat(data);
                    _this.start = data[data.length - 1].payload.doc.data().id_cat;
                    console.log(_this.start);
                }
                else {
                }
            }, function (error) {
            });
        }
    };
    ListPage.prototype.favorites = function (item) {
        var _this = this;
        console.log(item.payload.doc.id);
        var check = this.favo_str.indexOf(item.payload.doc.id);
        if (check == -1) {
            this.favo_str = this.favo_str + item.payload.doc.id + ' ';
        }
        else {
            this.favo_str = this.favo_str.replace(item.payload.doc.id + ' ', '');
        }
        this.favoritesProv.favoritesAdd(this.favo_str, this.id_user, this.id_favo_str).then(function (data) {
            if (!_this.id_favo_str || _this.id_favo_str == null) {
                _this.favoritesProv.getByUserId(_this.id_user).then(function (newFavo) {
                    _this.id_favo_str = newFavo[0].payload.doc.id;
                });
            }
        });
    };
    ListPage.prototype.addCart = function (item) {
        console.log(item);
        var itemCv = {
            id: item.payload.doc.id,
            name: item.payload.doc.data().name,
            price: item.payload.doc.data().price,
            discount: item.payload.doc.data().discount,
            description: item.payload.doc.data().description,
            vote: item.payload.doc.data().vote,
            created: item.payload.doc.data().created,
            id_cat: item.payload.doc.data().id_cat,
            tag: item.payload.doc.data().tag,
            thumb: item.payload.doc.data().thumb,
            thumb1: item.payload.doc.data().thumb1,
            thumb2: item.payload.doc.data().thumb2,
            thumb3: item.payload.doc.data().thumb3,
            thumb4: item.payload.doc.data().thumb4,
            quantity: 1
        };
        var temp = this.list_cart.filter(function (element) {
            if (element.id == itemCv.id) {
                element.quantity = 1 + element.quantity;
                return true;
            }
        });
        console.log(temp);
        if (temp.length == 0) {
            this.list_cart = this.list_cart.concat(itemCv);
        }
        var toast = this.toastCtrl.create({
            message: 'Se agrego con exito',
            duration: 2000,
            position: 'bottom'
        });
        this.presentToast();
        // this.list_cart = new Array();
        this.events.publish('cart_list: change', this.list_cart);
        this.storage.set('cart_list', this.list_cart);
        console.log(this.list_cart);
    };
    ListPage.prototype.presentLoading = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = this;
                        return [4 /*yield*/, this.loadingCtrl.create({
                                message: 'Cargando',
                                duration: 2000
                            })];
                    case 1:
                        _a.loading = _b.sent();
                        return [4 /*yield*/, this.loading.present()];
                    case 2: return [2 /*return*/, _b.sent()];
                }
            });
        });
    };
    ListPage.prototype.presentToast = function () {
        return __awaiter(this, void 0, void 0, function () {
            var toast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            message: 'Se agrego con exito',
                            duration: 2000,
                            position: 'bottom'
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    ListPage.prototype.u_list = function (val) {
        this.u_grid = val;
    };
    ListPage.prototype.ngOnInit = function () {
    };
    ListPage = __decorate([
        core_1.Component({
            selector: 'app-list',
            template: __webpack_require__(/*! ./list.page.html */ "./src/app/list/list.page.html"),
            styles: [__webpack_require__(/*! ./list.page.scss */ "./src/app/list/list.page.scss")]
        }),
        __metadata("design:paramtypes", [router_1.ActivatedRoute,
            angular_1.Events,
            categories_1.CategoriesProvider,
            angular_1.ToastController,
            favorites_1.FavoritesProvider,
            storage_1.Storage,
            currencies_1.CurrenciesProvider,
            angular_1.LoadingController,
            products_1.ProductsProvider])
    ], ListPage);
    return ListPage;
}());
exports.ListPage = ListPage;


/***/ })

}]);
//# sourceMappingURL=list-list-module.js.map