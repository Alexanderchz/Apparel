(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["shirt-info-shirt-info-module"],{

/***/ "./src/app/shirt-info/shirt-info.module.ts":
/*!*************************************************!*\
  !*** ./src/app/shirt-info/shirt-info.module.ts ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var shirt_info_page_1 = __webpack_require__(/*! ./shirt-info.page */ "./src/app/shirt-info/shirt-info.page.ts");
var routes = [
    {
        path: '',
        component: shirt_info_page_1.ShirtInfoPage
    }
];
var ShirtInfoPageModule = /** @class */ (function () {
    function ShirtInfoPageModule() {
    }
    ShirtInfoPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [shirt_info_page_1.ShirtInfoPage]
        })
    ], ShirtInfoPageModule);
    return ShirtInfoPageModule;
}());
exports.ShirtInfoPageModule = ShirtInfoPageModule;


/***/ }),

/***/ "./src/app/shirt-info/shirt-info.page.html":
/*!*************************************************!*\
  !*** ./src/app/shirt-info/shirt-info.page.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\t<ion-toolbar class=\"toolbar\">\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-back-button color=\"light\" text=\"\" icon=\"ios-arrow-round-back\"></ion-back-button>\n\t\t\t\n\t\t\t\t<ion-back-button class=\"mgb-5  txt-light\" defaultHref=\"/home-client\"></ion-back-button>\n\t\t\n\t\t</ion-buttons>\n\n\t\n\n\t\t<ion-title color=\"light\">Tipos de prenda</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <ion-label>\n  </ion-label>\n\n\n\n  <ion-card>\n    <ion-card-header>\n      <ion-card-subtitle>Tipos de corte</ion-card-subtitle>\n    </ion-card-header>\n    <ion-card-content>\n      <p>\n        Dentro de la confeccion de ropa existen diferentes tipos de corte de los cuales desconocemos muchas veces\n      </p>\n      <ion-spinner *ngIf=\"!articles\" name=\"dots\"></ion-spinner>\n      <p>\n        En este articulo encontraras tu tipo de prenda ideal segun tus medidas!\n      </p>\n    </ion-card-content>\n  </ion-card>\n\n  <ion-card>\n    <ion-card-header>\n        <ion-card-subtitle>Regular fit</ion-card-subtitle>\n    </ion-card-header>\n    <ion-card-content>\n      <p>\n        Se trata generalmente de lo que conocemos como corte recto (de ahí que también podamos encontrarlo como Straight Fit). Son quizá las más cómodas, la sisa es amplia y el ancho de la manga estándar (cubre el brazo sin ceñirlo), al igual que el del pecho. La tela cae recta de la sisa hasta el final de la camisa.\n\n*Nota: esta comodidad no tiene por qué implicar un aspecto casual o despreocupado. Una camisa blanca de corte regular fit puede ser igual de elegante que una slim fit\n\nQué esperar de ella: es la típica camisa de no fallar. La que sirve para cualquier tipo de cuerpo. Si te queda bien de hombros, el resto de tu cuerpo entrará en ella. Eso sí, no esperes que realce demasiado, simplemente servirá para cubrir el cuerpo de forma sencilla.\n      </p>\n\n      <ion-img src=\"https://media.revistagq.com/photos/5ca600fad71dd9ee91958958/master/w_1280%2cc_limit/camisa_regular_fit_3837.jpg\"></ion-img>\n    </ion-card-content>\n  </ion-card>\n\n  <ion-card>\n    <ion-card-header>\n        <ion-card-subtitle>Tailored fit</ion-card-subtitle>\n    </ion-card-header>\n    <ion-card-content>\n      <p>\n        Hablando en plata, es un regular fit estrechado ligeramente. Imagina que compras una camisa de corte recto y la llevas a arreglar para que se adapte ligeramente a tu torso, pero sin marcarlo, entonces obtienes un tailored fit. Como su propio nombre indica, imita el corte de una camisa hecha a medida, por un sastre (tailor), bien encajada pero sin apretar.\n\n        Qué puedes esperar de ella: La sisa y la manga mantienen el ancho del regular fit, por lo que conserva la comodidad y la libertad de movimiento, pero se estrecha en el tronco para realzar la silueta masculina. Perfecta para, o bien aquellos lorzalameros que se han dejado llevar por el influjo descontrolado de las cañas y las tapas, o bien, para aquellos que han desarrollado en el gimnasio los hombros y el pecho pero no tanto la cadera. Marca bien la línea de los hombros y resalta ligeramente la silueta sin subrayarla, por lo que consigue disimular la barriguita o aportar el volumen justo en la zona de la cadera para desdibujar la descompensación respecto a la parte superior.\n      </p>\n\n      <ion-img src=\"https://media.revistagq.com/photos/5ca600fbf46488cedaf4a4cd/master/w_1280%2cc_limit/camisa_tailored_fit_3284.jpg\"></ion-img>\n    </ion-card-content>\n  </ion-card>\n\n\n  <ion-card>\n    <ion-card-header>\n        <ion-card-subtitle>Custom fit</ion-card-subtitle>\n    </ion-card-header>\n    <ion-card-content>\n      <p>\n        Aquí, la cosa se sigue estrechando. Mantiene el largo de la camisa, pero todo se reduce: sisa, ancho de manga, contorno de pecho y tronco con el fin de resaltar la figura masculina.\n\n        Qué esperar de ella: La gente delgada y alta se sentirá cómoda dentro de este corte. Consigue un efecto visual que enfatiza los hombros con respecto a la cintura, dando un aspecto más corpulento. Y lo más importante, aunque su bajo es más recogido que el de un tailored o un regular, no les quedarán cortas ni de mangas ni de largo. Concursantes de MYHYV, este es el límite de ajuste que os deberíais permitir.\n      </p>\n\n      <ion-img src=\"https://media.revistagq.com/photos/5ca600fad71dd9de88958957/master/w_1280%2cc_limit/camisa_custom_fit_4347.jpg\"></ion-img>\n    </ion-card-content>\n  </ion-card>\n\n\n\n  <ion-card>\n    <ion-card-header>\n        <ion-card-subtitle>Slim fit</ion-card-subtitle>\n    </ion-card-header>\n    <ion-card-content>\n      <p>\n         \n        Vamos un paso más allá. Con el slim fit, el pecho se estrecha y el tronco se acorta. Además, la sisa y el ancho de mangas seguirán siendo ceñidos. La principal diferencia con la anterior es la siguiente: si te pones una camisa custom fit, la coges justo por debajo del pecho y tiras de ella hacia arriba (sitúas la parte del abdomen en el pecho), obtienes un slim fit.\n\nQué esperar de ella: Gracias a su corte, te hace parecer mucho más fornido, además de pegarse mucho más al cuerpo (por tanto, son más recomendadas para gente con un abdomen más bien plano, puesto que, si no, estaremos subrayando la barriga en lugar de disimularla –ver punto 2–) . Aviso a los altos: pruébate la camisa antes de comprarla, puede que llegado el momento de estrenarla y debido a que es más corta, parezca que ha encogido en la lavadora.\n      </p>\n\n      <ion-img src=\"https://media.revistagq.com/photos/5ca600faebc41d6faf7b1022/master/w_1280%2cc_limit/camisa_slim_fit_198.jpg\"></ion-img>\n    </ion-card-content>\n  </ion-card>\n\n\n  <ion-card>\n    <ion-card-header>\n        <ion-card-subtitle>Super slim fit</ion-card-subtitle>\n    </ion-card-header>\n    <ion-card-content>\n      <p>\n         \n        Lo anterior pero llevado al extremo.\n\n        Qué esperar de ella: La gente menuda encontrará en este corte a su mayor aliado. Encaja en los hombros y recorre el cuerpo pegado a él como si se tratase de una segunda piel. Visualmente, los hombros se multiplican por 10 y las caderas se estrechan, pareciendo que lleves meses yendo al gimnasio.\n        \n        *Una versión de este artículo fue originalemnte publicada el 26-05-2015.\n      </p>\n\n      <ion-img src=\"https://media.revistagq.com/photos/5ca600fabda59449f733ea2f/master/w_1280%2cc_limit/camisa_superslim_fit__721.jpg\"></ion-img>\n    </ion-card-content>\n  </ion-card>\n\n</ion-content>"

/***/ }),

/***/ "./src/app/shirt-info/shirt-info.page.scss":
/*!*************************************************!*\
  !*** ./src/app/shirt-info/shirt-info.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hpcnQtaW5mby9DOlxcVXNlcnNcXGFsZXhhXFxEZXNrdG9wXFxGaW5hbC9zcmNcXGFwcFxcc2hpcnQtaW5mb1xcc2hpcnQtaW5mby5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxzRkFBYSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvc2hpcnQtaW5mby9zaGlydC1pbmZvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b29sYmFyIHtcclxuICAgXHJcbiAgICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsIHZhcigtLWlvbi1jb2xvci1kYXJrKSwgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpKTtcclxuICAgICAgICBcclxuICB9Il19 */"

/***/ }),

/***/ "./src/app/shirt-info/shirt-info.page.ts":
/*!***********************************************!*\
  !*** ./src/app/shirt-info/shirt-info.page.ts ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var ShirtInfoPage = /** @class */ (function () {
    function ShirtInfoPage() {
    }
    ShirtInfoPage.prototype.ngOnInit = function () {
    };
    ShirtInfoPage = __decorate([
        core_1.Component({
            selector: 'app-shirt-info',
            template: __webpack_require__(/*! ./shirt-info.page.html */ "./src/app/shirt-info/shirt-info.page.html"),
            styles: [__webpack_require__(/*! ./shirt-info.page.scss */ "./src/app/shirt-info/shirt-info.page.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], ShirtInfoPage);
    return ShirtInfoPage;
}());
exports.ShirtInfoPage = ShirtInfoPage;


/***/ })

}]);
//# sourceMappingURL=shirt-info-shirt-info-module.js.map