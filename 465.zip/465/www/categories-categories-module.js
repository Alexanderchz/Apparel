(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["categories-categories-module"],{

/***/ "./src/app/categories/categories.module.ts":
/*!*************************************************!*\
  !*** ./src/app/categories/categories.module.ts ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var categories_page_1 = __webpack_require__(/*! ./categories.page */ "./src/app/categories/categories.page.ts");
var routes = [
    {
        path: '',
        component: categories_page_1.CategoriesPage
    }
];
var CategoriesPageModule = /** @class */ (function () {
    function CategoriesPageModule() {
    }
    CategoriesPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [categories_page_1.CategoriesPage]
        })
    ], CategoriesPageModule);
    return CategoriesPageModule;
}());
exports.CategoriesPageModule = CategoriesPageModule;


/***/ }),

/***/ "./src/app/categories/categories.page.html":
/*!*************************************************!*\
  !*** ./src/app/categories/categories.page.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\t<ion-toolbar color=\"ion-color-primary-rgb\">\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-back-button class=\"fs-24 txt1\" text=\"\" icon=\"ios-arrow-round-back\"></ion-back-button>\n\t\t\t<ion-menu-button>\n\t\t\t\t<ion-icon class=\"fs-24 txt1\" name=\"menu\"></ion-icon>\n\t\t\t</ion-menu-button>\n\t\t</ion-buttons>\n\n\t\t   <ion-buttons slot=\"end\">\n     \n      <ion-button fill=\"clear\" class=\"shadow-0 txt1\" [routerLink]=\"'/mycart'\" routerDirection=\"forward\">\n        <ion-icon name=\"cart\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n\t\t<ion-title style=\"color:white;\">Categories</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content fullscreen>\n\n\n<ion-searchbar (ionInput)=\"searchItem($event)\" placeholder=\"Search category here...\">\n    </ion-searchbar>\n\n\t <div class=\"movies-flex\" *ngIf=\"categoryList\">\n    <div class=\"movie\" *ngFor=\"let cats of categoryList\" [routerLink]=\"['/products', {id: id, title: title , owner_id: owner_id , cat_id: cats.id}]\">\n      <div class=\"poster\">\n       \n\t\t<img  class=\"poster-effect\" [src]=\"cats.image\">\n      </div>\n      <div class=\"title\">{{cats.title }}</div>\n      <div class=\"year\"><ion-icon name=\"star\"></ion-icon>{{ cats.title}}</div>\n      \n    </div>\n  </div>\n\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/categories/categories.page.scss":
/*!*************************************************!*\
  !*** ./src/app/categories/categories.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-icon {\n  font-size: 24px; }\n\nion-toolbar .tabs {\n  display: flex;\n  justify-content: center; }\n\nion-toolbar .tabs .tab {\n    text-align: center;\n    width: calc(100% / 3);\n    color: #8c8c8c; }\n\nion-toolbar .tabs .tab.active {\n      color: #488aff; }\n\nion-toolbar .tabs .tab ion-icon {\n      font-size: 30px; }\n\nion-toolbar .tabs .tab .label {\n      font-size: 10px;\n      margin-top: -2px; }\n\nh1 {\n  font-weight: 800;\n  letter-spacing: -0.03em;\n  font-size: 32px;\n  line-height: 32px;\n  margin: 8px 0 16px 16px; }\n\n.movies-flex {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: space-around; }\n\n.movies-flex .movie {\n    flex: 0 170px;\n    padding: 15px 8px;\n    display: flex;\n    flex-wrap: wrap;\n    justify-content: flex-start;\n    align-items: flex-start;\n    align-content: flex-start;\n    cursor: pointer; }\n\n.movies-flex .movie div.poster {\n      position: relative;\n      width: 100%;\n      height: 230px;\n      background: #eee;\n      border-radius: 6px; }\n\n.movies-flex .movie div.poster img.poster, .movies-flex .movie div.poster img.poster-effect {\n        width: 100%;\n        height: 230px;\n        -o-object-fit: cover;\n           object-fit: cover;\n        border-radius: 6px;\n        z-index: 9999;\n        position: relative;\n        margin-bottom: -215px;\n        -webkit-transform: translateZ(0);\n        -webkit-perspective: 1000;\n        -webkit-backface-visibility: hidden; }\n\n.movies-flex .movie div.poster img.poster.poster-effect, .movies-flex .movie div.poster img.poster-effect.poster-effect {\n          z-index: 999;\n          transform: scale(0.95) translateZ(0); }\n\n.movies-flex .movie .title {\n      width: 100%;\n      font-weight: 800;\n      letter-spacing: -0.05em;\n      font-size: 15px;\n      line-height: 15px;\n      padding: 20px 0 5px 0; }\n\n.movies-flex .movie .year {\n      width: 50%;\n      color: #aaa;\n      font-size: 12px; }\n\n.movies-flex .movie .vote {\n      width: 50%;\n      text-align: right;\n      color: #aaa;\n      font-size: 12px; }\n\n.movies-flex .movie .vote b {\n        font-weight: 800;\n        color: #000; }\n\n.movies-flex .movie .vote ion-icon {\n        color: #fbcd00;\n        line-height: 0px;\n        position: absolute;\n        margin: 1px 0 0 -14px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2F0ZWdvcmllcy9DOlxcVXNlcnNcXGFsZXhhXFxEZXNrdG9wXFxGaW5hbC9zcmNcXGFwcFxcY2F0ZWdvcmllc1xcY2F0ZWdvcmllcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxlQUFlLEVBQUE7O0FBRWpCO0VBQ0UsYUFBYTtFQUNiLHVCQUF1QixFQUFBOztBQUZ6QjtJQUlJLGtCQUFrQjtJQUNsQixxQkFBcUI7SUFDckIsY0FBYyxFQUFBOztBQU5sQjtNQVFNLGNBQWMsRUFBQTs7QUFScEI7TUFXTSxlQUFlLEVBQUE7O0FBWHJCO01BY00sZUFBZTtNQUNmLGdCQUFnQixFQUFBOztBQUl0QjtFQUNFLGdCQUFnQjtFQUNoQix1QkFBdUI7RUFDdkIsZUFBZTtFQUNmLGlCQUFpQjtFQUNqQix1QkFBdUIsRUFBQTs7QUFFekI7RUFDRSxhQUFhO0VBQ2IsZUFBZTtFQUNmLDZCQUE2QixFQUFBOztBQUgvQjtJQUtJLGFBQWE7SUFDYixpQkFBaUI7SUFDakIsYUFBYTtJQUNiLGVBQWU7SUFDZiwyQkFBMkI7SUFDM0IsdUJBQXVCO0lBQ3ZCLHlCQUF5QjtJQUN6QixlQUFlLEVBQUE7O0FBWm5CO01BY00sa0JBQWtCO01BQ2xCLFdBQVc7TUFDWCxhQUFhO01BQ2IsZ0JBQWdCO01BQ2hCLGtCQUFrQixFQUFBOztBQWxCeEI7UUFvQlEsV0FBVztRQUNYLGFBQWE7UUFDYixvQkFBaUI7V0FBakIsaUJBQWlCO1FBQ2pCLGtCQUFrQjtRQUNsQixhQUFhO1FBQ2Isa0JBQWtCO1FBQ2xCLHFCQUFxQjtRQUNyQixnQ0FBZ0M7UUFDaEMseUJBQXlCO1FBQ3pCLG1DQUFtQyxFQUFBOztBQTdCM0M7VUErQlUsWUFBWTtVQUVaLG9DQUFvQyxFQUFBOztBQWpDOUM7TUF1Q00sV0FBVztNQUNYLGdCQUFnQjtNQUNoQix1QkFBdUI7TUFDdkIsZUFBZTtNQUNmLGlCQUFpQjtNQUNqQixxQkFBcUIsRUFBQTs7QUE1QzNCO01BK0NNLFVBQVU7TUFDVixXQUFXO01BQ1gsZUFBZSxFQUFBOztBQWpEckI7TUFvRE0sVUFBVTtNQUNWLGlCQUFpQjtNQUNqQixXQUFXO01BQ1gsZUFBZSxFQUFBOztBQXZEckI7UUF5RFEsZ0JBQWdCO1FBQ2hCLFdBQVcsRUFBQTs7QUExRG5CO1FBNkRRLGNBQWM7UUFDZCxnQkFBZ0I7UUFDaEIsa0JBQWtCO1FBQ2xCLHFCQUFxQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvY2F0ZWdvcmllcy9jYXRlZ29yaWVzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIgaW9uLWljb24ge1xyXG4gIGZvbnQtc2l6ZTogMjRweDtcclxufVxyXG5pb24tdG9vbGJhciAudGFicyB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAudGFiIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHdpZHRoOiBjYWxjKDEwMCUgLyAzKTtcclxuICAgIGNvbG9yOiAjOGM4YzhjO1xyXG4gICAgJi5hY3RpdmUge1xyXG4gICAgICBjb2xvcjogIzQ4OGFmZjtcclxuICAgIH1cclxuICAgIGlvbi1pY29uIHtcclxuICAgICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgfVxyXG4gICAgLmxhYmVsIHtcclxuICAgICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgICBtYXJnaW4tdG9wOiAtMnB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5oMSB7XHJcbiAgZm9udC13ZWlnaHQ6IDgwMDtcclxuICBsZXR0ZXItc3BhY2luZzogLTAuMDNlbTtcclxuICBmb250LXNpemU6IDMycHg7XHJcbiAgbGluZS1oZWlnaHQ6IDMycHg7XHJcbiAgbWFyZ2luOiA4cHggMCAxNnB4IDE2cHg7XHJcbn1cclxuLm1vdmllcy1mbGV4IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcclxuICAubW92aWUge1xyXG4gICAgZmxleDogMCAxNzBweDtcclxuICAgIHBhZGRpbmc6IDE1cHggOHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtd3JhcDogd3JhcDtcclxuICAgIGp1c3RpZnktY29udGVudDogZmxleC1zdGFydDtcclxuICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG4gICAgYWxpZ24tY29udGVudDogZmxleC1zdGFydDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIGRpdi5wb3N0ZXIge1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICBoZWlnaHQ6IDIzMHB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjZWVlO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICAgIGltZy5wb3N0ZXIsIGltZy5wb3N0ZXItZWZmZWN0IHtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICBoZWlnaHQ6IDIzMHB4O1xyXG4gICAgICAgIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDZweDtcclxuICAgICAgICB6LWluZGV4OiA5OTk5O1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAtMjE1cHg7XHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVooMCk7XHJcbiAgICAgICAgLXdlYmtpdC1wZXJzcGVjdGl2ZTogMTAwMDtcclxuICAgICAgICAtd2Via2l0LWJhY2tmYWNlLXZpc2liaWxpdHk6IGhpZGRlbjtcclxuICAgICAgICAmLnBvc3Rlci1lZmZlY3Qge1xyXG4gICAgICAgICAgei1pbmRleDogOTk5O1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDAuOTUpIHRyYW5zbGF0ZVooMCk7XHJcbiAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC50aXRsZSB7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICBmb250LXdlaWdodDogODAwO1xyXG4gICAgICBsZXR0ZXItc3BhY2luZzogLTAuMDVlbTtcclxuICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICBsaW5lLWhlaWdodDogMTVweDtcclxuICAgICAgcGFkZGluZzogMjBweCAwIDVweCAwO1xyXG4gICAgfVxyXG4gICAgLnllYXIge1xyXG4gICAgICB3aWR0aDogNTAlO1xyXG4gICAgICBjb2xvcjogI2FhYTtcclxuICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgfVxyXG4gICAgLnZvdGUge1xyXG4gICAgICB3aWR0aDogNTAlO1xyXG4gICAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgICAgY29sb3I6ICNhYWE7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgYiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDgwMDtcclxuICAgICAgICBjb2xvcjogIzAwMDtcclxuICAgICAgfVxyXG4gICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgY29sb3I6ICNmYmNkMDA7XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDBweDtcclxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgbWFyZ2luOiAxcHggMCAwIC0xNHB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/categories/categories.page.ts":
/*!***********************************************!*\
  !*** ./src/app/categories/categories.page.ts ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var CategoriesPage = /** @class */ (function () {
    function CategoriesPage(loadingCtrl, events, toastCtrl) {
        this.loadingCtrl = loadingCtrl;
        this.events = events;
        this.toastCtrl = toastCtrl;
        this.params = {};
    }
    CategoriesPage = __decorate([
        core_1.Component({
            selector: 'app-categories',
            template: __webpack_require__(/*! ./categories.page.html */ "./src/app/categories/categories.page.html"),
            styles: [__webpack_require__(/*! ./categories.page.scss */ "./src/app/categories/categories.page.scss")]
        }),
        __metadata("design:paramtypes", [angular_1.LoadingController,
            angular_1.Events,
            angular_1.ToastController])
    ], CategoriesPage);
    return CategoriesPage;
}());
exports.CategoriesPage = CategoriesPage;


/***/ })

}]);
//# sourceMappingURL=categories-categories-module.js.map