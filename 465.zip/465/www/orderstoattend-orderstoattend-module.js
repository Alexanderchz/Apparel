(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["orderstoattend-orderstoattend-module"],{

/***/ "./src/app/orderstoattend/orderstoattend.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/orderstoattend/orderstoattend.module.ts ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var orderstoattend_page_1 = __webpack_require__(/*! ./orderstoattend.page */ "./src/app/orderstoattend/orderstoattend.page.ts");
var routes = [
    {
        path: '',
        component: orderstoattend_page_1.OrderstoattendPage
    }
];
var OrderstoattendPageModule = /** @class */ (function () {
    function OrderstoattendPageModule() {
    }
    OrderstoattendPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [orderstoattend_page_1.OrderstoattendPage]
        })
    ], OrderstoattendPageModule);
    return OrderstoattendPageModule;
}());
exports.OrderstoattendPageModule = OrderstoattendPageModule;


/***/ }),

/***/ "./src/app/orderstoattend/orderstoattend.page.html":
/*!*********************************************************!*\
  !*** ./src/app/orderstoattend/orderstoattend.page.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar class=\"toolbar\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button color=\"light\" text=\"\" icon=\"ios-arrow-round-back\"></ion-back-button>\n        \n          <ion-back-button class=\"mgb-5  txt-light\" defaultHref=\"/home-vendor\"></ion-back-button>\n      \n      </ion-buttons>\n  \n    \n  \n      <ion-title color=\"light\">Ordenes de confeccion</ion-title>\n    </ion-toolbar>\n  </ion-header>\n  \n<ion-content>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/orderstoattend/orderstoattend.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/orderstoattend/orderstoattend.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvb3JkZXJzdG9hdHRlbmQvQzpcXFVzZXJzXFxhbGV4YVxcRGVza3RvcFxcRmluYWwvc3JjXFxhcHBcXG9yZGVyc3RvYXR0ZW5kXFxvcmRlcnN0b2F0dGVuZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxzRkFBYSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvb3JkZXJzdG9hdHRlbmQvb3JkZXJzdG9hdHRlbmQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXIgeyAgXHJcbiAgICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsIHZhcigtLWlvbi1jb2xvci1kYXJrKSwgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpKTsgICAgICBcclxuICB9Il19 */"

/***/ }),

/***/ "./src/app/orderstoattend/orderstoattend.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/orderstoattend/orderstoattend.page.ts ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var OrderstoattendPage = /** @class */ (function () {
    function OrderstoattendPage() {
    }
    OrderstoattendPage.prototype.ngOnInit = function () {
    };
    OrderstoattendPage = __decorate([
        core_1.Component({
            selector: 'app-orderstoattend',
            template: __webpack_require__(/*! ./orderstoattend.page.html */ "./src/app/orderstoattend/orderstoattend.page.html"),
            styles: [__webpack_require__(/*! ./orderstoattend.page.scss */ "./src/app/orderstoattend/orderstoattend.page.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], OrderstoattendPage);
    return OrderstoattendPage;
}());
exports.OrderstoattendPage = OrderstoattendPage;


/***/ })

}]);
//# sourceMappingURL=orderstoattend-orderstoattend-module.js.map