(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-product-add-product-module"],{

/***/ "./src/app/add-product/add-product.module.ts":
/*!***************************************************!*\
  !*** ./src/app/add-product/add-product.module.ts ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var add_product_page_1 = __webpack_require__(/*! ./add-product.page */ "./src/app/add-product/add-product.page.ts");
var routes = [
    {
        path: '',
        component: add_product_page_1.AddProductPage
    }
];
var AddProductPageModule = /** @class */ (function () {
    function AddProductPageModule() {
    }
    AddProductPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [add_product_page_1.AddProductPage]
        })
    ], AddProductPageModule);
    return AddProductPageModule;
}());
exports.AddProductPageModule = AddProductPageModule;


/***/ }),

/***/ "./src/app/add-product/add-product.page.html":
/*!***************************************************!*\
  !*** ./src/app/add-product/add-product.page.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\t<ion-toolbar class=\"toolbar\">\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-back-button color=\"light\" text=\"\" icon=\"ios-arrow-round-back\"></ion-back-button>\n\t\t\t\n\t\t\t\t<ion-back-button class=\"mgb-5  txt-light\" defaultHref=\"/home-vendor\"></ion-back-button>\n\t\t\n\t\t</ion-buttons>\n\n\t\n\n\t\t<ion-title color=\"light\">Agregar nuevo producto</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n    \n<ion-content padding>\n \n\t<ion-grid fixed>\n\t\t\n\t\t  \n\t\t\n\t\t<br>\n\t\t\t<ion-label>Ingresar nombre del producto          </ion-label>\n\n\t\t\t<ion-item>\n\t\t\t  <ion-input placeholder=\"\" [(ngModel)]=\"name\"></ion-input>\n\t\t\t</ion-item>\n\t\t\t<br>\n\t\t\t<ion-label>Ingresar descripcion del producto          </ion-label>\n\n\t\t\t<ion-item>\n\t\t\t  <ion-input placeholder=\"\" [(ngModel)]=\"description\"></ion-input>\n\t\t\t</ion-item>\n\t\t\t<br>\n\t\t\t<ion-label>Ingresar descuento del producto          </ion-label>\n\n\t\t\t<ion-item>\n\t\t\t  <ion-input placeholder=\"\" type=\"number\" [(ngModel)]=\"discount\"></ion-input>\n\t\t\t</ion-item>\n\t\t  \n\t\t\t<br>\n\t\t\t<ion-label>Ingrese el precio del producto          </ion-label>\n\t\t\t<ion-item>\n\t\t\t\t\t<ion-input placeholder=\"\" type=\"number\" [(ngModel)]=\"price\"></ion-input>\n\t\t\t\t  </ion-item>\n\n\t\t\t\t  <br>\n\t\t   \n\t\t\t\t\t\t\t  <div *ngIf=\"downloadURL != null\">\n\t\t\t\t\t\t\t\t<img src=\"{{downloadURL}}\">\n\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t <ion-item>\n\t\t\t\t\t\t\n\t\t\t\t\t\t   <input type=\"file\" name=\"select Image\" [(ngModel)]=\"downloadURL\" (change)=\"onChange($event)\" >\n\t\t\t\t\t  </ion-item>\n                    \n\t\t<br>\n\t\t<ion-list>\n\t\t\t<ion-list-header>Seleccione su tienda</ion-list-header>\n\t\t  \n\t\t\t<ion-item>\n\t\t\t  <ion-label>Tienda</ion-label>\n\t\t\t  <ion-select [(ngModel)]=\"vendor\" >\n\t\t\t\t<ion-select-option value=\"Industrias Delman\">Industrias Delman</ion-select-option>\n\t\t\t\t<ion-select-option value=\"Confecciones Marrog\">Confecciones Marrog</ion-select-option>\n\t\t\t  </ion-select>\n\t\t\t</ion-item>\n\t\t  \n\t\t\t<ion-item>\n\t\t\t  <ion-label>Categoria</ion-label>\n\t\t\t  <ion-select value=\"\" [(ngModel)]=\"category\" okText=\"Ok\" cancelText=\"Cancelar\">\n\t\t\t\t<ion-select-option value=\"Camisa de boton\">Camisa de boton</ion-select-option>\n\t\t\t\t<ion-select-option value=\"Camisa polo\">Camisa polo</ion-select-option>\n\t\t\t\t<ion-select-option value=\"Sudadera\">Sudadera</ion-select-option>\n\t\t\t\t<ion-select-option value=\"Camiseta\">Camiseta</ion-select-option>\n\t\t\t  </ion-select>\n\t\t\t</ion-item>\n\n\t\t\t<ion-item>\n\t\t\t\t<ion-label>Configuracion</ion-label>\n\t\t\t\t<ion-select value=0 type=\"number\" [(ngModel)]=\"type\" okText=\"Ok\" cancelText=\"Cancelar\">\n\t\t\t\t  <ion-select-option  type=\"number\" value=1>Mostrar en slide</ion-select-option>\n\t\t\t\t  <ion-select-option  type=\"number\" value=0>Mostrar solo en catalogo</ion-select-option>\n\t\t\t\t \n\t\t\t\t</ion-select>\n\t\t\t  </ion-item>\n\t\t  \n\t\t  </ion-list>\n\t\t<ion-row>\n\t\t  <ion-col text-center>\n\t\t\t<ion-button color=\"primary\" (click)=\"CreateNewProduct()\" [disabled]=\"!name || !description \">\n\t\t\t  <ion-icon size=\"small\" slot=\"icon-only\" name=\"add\"></ion-icon>\n\t\t\t  &nbsp;Crear producto\n\t\t\t</ion-button>\n\t\t  </ion-col>\t\n\t\t</ion-row>\n\t\t\n\t  </ion-grid>\n \n</ion-content>"

/***/ }),

/***/ "./src/app/add-product/add-product.page.scss":
/*!***************************************************!*\
  !*** ./src/app/add-product/add-product.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWRkLXByb2R1Y3QvQzpcXFVzZXJzXFxhbGV4YVxcRGVza3RvcFxcRmluYWwvc3JjXFxhcHBcXGFkZC1wcm9kdWN0XFxhZGQtcHJvZHVjdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxzRkFBYSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvYWRkLXByb2R1Y3QvYWRkLXByb2R1Y3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXIge1xyXG4gICBcclxuICAgIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgdmFyKC0taW9uLWNvbG9yLWRhcmspLCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkpO1xyXG4gICAgICAgIFxyXG4gIH0iXX0= */"

/***/ }),

/***/ "./src/app/add-product/add-product.page.ts":
/*!*************************************************!*\
  !*** ./src/app/add-product/add-product.page.ts ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var products_1 = __webpack_require__(/*! ../../providers/products */ "./src/providers/products.ts");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var firebase = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
var AddProductPage = /** @class */ (function () {
    function AddProductPage(productService, toastCtrl, storage) {
        this.productService = productService;
        this.toastCtrl = toastCtrl;
        this.storage = storage;
        this.active = true;
        this.disableSubmit = false;
        this.success = false;
        this.form = {};
        this.currentUser = firebase.auth().currentUser;
        console.log(this.currentUser);
    }
    AddProductPage.prototype.ngOnInit = function () {
    };
    AddProductPage.prototype.CreateNewProduct = function () {
        var _this = this;
        var product = {};
        product['active'] = this.active;
        product['description'] = this.description;
        product['discount'] = this.discount;
        product['name'] = this.name;
        product['price'] = this.price;
        product['type'] = this.type;
        product['thumb'] = this.downloadURL;
        product['category'] = this.category;
        product['vendor'] = this.vendor;
        this.productService.createNewProduct(product).then(function (res) {
            _this.active = true;
            _this.description = "";
            _this.discount = 0;
            _this.name = "";
            _this.price = 0;
            _this.type = 0;
            _this.thumb = "";
            _this.category = "";
            _this.vendor = "";
            console.log(res);
            _this.id = _this.products.payload.doc.data().id;
        }).catch(function (error) {
            console.log(error);
        });
        this.toastCtrl.create({
            message: 'Se agrego con exito',
            duration: 2000,
            position: 'bottom'
        });
    };
    AddProductPage.prototype.onChange = function (event) {
        this.selectedFile = event.target.files[0];
        this.disableSubmit = true;
        this.upLoad();
    };
    AddProductPage.prototype.upLoad = function () {
        var _this = this;
        var fileName = this.selectedFile.name;
        var storageRef = firebase.storage().ref('products products/' + fileName);
        var metadata = { contentType: 'image/jpeg' };
        var uploadTask = storageRef.put(this.selectedFile, metadata);
        uploadTask.on('state_changed', function (snapshot) {
            console.log(snapshot);
            var progress = (uploadTask.snapshot.bytesTransferred / uploadTask.snapshot.totalBytes) * 100;
            console.log('upload' + progress + '% done');
            switch (uploadTask.snapshot.state) {
                case firebase.storage.TaskState.PAUSED: // or Paused
                    console.log('upLoad is paused');
                    break;
                case firebase.storage.TaskState.RUNNING: // OR Running
                    console.log('upload is running');
                    break;
            }
        }, function (error) {
            console.log(error);
        }, function () {
            _this.disableSubmit = false;
            storageRef.getDownloadURL().then(function (ref) {
                console.log(ref);
                _this.downloadURL = ref;
            });
            console.log(_this.downloadURL);
            console.log('success');
            _this.success = true;
        });
    };
    AddProductPage = __decorate([
        core_1.Component({
            selector: "app-add-product",
            template: __webpack_require__(/*! ./add-product.page.html */ "./src/app/add-product/add-product.page.html"),
            styles: [__webpack_require__(/*! ./add-product.page.scss */ "./src/app/add-product/add-product.page.scss")]
        }),
        __metadata("design:paramtypes", [products_1.ProductsProvider, angular_1.ToastController, storage_1.Storage])
    ], AddProductPage);
    return AddProductPage;
}());
exports.AddProductPage = AddProductPage;


/***/ })

}]);
//# sourceMappingURL=add-product-add-product-module.js.map