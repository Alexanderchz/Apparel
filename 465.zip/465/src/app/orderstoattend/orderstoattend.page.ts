import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orderstoattend',
  templateUrl: './orderstoattend.page.html',
  styleUrls: ['./orderstoattend.page.scss'],
})
export class OrderstoattendPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
