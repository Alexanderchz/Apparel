import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shirt-info',
  templateUrl: './shirt-info.page.html',
  styleUrls: ['./shirt-info.page.scss'],
})
export class ShirtInfoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
