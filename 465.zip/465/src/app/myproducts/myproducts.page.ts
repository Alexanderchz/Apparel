import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myproducts',
  templateUrl: './myproducts.page.html',
  styleUrls: ['./myproducts.page.scss'],
})
export class MyproductsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
