import { Component, OnInit } from "@angular/core";
import { ProductsProvider } from "../../providers/products";
import { ToastController } from '@ionic/angular';
import * as firebase from 'firebase';
import { Storage } from '@ionic/storage';
@Component({
  selector: "app-add-product",
  templateUrl: "./add-product.page.html",
  styleUrls: ["./add-product.page.scss"]
})
export class AddProductPage implements OnInit {
  products: any;
	form: any;
  currentUser: any;
  active: boolean=true;
  description: string;
  id_pd: string;
  disableSubmit: boolean = false;
  discount: number;
  name: string;
  public selectedFile: any;
  downloadURL: any;
  success: boolean = false;
  price: number;

  type: number;

  thumb: string;

  vendor: string;
  id: string;

  category: string;
  constructor(private productService: ProductsProvider, private toastCtrl: ToastController,private storage: Storage) 
  {
    this.form = {};
    this.currentUser = firebase.auth().currentUser;
    console.log(this.currentUser);
  }

  ngOnInit() {
  
  
  }

  CreateNewProduct() {

    const product = {};
    product['active'] = this.active;
    product['description'] = this.description;
    product['discount'] = this.discount;
    product['name'] = this.name;
    product['price'] = this.price;
    product['type'] = this.type;
    product['thumb'] = this.downloadURL;
    product['category'] = this.category;
    product['vendor']= this.vendor;
    
    this.productService.createNewProduct(product).then(res=> {
      this.active=true;
      this.description= "";
      this.discount=0;
      this.name= "";
      this.price= 0;
      this.type=0;
      this.thumb="";
      this.category="";
      this.vendor="";

      console.log(res);

      this.id= this.products.payload.doc.data().id;

    }).catch(error=>{
      console.log(error);
    })

 

    this.toastCtrl.create({
      message: 'Se agrego con exito',
      duration: 2000,
      position: 'bottom'
  })

  

  }


  onChange(event){
    this.selectedFile = event.target.files[0];
    this.disableSubmit = true;
    this.upLoad();
	
	
  }
  


  upLoad(){

    var fileName = this.selectedFile.name;

    var storageRef = firebase.storage().ref('products products/' + fileName);

    var metadata = { contentType: 'image/jpeg'};

    var uploadTask = storageRef.put(this.selectedFile, metadata);
	
	
	

    uploadTask.on('state_changed', (snapshot) =>{

      console.log(snapshot);

      var progress = (uploadTask.snapshot.bytesTransferred / uploadTask.snapshot.totalBytes) * 100 ;

        console.log('upload' + progress + '% done' );

        switch(uploadTask.snapshot.state){
          case firebase.storage.TaskState.PAUSED:   // or Paused
          console.log('upLoad is paused');
          break;

          case firebase.storage.TaskState.RUNNING:   // OR Running
          console.log('upload is running');
          break;

        }

      }, (error) =>  {
          console.log(error);

        },() =>{

       
           this.disableSubmit = false;
		   
		   storageRef.getDownloadURL().then(ref => {
				 
				 console.log(ref);
			  this.downloadURL = ref;
			});
			
		   
		   
		   
          console.log(this.downloadURL);
          console.log('success');
		  
		  
		  this.success = true;
        });

  }
  


}
