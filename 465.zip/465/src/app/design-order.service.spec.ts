import { TestBed } from '@angular/core/testing';

import { DesignOrderService } from './design-order.service';

describe('DesignOrderService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DesignOrderService = TestBed.get(DesignOrderService);
    expect(service).toBeTruthy();
  });
});
