import { Component, OnInit } from '@angular/core';
import { CurrenciesProvider } from 'src/providers/currencies';
import { DesignOrdersProvider } from 'src/providers/designOrders';
import { LoadingController } from '@ionic/angular';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-design-orders',
  templateUrl: './design-orders.page.html',
  styleUrls: ['./design-orders.page.scss'],
})
export class DesignOrdersPage implements OnInit {


  list_orders_success: any = [];
  list_orders_pending: any = [];

  settings: any;

  user_id: any;

  loading: any;

  constructor(
    public currenciesProv: CurrenciesProvider,
    public ordersProv: DesignOrdersProvider,
    public storage: Storage,
    public loadingCtrl: LoadingController
  ) {
    this.presentLoading();

    this.storage.get('setting').then(data => {
      this.settings = data;
    })

    this.storage.get('user').then((obj) => {
      console.log(obj);
      if (obj == null) {
        this.user_id = null;
      } else {
        this.user_id = obj.id_auth;

        this.ordersProv.getDesignOrdersPending(this.user_id).then(data => {
          this.list_orders_pending = data;
          for (var i = 0; i < data.length; ++i) {
            this.list_orders_pending[i]['lst_items'] = JSON.parse(data[i].payload.doc.data().items);
          }
          console.log(this.list_orders_pending);
        });

        this.ordersProv.getDesignOrdersSuccess(this.user_id, 10).then(data => {
          this.loading.dismiss().then(() => {
            this.list_orders_success = data;
            for (var i = 0; i < data.length; ++i) {
              this.list_orders_success[i]['lst_items'] = JSON.parse(data[i].payload.doc.data().items);
            }
          })
          console.log(this.list_orders_success);
        });
      }
    });

  }

  async presentLoading() {
    this.loading = await this.loadingCtrl.create({
      message: 'Cargando',
      duration: 2000
    });
    return await this.loading.present();
  }

  ionViewWillEnter() {
  }


  ngOnInit() {
  }
}
