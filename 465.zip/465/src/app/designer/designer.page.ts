import { Component, OnInit } from '@angular/core';
import { DesignOrdersProvider } from '../../providers/designOrders';
import * as firebase from 'firebase';
import { Storage } from '@ionic/storage';
import { AboutProvider } from 'src/providers/about';


@Component({
  selector: 'app-designer',
  templateUrl: './designer.page.html',
  styleUrls: ['./designer.page.scss'],
})
export class DesignerPage implements OnInit {
  form: any;
  currentUser: any;
  fullName: string;
  phoneNumber: number;
  email: string;
  description:string;
  thumb: string;
  vendor: string;
  logo: string;
  public selectedFile: any;
  downloadURL: any;
  success: boolean = false;
  disableSubmit: boolean = false;

  constructor(private designOrderService: AboutProvider) 
  {

    this.form = {};
    this.currentUser = firebase.auth().currentUser;
    console.log(this.currentUser);

   }

  ngOnInit() {
  }



  createDesignOrder(){
    const designOrder={};

    designOrder['fullName']=this.fullName;
    designOrder['phoneNumber']= this.phoneNumber;
    designOrder['email']= this.email;
    designOrder['description'] = this.description;
    designOrder['thumb'] = this.downloadURL;
    designOrder['vendor'] = this.vendor;
    designOrder['logo']= this.logo;

    this.designOrderService.createNewDesignOrder(designOrder).then(res=>{
      this.fullName= "";
      this.phoneNumber=0;
      this.email="";
      this.description="";
      this.thumb="";
      this.vendor="";
      this.logo="";

      console.log(res);
    }).catch(error=>{
      console.log(error);
    })
  }
  

  onChange(event){
    this.selectedFile = event.target.files[0];
    this.disableSubmit = true;
    this.upLoad();
	
	
  }


  onChangeLogo(event){
    this.selectedFile = event.target.files[0];
    this.disableSubmit = true;
    this.upLoadLogo();
	
	
  }

  upLoad(){

    var fileName = this.selectedFile.name;

    var storageRef = firebase.storage().ref('products products/' + fileName);

    var metadata = { contentType: 'image/jpeg'};

    var uploadTask = storageRef.put(this.selectedFile, metadata);
	
	
	

    uploadTask.on('state_changed', (snapshot) =>{

      console.log(snapshot);

      var progress = (uploadTask.snapshot.bytesTransferred / uploadTask.snapshot.totalBytes) * 100 ;

        console.log('upload' + progress + '% done' );

        switch(uploadTask.snapshot.state){
          case firebase.storage.TaskState.PAUSED:   // or Paused
          console.log('upLoad is paused');
          break;

          case firebase.storage.TaskState.RUNNING:   // OR Running
          console.log('upload is running');
          break;

        }

      }, (error) =>  {
          console.log(error);

        },() =>{

       
           this.disableSubmit = false;
		   
		   storageRef.getDownloadURL().then(ref => {
				 
				 console.log(ref);
			  this.downloadURL = ref;
			});
			
		   
		   
		   
          console.log(this.downloadURL);
          console.log('success');
		  
		  
		  this.success = true;
        });

  }



  upLoadLogo(){

    var fileName = this.selectedFile.name;

    var storageRef = firebase.storage().ref('products products/' + fileName);

    var metadata = { contentType: 'image/jpeg'};

    var uploadTask = storageRef.put(this.selectedFile, metadata);
	
	
	

    uploadTask.on('state_changed', (snapshot) =>{

      console.log(snapshot);

      var progress = (uploadTask.snapshot.bytesTransferred / uploadTask.snapshot.totalBytes) * 100 ;

        console.log('upload' + progress + '% done' );

        switch(uploadTask.snapshot.state){
          case firebase.storage.TaskState.PAUSED:   // or Paused
          console.log('upLoad is paused');
          break;

          case firebase.storage.TaskState.RUNNING:   // OR Running
          console.log('upload is running');
          break;

        }

      }, (error) =>  {
          console.log(error);

        },() =>{

       
           this.disableSubmit = false;
		   
		   storageRef.getDownloadURL().then(ref => {
				 
				 console.log(ref);
			  this.logo = ref;
			});
			
		   
		   
		   
          console.log(this.logo);
          console.log('success');
		  
		  
		  this.success = true;
        });

  }

}
