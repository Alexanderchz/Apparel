import { Component } from '@angular/core';
import { environment } from '../../environments/environment';
import { ThemeProvider } from '../../providers/theme';

@Component({
	selector: 'app-setting',
	
	templateUrl: './setting.page.html',
	styleUrls: ['./setting.page.scss'],
})
export class SettingPage {


	constructor() {

	}


}
