import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-administration',
  templateUrl: './administration.page.html',
  styleUrls: ['./administration.page.scss'],
})
export class AdministrationPage implements OnInit {

  constructor(public navCtrl: NavController) { }

  ngOnInit() {
  }



  categories(){
    this.navCtrl.navigateRoot('/categories');
  }

}
