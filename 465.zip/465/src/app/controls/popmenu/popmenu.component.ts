import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { routerNgProbeToken } from '@angular/router/src/router_module';

@Component({
  selector: 'popmenu',
  templateUrl: './popmenu.component.html',
  styleUrls: ['./popmenu.component.scss']
})
export class PopmenuComponent implements OnInit {
  openMenu: Boolean = false;
  constructor(public router: NavController) { }

  ngOnInit() {
  }

  togglePopupMenu() {
    return this.openMenu = !this.openMenu;
  }


  shirtInfo() {

    this.router.navigateRoot('/shirt-info');
  }


  suggestions() {
    this.router.navigateRoot('/suggestions');
  }

  comments() {
    this.router.navigateRoot('/comments');
  }


}
