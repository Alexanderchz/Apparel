import { Component } from '@angular/core';
import { Platform, Events, MenuController, ToastController } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Storage } from '@ionic/storage';

import { environment } from '../environments/environment';


import { CurrenciesProvider } from '../providers/currencies';

import { UsersProvider } from '../providers/users';

import { tap } from 'rxjs/operators';

import { Router } from '@angular/router';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { finalize } from 'rxjs/operators';


@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'
})
export class AppComponent {
  menu = [];
  user: any;

  constructor(
    public currenciesProv: CurrenciesProvider,

    public toastCtrl: ToastController,
    public menuCtrl: MenuController, 
    public events: Events, 
    private storage: Storage, 
    public usersProv: UsersProvider, 
    private router: Router,
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
  ) {

    this.menu = environment.menu;



    this.events.subscribe('user: change', (user) => {
      if(user || user != null){
        console.log('userchange');
        console.log(user);
        this.user = user;
        this.menuCtrl.enable(true);
      }else{
        this.router.navigateByUrl('login');
        this.menuCtrl.enable(false);
      }
    });


    this.storage.ready().then(() => {
      this.storage.get('user').then((val) => {
        console.log(val);
        if(val != null){
          this.user = val;
          this.menuCtrl.enable(true);
        }else{
          this.router.navigateByUrl('login');
          this.menuCtrl.enable(false);
        }
      })
    })

    this.initializeApp();
  }

  ionViewWillEnter(){

  }


  async presentToast(msg) {
    const toast = await this.toastCtrl.create({
      message: msg.body,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.router.navigateByUrl('/login');
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }

  logout() {
    this.usersProv.logoutUser().then(() => {
      this.storage.remove('user');
      this.user = null;
      this.storage.remove('cart_list');
      this.router.navigateByUrl('/login');
      this.menuCtrl.enable(false);
    });
  }

}
