import { Injectable } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { Observable } from 'rxjs-compat/Observable';
import * as firebase from 'firebase';
import { AngularFirestore } from 'angularfire2/firestore';
import { AngularFirestoreModule } from 'angularfire2/firestore';
import { Facebook, FacebookLoginResponse } from '@ionic-native/facebook/ngx';


import 'rxjs/add/operator/map';
import {map} from 'rxjs/Operator/map';
import { URLSearchParams } from '@angular/http';





@Injectable()
export class ServiceProvider {


	product_id: Array<number> = [];
	url: any;
	cart: any;
	params:any;
	orderLists: any;
	public ref: any;  
	productsList:any;
	customerList: any;
	public orderList: any;
	
	
	total: number = 0;
	proqty: Array<number> = [];
	getSecKey: any;
	users: any;
	

	public fireAuth: any;
	public restaurantUserInfo : any;
	public restaurants : any;
	public restaurantCategory : any;
	public category: any;
	public restaurantItems: any;
	public items: any;
	public currentUser: any;
	public userAddressList: any;
	
	public cityName: any;
	public cityDistrictName: any;
	public streetName: any;
	public apartmentOfficeName: any;
	public categorizedOrders: any;
	public favoriteItem: any;
	public favoriteItemList: any;
	public chats: any;
	public userChatList: any;
	public allChoosenItems: any;
	
	public hotelCords: any;
	
	public bannerList: any;
	
	public ownerRestaurantList: any;
	
	public ownerCategoryList: any;
	
	public addCategory: any;
	
	public ownerCategoryListDetails: any;
	
	public ownerRestaurantListDetails: any;
	
	public newUserChatList: any;
	
	public categorizedOrderList: any;
	
	public ownerOrderList: any;
	
	public allOrderDetails: any;
	
	public orderCompleted: any;
	
	public tax: any;
  
	public taxPercent: any;
	  
	public reportsDay: any;
	 
	public todayReport: any;
	 
	public reportsMonth: any;
	 
	public monthReport: any;
	  
	public reportsYear: any;
	  
	public yearsReport: any;
	  
	public orderlistByDay: any;
	  
	public orderlistByMonth: any;

	public orderlistByYear: any;
	
	public completedOrderDetails: any;

  constructor(public afs: AngularFirestore, public facebook: Facebook, public alertCtrl: AlertController ) {
	  
	  this.cart = { "line_items": [],
		"extraOptions": [] };
		
	  this.currentUser = firebase.auth().currentUser;
	  
	  console.log(this.currentUser);
	  
	  this.fireAuth = firebase.auth(); 
	  
	  this.restaurantUserInfo = firebase.database().ref('/users');
	  
	  this.restaurants = firebase.database().ref('/restaurants');
	  
	  this.restaurantCategory = firebase.database().ref('/category');
	  
	  this.items = firebase.database().ref('/items');
	  
	  this.cityName = firebase.database().ref('/city');
	  
	  this.cityDistrictName = firebase.database().ref('/districts');
	  
	  this.streetName = firebase.database().ref('/streets');
	  
	  this.apartmentOfficeName = firebase.database().ref('/apartments');
	  
	  this.orderList = firebase.database().ref('/orders'); 
	  
	  this.categorizedOrders = firebase.database().ref('/categorizedOrders');
	  
	  this.chats = firebase.database().ref('/chats');
	  
	  this.allChoosenItems = firebase.database().ref('/items');
	  
	  this.hotelCords = firebase.database().ref('/cordItems');
	  
	  
	  this.bannerList = firebase.database().ref('/slider');
	  
	  this.addCategory = firebase.database().ref('/Category_List'); 
	  
	  this.categorizedOrderList = firebase.database().ref('/categorizedOrders');
	  
	  this.orderCompleted = firebase.database().ref('/orderCompleted'); 
	  
	  this.tax = firebase.database().ref('/tax'); 
	
	  this.reportsDay = firebase.database().ref('/reportsDay'); 
	
   	  this.reportsMonth = firebase.database().ref('/reportsMonth'); 
	
	  this.reportsYear = firebase.database().ref('/reports'); 
	
	  
  }
  
  orderByOwnerYear(year){
	   var uid = firebase.auth().currentUser.uid;
	   
	   var yearValue =  parseFloat(year);
	  
	   this.orderlistByYear = this.orderCompleted.child(uid).orderByChild("year").equalTo(yearValue);
	  return this.orderlistByYear;
  }
  
    orderByOwnerMonth(year,month){
	  
	    var uid = firebase.auth().currentUser.uid;
		
		var yearValue =  parseFloat(year);
	  
	   this.orderlistByMonth = this.orderCompleted.child(uid).orderByChild("year").equalTo(yearValue);
	  return this.orderlistByMonth;
	  
  }
  
   orderByOwnerDay(year,month,day){
	  
	    var uid = firebase.auth().currentUser.uid;
		
		console.log(year);
	
	   // var yearValue = parseToFloatyear;
		
		var yearValue =  parseFloat(year);
	  
	   this.orderlistByDay = this.orderCompleted.child(uid).orderByChild("year").equalTo(yearValue);
	   
	   
	  // console.log(this.orderCompleted.child(uid).orderByChild("year").equalTo(year));
	   console.log(this.orderlistByDay);
	   
	  return this.orderlistByDay;
	  
  }
  
  getRestaurantCompletedOrderStatus(order_id){

	var uid = firebase.auth().currentUser.uid;

	this.completedOrderDetails = this.orderCompleted.child(uid).child(order_id);
	
	return this.completedOrderDetails;

    
  }
  
  updateYearReport(order_details,total,status,fee){
		
		console.log(order_details);
		console.log(total);
		console.log(status);
		
		var totals =  parseFloat(total);
		
		var uid = firebase.auth().currentUser.uid;
		
		
		
		var fees = parseFloat(fee);
		
		if(status == "Delivered"){
			console.log("inside delivered");
		
			
			
			firebase.database().ref('reports/' + order_details[0].year + '/'  + uid + '/total' ).once('value').then(function (snapshot) {
			  
			  console.log(snapshot.val());
			  
			 
			  
			  if(snapshot.exists()){
				var totalYear = snapshot.val();
				
					var sumTotal = totalYear + totals;
			  
					  firebase.database().ref('reports/' + order_details[0].year + '/' + uid ).update({
						total: sumTotal,
					});
				
			  }
			  else{
				  
				  
				  
				  firebase.database().ref('reports/' + order_details[0].year + '/' + uid ).update({
						total: totals,
					});
			  }
			  
			  
		
			  
			  
			});
			
			
			
			firebase.database().ref('reports/' + order_details[0].year + '/'  + uid + '/fee' ).once('value').then(function (snapshot) {
			  
			  console.log(snapshot.val());
			  
			 
			  
			  if(snapshot.exists()){
				var totalYearFee = snapshot.val();
				
					var sumFee = totalYearFee + fees;
			  
					  firebase.database().ref('reports/' + order_details[0].year + '/' + uid ).update({
						fee: sumFee,
					});
				
			  }
			  else{
				  
				  
				  
				  firebase.database().ref('reports/' + order_details[0].year + '/' + uid ).update({
						fee: fees,
					});
			  }
			  
			  
		
			  
			  
			});
			
		}
		
		
	
  }
  
  
   updateMonthReport(order_details,total,status,fee){
		
		console.log(order_details);
		console.log(total);
		console.log(status);
		
		var totals =  parseFloat(total);
		
		var uid = firebase.auth().currentUser.uid;
		
		
		
		var fees = parseFloat(fee);
		
		if(status == "Delivered"){
			console.log("inside delivered");
		
			
			
			firebase.database().ref('reportsMonth/' + order_details[0].year + '/' + order_details[0].month + '/' + uid  + '/total' ).once('value').then(function (snapshot) {
			  
			  console.log(snapshot.val());
			  
			  
			  if(snapshot.exists()){
				var totalYear = snapshot.val();
				
					var sumTotal = totalYear + totals;
			  
					  firebase.database().ref('reportsMonth/' + order_details[0].year + '/' + order_details[0].month + '/' + uid ).update({
						total: sumTotal,
					});
				
			  }
			  else{
				  
				  
				  
				  firebase.database().ref('reportsMonth/' + order_details[0].year + '/' + order_details[0].month + '/' + uid ).update({
						total: totals,
					});
			  }
			  
		
			  
			  
			});
			
			
			
			firebase.database().ref('reportsMonth/' + order_details[0].year + '/' + order_details[0].month + '/' + uid  + '/fee' ).once('value').then(function (snapshot) {
			  
			  console.log(snapshot.val());
			  
			 
			  
			  if(snapshot.exists()){
				var totalYearFee = snapshot.val();
				
					var sumFee = totalYearFee + fees;
			  
					  firebase.database().ref('reportsMonth/' + order_details[0].year + '/' + order_details[0].month + '/' + uid ).update({
						fee: sumFee,
					});
				
			  }
			  else{
				  
				  
				  
				  firebase.database().ref('reportsMonth/' + order_details[0].year + '/' + order_details[0].month + '/' + uid ).update({
						fee: fees,
					});
			  }
			  
			  
		
			  
			  
			});
			
		}
	
  }
  
  updateDayReport(order_details,total,status,fee){
		
		console.log(order_details);
		console.log(total);
		console.log(status);
		
		var totals =  parseFloat(total);
		
		var uid = firebase.auth().currentUser.uid;
		
		
		
		
		var fees = parseFloat(fee);
		
		if(status == "Delivered"){
			console.log("inside delivered");
		
			
			
			firebase.database().ref('reportsDay/' + order_details[0].year + '/' + order_details[0].month + '/' + order_details[0].day + '/' + uid + '/total').once('value').then(function (snapshot) {
			  
			  console.log(snapshot.val());
			  
			  
			  if(snapshot.exists()){
				var totalYear = snapshot.val();
				
					var sumTotal = totalYear + totals;
			  
					firebase.database().ref('reportsDay/' + order_details[0].year + '/' + order_details[0].month + '/' + order_details[0].day + '/' + uid ).update({
						total: sumTotal,
					});
				
			  }
			  else{
				  
				 
				  
				  firebase.database().ref('reportsDay/' + order_details[0].year + '/' + order_details[0].month + '/' + order_details[0].day + '/' + uid ).update({
						total: totals,
					});
			  }
			  
		
			  
			  
			});
			
			
			
			
			firebase.database().ref('reportsDay/' + order_details[0].year + '/' + order_details[0].month + '/' + order_details[0].day + '/' + uid + '/fee').once('value').then(function (snapshot) {
			  
			  console.log(snapshot.val());
			  
			 
			  
			  if(snapshot.exists()){
				var totalYearFee = snapshot.val();
				
					var sumFee = totalYearFee + fees;
			  
					  firebase.database().ref('reportsDay/' + order_details[0].year + '/' + order_details[0].month + '/' + order_details[0].day + '/' + uid ).update({
						fee: sumFee,
					});
				
			  }
			  else{
				  
				  
				  
				  firebase.database().ref('reportsDay/' + order_details[0].year + '/' + order_details[0].month + '/' + order_details[0].day + '/' + uid ).update({
						fee: fees,
					});
			  }
			  
			  
		
			  
			  
			});
			
		}
	
  }
  
  
   getTaxPercent(){
	
	this.taxPercent = this.tax.child("percent");
    return this.taxPercent;


  }
  
  
   getTodayReport(year,month,day){

	
	var uid = firebase.auth().currentUser.uid;
	  
	this.todayReport = this.reportsDay.child(year).child(month).child(day).child(uid);
	
	return this.todayReport;
  }
  
  getMonthReport(year,month){

	
	var uid = firebase.auth().currentUser.uid;
	  
	this.monthReport = this.reportsMonth.child(year).child(month).child(uid);
	
	return this.monthReport;
  }
  
  getYearReport(year){

	
	var uid = firebase.auth().currentUser.uid;
	  
	this.yearsReport = this.reportsYear.child(year).child(uid);
	
	return this.yearsReport;
  }
  
   saveStatus(id , status, total){
	  return this.orderList.child(id).update({
		  status : status,
		  total : total,
    });
  }
  
   saveStatusByOwner(id, status, total){
	   
	    var uid = firebase.auth().currentUser.uid;
	  
	 
	   
	  return this.categorizedOrderList.child(uid).child(id).update({
		  status : status,
		  total: total,
    });
  }
  
  
    createOwnerOrderStatus(id, order_details,status,total){
	  
		  var uid = firebase.auth().currentUser.uid;
		  
		  console.log(id);
		  console.log(order_details);
		  console.log(status);
	   
		
		return this.orderCompleted.child(uid).child(id).update({
				
				id: order_details[0].id,
				addresses: order_details[0].addresses,
				customerDetails: order_details[0].customerDetails,
				email: order_details[0].email,
				payments: order_details[0].payments,
				reverseOrder: order_details[0].reverseOrder,
				items: order_details[0].items,
				status: status,
				timeStamp: order_details[0].timeStamp,
				total: total,
				day: order_details[0].day,
				month: order_details[0].month,
				year: order_details[0].year,
				
		});
		
		
	
  }
  

  
  getOrderDetails(id){
	  
	  
	  this.allOrderDetails = this.orderList.child(id);
	  return this.allOrderDetails;
  }
  
  orderByOwner(){
    var uid = firebase.auth().currentUser.uid;
	  
	   this.ownerOrderList = this.categorizedOrderList.child(uid).orderByChild("restaurant_owner_id").equalTo(uid);
	   
	   console.log(this.ownerOrderList);
	   
	  return this.ownerOrderList;
	  
	  
  }
  
   deleteCategory(id){
	  
	  return this.restaurantCategory.child(id).remove();
	  
  }
  
  
  editCategory(cat_id: any, 
	cat_name: any,
	res_name: any, 
	downloadURL: any,
	categoryID: any,
	restaurantDetails: any){  
	 // console.log(restaurantID);
	  
	  console.log(cat_id);
	  console.log(cat_name);
	  console.log(res_name);

	  console.log(downloadURL);
	  console.log(categoryID);
	  console.log(restaurantDetails);
	  //console.log(categoryDetails);
	  
	  var uid = firebase.auth().currentUser.uid;
	  
	  	return this.restaurantCategory.child(categoryID).update({

			  cat_id: cat_id,
			  cat_name: cat_name,
			  image: downloadURL,
			  firebase_url: downloadURL,
			  res_id: res_name,
			  res_name: res_name,
			  restaurant_image: restaurantDetails.firebase_url,
			  restaurant_lat: restaurantDetails.lat,
			  restaurant_long: restaurantDetails.long,
			  restaurant_name: restaurantDetails.title,
			  user_id:  uid,
		

			});
	

	
	
	
	
	
	
	
	
  }
  
   deleteRestaurant(id){
	  
	  return this.restaurants.child(id).remove();
	  
  }
  
  editRestaurant(title: any, 
	address: any,
	description: any, 
	info: any,
	lat: any,
	long: any,
	mark: any,
	option: any,
	outlet: any,
	phonenumber: any,
	downloadURL: any,
	restaurantID: any){  
	 // console.log(restaurantID);
	  
	  console.log(title);
	  console.log(address);
	  console.log(description);
	  console.log(info);
	  console.log(lat);
	  console.log(long);
	  console.log(mark);
	  console.log(option);
	  console.log(outlet);
	  console.log(phonenumber);
	  console.log(downloadURL);
	  console.log(restaurantID);
	  //console.log(categoryDetails);
	  
	  var uid = firebase.auth().currentUser.uid;
	
	
    return this.restaurants.child(restaurantID).update({
      
	  address: address,
	  description: description,
	  firebase_url: downloadURL,
	  image: downloadURL,
	  info: info,
	  lat: lat,
	  long: long,
	  mark: mark,
	  option: option,
	  outlet: outlet,
	  phonenumber: phonenumber,
	  title: title,
	  user_id: uid,
	 
    });
	
	
	
	
	
	
	
	
  }
  
  addNewCategory(newCategory, downloadURL, restaurantDetails){
	  console.log(newCategory);
	  console.log(downloadURL);
	  
	    var uid = firebase.auth().currentUser.uid;
	  
			return this.restaurantCategory.push({

			  cat_id: newCategory.cat_id,
			  cat_name: newCategory.cat_name,
			  image: downloadURL,
			  firebase_url: downloadURL,
			  res_id: newCategory.res_name,
			  res_name: newCategory.res_name,
			  restaurant_image: restaurantDetails.firebase_url,
			  restaurant_lat: restaurantDetails.lat,
			  restaurant_long: restaurantDetails.long,
			  restaurant_name: restaurantDetails.title,
			  user_id:  uid,
		

			});
	  
	  
  }
  
   addNewRestaurant(
	  newRestaurant,   
	  downloadURL,
	 ){
		 
		 console.log(newRestaurant);
		 console.log(downloadURL);
		
	  
	  var uid = firebase.auth().currentUser.uid;
	  
	   return this.restaurants.push({

			  address: newRestaurant.address,
			  description: newRestaurant.description,
			  info: newRestaurant.info,
			  lat: newRestaurant.lat,
			  long: newRestaurant.long,
			  mark: newRestaurant.mark,
			  option : newRestaurant.option,
			  outlet : newRestaurant.outlet,
			  phonenumber : newRestaurant.phonenumber,
			  title : newRestaurant.title,
			  firebase_url : downloadURL,
			  image: downloadURL,
			  user_id: uid,
			});
	  
 
  }
  
  addProfileImage(downloadURL:any){
	  
	  var uid = firebase.auth().currentUser.uid;
	  
    return this.restaurantUserInfo.child(uid).update({

     photoURL: downloadURL,

    });
  }
  
  addRestaurantPro2(
	  newItem,   
	  downloadURL,
	  category
	 ){
		 
		 console.log(newItem);
		 console.log(downloadURL);
		 console.log(category);
	  
	  var uid = firebase.auth().currentUser.uid;
	  
    return this.items.push({

	  available: newItem.available,
	  categories : newItem.categories,
	  category: newItem.category,
	  description: newItem.description,
	  image: newItem.image,
      name: newItem.name,
	  percent: newItem.percent,
	  price : newItem.price,
	  real_price : newItem.real_price,
	  stock : newItem.stock,
	  image_firebase_url : downloadURL,
	  user_id: uid,
	  res_id: category.res_id,
	  restaurant_image: category.restaurant_image,
	  restaurant_lat: category.restaurant_lat,
	  restaurant_long: category.restaurant_long,
	  restaurant_name: category.restaurant_name,

    });
	
	
  }
  
  
  addRestaurantPro(
	  name, 
	  available, 
	  category,
	  description, 
	  image, 
	  percent, 
	  price, 
	  real_price, 
	  stock, 
	  categories,  
	  downloadURL,
	  res_id,
	  restaurant_image,
	  restaurant_lat,
	  restaurant_long,
	  restaurant_name,
	  facebook,
	  instagram,
	  snapchat){
	  
	  var uid = firebase.auth().currentUser.uid;
	  
    return this.items.push({

      name: name,
      available: available,
      category:category,
      description: description,
      image: image,
	  percent: percent,
	  price : price,
	  real_price : real_price,
	  stock : stock,
	  categories : categories,
	  image_firebase_url : downloadURL,
	  user_id: uid,
	  res_id: res_id,
	  restaurant_image: restaurant_image,
	  restaurant_lat: restaurant_lat,
	  restaurant_long: restaurant_long,
	  restaurant_name: restaurant_name,
	  facebook: facebook,
	  instagram: instagram,
	  snapchat: snapchat,

    });//.then( newProduct =>{
      
    //     this.items.child(newProduct.key).child('id').set(newProduct.key);
   //}) ;
  }
  
  restaurantByOwner(){
	  
	  var uid = firebase.auth().currentUser.uid;
	  
	   this.ownerRestaurantList = this.restaurants.orderByChild("user_id").equalTo(uid);
	  return this.ownerRestaurantList;
	  
  }
  

  getRestaurantsById(id){
	 var uid = firebase.auth().currentUser.uid;
	  
	   this.ownerRestaurantListDetails = this.restaurants.child(id);
	  return this.ownerRestaurantListDetails;
	  
  }
  
  getCategoriesById(id){
	 var uid = firebase.auth().currentUser.uid;
	  
	   this.ownerCategoryListDetails = this.restaurantCategory.child(id);
	  return this.ownerCategoryListDetails;
	  
  }
  
    getCategoryList(): any {
    return this.addCategory;
  }

  
    categoryByOwner(){
	  
	  var uid = firebase.auth().currentUser.uid;
	  
	   this.ownerCategoryList = this.restaurantCategory.orderByChild("user_id").equalTo(uid);
	  return this.ownerCategoryList;
	  
  }
  
  restaurantsByOwner(){
	  
	  var uid = firebase.auth().currentUser.uid;
	  
	  console.log(uid);
	  
	   this.ownerRestaurantList = this.restaurants.orderByChild("user_id").equalTo(uid);
	  return this.ownerRestaurantList;
	  
  }

    getBannerList(): any{
	  console.log(this.bannerList);
	  return this.bannerList;
  }
  
  
  getRestaurantUserProfile(id): any {
    return this.restaurantUserInfo.child(id);
  }
  
  
  getRestaurantsList(): any{
	  console.log(this.restaurants);
	  return this.restaurants;
  }
  
  getAllCategoryList(){
	   
    this.category = this.restaurantCategory;
    return this.category;
  }
  
  getRestaurantCategoryLists(id){
	   console.log(id);
    this.category = this.restaurantCategory.orderByChild("res_name").equalTo(id);
    return this.category;
  }
  
  getItemLists(id){
	 console.log(id);
    this.restaurantItems = this.items.orderByChild("categories").equalTo(id);
    return this.restaurantItems;
	  
  }
  
   getItemDetail(id): any{

    return this.items.child(id);
    
  }
  
  getItemExtraOptionsDetail(id){
	 
    return this.items.child(id).child("extraOptions");
    
  }
  
  getCurrentUserAddresses(uid){
	 
	 this.userAddressList = this.restaurantUserInfo.child(uid).child("addresses");
	 
	 return this.userAddressList;
  }
  
   getCityName(){
	  console.log(this.cityName);
	  return this.cityName;
  }
  
  getCityDistrictName(){
	  console.log(this.cityDistrictName);
	  return this.cityDistrictName;
  }
  
  getStreetName(){
	  console.log(this.streetName);
	  return this.streetName;
  }
  
  getApartmentOfficeName(){
	  
	  return this.apartmentOfficeName;
  }
  
  saveNewAddress(city,district,street,apartmentOffice,displayName,email,phone,address,uid){
	    return this.restaurantUserInfo.child(uid).child("addresses").push({
			city: city,
			district:district,
			street:street,
			apartmentOffice:apartmentOffice,
			displayName: displayName,
			email:email,
			phone: phone,
			address: address,
			uid:uid,
			timeStamp: firebase.database.ServerValue.TIMESTAMP,
			reverseOrder: 0 - Date.now()
    });
  }
  
  addOrders(order:String, total:number, uid:String, payments:String, userProfiles:String, currentUserAddress: any){
	  
	  console.log(userProfiles);
			return this.orderList.push({
			  email: uid,
			  items: order,
			  total: total,
			  payments: payments,
			  customerDetails: userProfiles,
			  addresses: currentUserAddress,
			  status: "Queued",
			  timeStamp: firebase.database.ServerValue.TIMESTAMP,
			  reverseOrder: 0 - Date.now()
			});
  }
  
  getUserProfile(id): any {
    return this.restaurantUserInfo.child(id);
  }
  
  chargeStripe(token, currency, amount, secret_kay){
	return false;
/**
  this.getSecKey = secret_kay;
    var headers = new Headers();
    var params = new URLSearchParams();

    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    headers.append('Authorization', 'Bearer ' + secret_kay); 
    params.append("currency", currency);
    params.append("amount",  amount);
    params.append("description", "description");
    params.append("source", token);
		alert("params-"+JSON.stringify(params));
	
				return new Promise(resolve => {  
				  this.http.post(  'https://api.stripe.com/v1/charges', params, { headers: headers }).map(res => res.json())
					.subscribe(data => {
						alert("DATA"+data);
					  resolve(data);
					});
				});
				
				*/
  }
  
  addIdToOrder(newOrderKey){
	  return this.orderList.child(newOrderKey).child('id').set(newOrderKey);
  }
  
  addNewOrdersToEachRestaurantExtra(orderKey,restaurantKey,restaurantName,/**extras,*/order,imagess,name,price,productId,quantity,restaurantId,restaurantNames,newOrderDetails){
	  
	  console.log(orderKey);
	  console.log(restaurantKey);
	  console.log(restaurantName);
	  console.log(order);
	    
		
		    return this.categorizedOrders.child(order.owner_id).child(orderKey).set({
			   	 addresses: newOrderDetails.addresses,
				 customerDetails: newOrderDetails.customerDetails,
				 email: newOrderDetails.email,
				 items:newOrderDetails.items,
				 payments: newOrderDetails.payments,
				 status: newOrderDetails.status,
				 timeStamp: newOrderDetails.timeStamp,
				 total: newOrderDetails.total,
				 restaurant_owner_id: order.owner_id
			});
	  
	  
	
	
	

  }
  
   categorizedRestaurantOrder(orderKey,restaurantKey,owner_id){
	  
	    return this.categorizedOrders.child(owner_id).child(orderKey).update({
		 
			id: orderKey
	  
    });
	  
  }
  
  getOrderDetail(id){
    return this.orderList.child(id);
  }
  
  
  getMyOrderList(id){
    console.log(id);
    this.orderLists =  this.orderList.orderByChild("email").equalTo(id);
    return this.orderLists;
  }
  
  
   getFavoriteItem(id) :any{
	  console.log(id);
	  console.log(firebase.auth());
	  
	  var uid = firebase.auth().currentUser.uid;
	  
	 this.favoriteItem = this.restaurantUserInfo.child(uid).child("favorites").child(id);
	 return this.favoriteItem;
  }
  
   addToFavorite(data,id){
	  
	  var uid = firebase.auth().currentUser.uid;
	  
	  console.log("service");
	  console.log(uid);
	  console.log(data);
	  
	this.restaurantUserInfo.child(uid).child("favorites").child(id).set({
		product_id:id,
		image:data.image_firebase_url,
		name:data.name,
		price:data.price,
		categories:data.categories,
		available:data.available,
		category:data.category,
		description:data.description,
		stock:data.stock,
		restaurantId:data.restaurantId,
		restaurantName:data.restaurantName,
		market:true,
		user_id: data.owner_id,
		facebook: data.facebook,
		instagram: data.instagram,
		snapchat: data.snapchat,
    });
  }
  
   removeFavourite(id){
	  console.log(id);
	  var uid = firebase.auth().currentUser.uid;
	  
	 this.restaurantUserInfo.child(uid).child("favorites").child(id).remove();
	 
  }
  
  getUserFavouriteList(){
	  
	  var uid = firebase.auth().currentUser.uid;
	  
	  this.favoriteItemList = this.restaurantUserInfo.child(uid).child("favorites");
	 return this.favoriteItemList;
  }
  
  
  removeFavItem(item){
	  var uid = firebase.auth().currentUser.uid;
	  
	  console.log(item.id);
	  
	  this.restaurantUserInfo.child(uid).child("favorites").child(item.id).remove();
  }
  
  deleteUserAddress(id){
	  
	  var uid = firebase.auth().currentUser.uid;
	  
    return this.restaurantUserInfo.child(uid).child("addresses").child(id).remove();
  }
  
  
  getUserChatList(id){
	  console.log(id);
	  
	  this.userChatList = this.chats.child(id).child("chat");
	  
	  
	  return this.userChatList;
  }
  
  
  addRoom(uid,data,userImage,userName){
	

	console.log(data);
	
	this.chats.child(data.owner_id).child(data.id).child('chat').child(uid).child('list').child("-0000").set({
      
	  type:'join',
      user:'user',
      message:'Welcome to restaurant.',
	  timeStamp: firebase.database.ServerValue.TIMESTAMP,
      sendDate:''
    
    });
	
	this.chats.child(data.owner_id).child(data.id).child('chat').child(uid).update({
      
	  restaurantTitle: data.title,
	  restaurantImage: data.firebase_url,
	  restaurantOwnerId: data.owner_id,
	  timeStamp: firebase.database.ServerValue.TIMESTAMP,
	  userImage: userImage,
	  userName: userName,
	  lastMessage: "Hello Dear"
    
    });
	
	
	
	
	 this.chats.child(uid).child('chat').child(data.id).child('list').child("-0000").set({
      
	  type:'join',
      user:'user',
      message:'Welcome to restaurant.',
      sendDate:''
    
    });
	
	
	return this.chats.child(uid).child('chat').child(data.id).update({
      
	  restaurantTitle: data.title,
	  restaurantImage: data.firebase_url,
	  restaurantOwnerId: data.owner_id,
	  userImage: userImage,
	  userName: userName,
	  lastMessage: "Hello Dear"
	  
    
    });
	
	
	
  }
  
  getAllChooseItems(): any{
	  
	  console.log(this.allChoosenItems);
	  return this.allChoosenItems;
	  
  }
  
  
  getNearestRestaurantItems(){
	  var uid = firebase.auth().currentUser.uid;
	  
	  return this.hotelCords.child(uid).orderByChild('item_dis');
  }
  
  updateProfileImage( downloadURL){
	  
	  var uid = firebase.auth().currentUser.uid;
	  
	  console.log(uid);
	  console.log(downloadURL);
	  
		return this.restaurantUserInfo.child(uid).update({

			facebook: downloadURL

		});
  }

	editRestaurantProduct(name: any, 
	categoryDetails: any,
	available: any, 
	description: any,
	image: any,
	percent: any,
	price: any,
	stock: any,
	categories: any,
	downloadURL: any,
  id: any){  
	  console.log(id);
	  
	  console.log(categoryDetails);
	  
	  var uid = firebase.auth().currentUser.uid;
	
    return this.items.child(id).update({
      name: name,
	  available: available,
	  description: description,
	  image: image,
	  percent: percent,
	  price: price,
	  categories: categories,
	  image_firebase_url: downloadURL,
	  res_id: categoryDetails.res_id,
	  restaurant_image: categoryDetails.restaurant_image,
	  restaurant_lat: categoryDetails.restaurant_lat,
	  restaurant_long: categoryDetails.restaurant_long,
	  restaurant_name: categoryDetails.restaurant_name,
	  user_id: uid
    });
	
	
	
	
	
	
  }
  
   deleteProduct(id){
	  
	  return this.items.child(id).remove();
	  
  }
  
    restaurantsChatLists(id){
	   var uid = firebase.auth().currentUser.uid;
	  
	   this.newUserChatList = this.chats.child(uid).child(id).child("chat");
	  return this.newUserChatList;
  }
  
  

}
