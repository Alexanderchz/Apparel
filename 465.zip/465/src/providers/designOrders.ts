import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from 'angularfire2/firestore';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class DesignOrdersProvider {

  private snapshotChangesSubscription: any;
  private temp: any;

  constructor(public afs: AngularFirestore) { }

  getDesignOrders() {
    return new Promise<any>((resolve, reject) => {
      this.snapshotChangesSubscription = this.afs.collection('design_orders').snapshotChanges().subscribe(snapshots => {
        resolve(snapshots);
        this.snapshotChangesSubscription.unsubscribe();
      })
    });
  }

  getDesignOrdersPending(id_user) {
    return new Promise<any>((resolve, reject) => {
      this.snapshotChangesSubscription = this.afs.collection('design_orders', ref => ref.where('id_user', '==', id_user).where('active', '==', true)).snapshotChanges().subscribe(snapshots => {
        resolve(snapshots);
        this.snapshotChangesSubscription.unsubscribe();
      })
    });
  }

  getDesignOrdersSuccess(id_user, limit) {
    return new Promise<any>((resolve, reject) => {
      this.snapshotChangesSubscription = this.afs.collection('design_orders', ref => ref.where('id_user', '==', id_user).where('active', '==', false).limit(limit)).snapshotChanges().subscribe(snapshots => {
        resolve(snapshots);
        this.snapshotChangesSubscription.unsubscribe();
      })
    });
  }

  addDesignOrders(data) {
    return new Promise<any>((resolve, reject) => {
      data.active = true;
      data.created = Date();
      this.snapshotChangesSubscription = this.afs.collection('design_orders').add(data).then(
        res => resolve(res),
        err => reject(err)
      )
    })
  }
  createDesignorder(designOrder) {
    return this.afs.collection('design_orders').add(designOrder);
  }
}
