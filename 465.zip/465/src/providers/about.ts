
//import * as Constants from '../../config/constants';

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs-compat/Observable';
import { AngularFirestore } from 'angularfire2/firestore';

@Injectable()
export class AboutProvider {

  private snapshotChangesSubscription: any;

  constructor(public afs: AngularFirestore) {}

createNewDesignOrder(designOrder){
  return this.afs.collection('design_orders').add(designOrder);

}
}
