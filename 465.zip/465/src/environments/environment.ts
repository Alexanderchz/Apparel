
export const environment = {
	production: false,
	AdMobFreeBannerConfig: {
		isTesting: true,
		autoShow: true
	},
	firebase: {
		apiKey: 'AIzaSyAU0_A_m4kqjKQ3zcPwzs0uJgkF7zThbZE',
		authDomain: 'proyectodegraduacion-3a260.firebaseapp.com',
		databaseURL: 'https://proyectodegraduacion-3a260.firebaseio.com',
		projectId: 'proyectodegraduacion-3a260',
		storageBucket: 'proyectodegraduacion-3a260.appspot.com',
		messagingSenderId: '416186548795',
		appId: '1:416186548795:web:aeceec77bb54be2f'

	},
	stripe_publish_key: 'pk_test_nqykHcHCdCnWPJCD6pguqShK',
	google_project_number: '762391382612',
	fb_app: 571610369618746,
	fb_v: "v3.2",
	paypal_sandbox_client_id: "AekaSdvxPOk7YzuubQBkNhkLl9BginZXd7f31duyaxK0hfERFlvImx5-k1Q4pF7vDNYwh_bEwE3Zm9X5",
	paypal_live_client_id: "",
	languages: {
		'en': 'English',
		'es': 'Spanish'
	},
	menu: [{
		name: 'Inicio',
		path: '/home-client',
		component: 'HomeClientPage',
		icon: 'ios-home',
	},


	{
		name: 'Mis favoritos',
		path: '/favorites',
		component: 'FavoritesPage',
		icon: 'md-heart-empty',
	}, {
		name: 'Carrito de compras',
		path: '/mycart',
		component: 'MycartPage',
		icon: 'md-basket',
	}, {
		name: 'Mis pedidos',
		path: '/myorder',
		component: 'MyorderPage',
		icon: 'md-clipboard',
	}, {
		name: 'Ofertas',
		path: '/offer',
		component: 'OfferPage',
		icon: 'md-gift',
	}, {
		name: 'Perfil',
		path: '/profile',
		component: 'ProfilePage',
		icon: 'ios-contact',
	},



	],

};

